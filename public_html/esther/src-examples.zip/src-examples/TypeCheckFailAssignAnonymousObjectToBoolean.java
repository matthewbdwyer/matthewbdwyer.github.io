class Object10 {
	
}

public class TypeCheckFailAssignAnonymousObjectToBoolean {
    public static void main(String[] args) {
    	boolean b;
    	
    	b = new Object10();
    }
}