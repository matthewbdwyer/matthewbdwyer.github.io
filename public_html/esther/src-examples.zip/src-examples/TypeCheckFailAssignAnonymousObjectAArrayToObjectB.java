class Object8 {

}

class Object9 {
	
}

public class TypeCheckFailAssignAnonymousObjectAArrayToObjectB {
	public static void main(String[] args) {
		Object9 o;

		o = new Object8[1];
	}
}