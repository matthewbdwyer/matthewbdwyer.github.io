public class TypeCheckFailIncBoolean {
    public static void main(String[] args) {
    	boolean b;
    	
    	b = true;
    	b++;
    }
}