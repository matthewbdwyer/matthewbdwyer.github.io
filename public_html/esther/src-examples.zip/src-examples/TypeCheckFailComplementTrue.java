public class TypeCheckFailComplementTrue {
    public static void main(String[] args) {
    	boolean b;
    	
    	b = ~true;
    }
}