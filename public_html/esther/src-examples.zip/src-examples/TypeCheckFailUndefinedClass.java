public class TypeCheckFailUndefinedClass {
    public static void main(String[] args) {
    	SomeClass o;
    }
}