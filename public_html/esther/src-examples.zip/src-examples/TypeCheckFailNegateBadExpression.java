public class TypeCheckFailNegateBadExpression {
    public static void main(String[] args) {
    	int i;
    	
    	i = -(true && true);
    }
}