class Object35 {
	
}

public class TypeCheckFailAssignAnonymousObjectToIntArray {
    public static void main(String[] args) {
    	int[] i;
    	
    	i = new Object35();
    }
}