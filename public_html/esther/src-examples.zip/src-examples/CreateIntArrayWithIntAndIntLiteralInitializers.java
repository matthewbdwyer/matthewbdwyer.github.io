public class CreateIntArrayWithIntAndIntLiteralInitializers {
    public static void main(String[] args) {
    	int[] I;
    	int i;
    	
    	i = 0;
    	I = new int[]{ i, 1 };
    }
}