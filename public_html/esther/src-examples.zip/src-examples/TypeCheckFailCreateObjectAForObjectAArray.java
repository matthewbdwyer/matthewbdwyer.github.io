public class TypeCheckFailCreateObjectAForObjectAArray {
    public static void main(String[] args) {
    	COAA[] O;
    	
    	O = new COAA();
    }
}

class COAA {
	
}
