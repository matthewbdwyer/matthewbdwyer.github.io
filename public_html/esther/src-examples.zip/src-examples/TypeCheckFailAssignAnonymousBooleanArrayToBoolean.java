public class TypeCheckFailAssignAnonymousBooleanArrayToBoolean {
    public static void main(String[] args) {
    	boolean b;
     	
    	b = new boolean[1];
    }
}