public class ArrayCreation
{
    public static void main(String[] args)
    {
        AC[] acs;
        
        acs = new AC[] { null, new AC() };
    }
}

class AC
{
    
}