public class TypeCheckFailAssignTrueToIntArray {
    public static void main(String[] args) {
    	int[] I;
    	
    	I = true;
    }
}