public class AEEmptyTest
{
    public static void main(String[] args)
    {
        int x;
        int y;
        boolean b;
        x = 1;
        y = 2;
        b = x + y > 2;
        while (b)
        {
            
        }
        b = x > y;
        return;
    }
}
