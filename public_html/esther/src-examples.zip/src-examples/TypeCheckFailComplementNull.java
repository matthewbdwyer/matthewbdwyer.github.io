public class TypeCheckFailComplementNull {
    public static void main(String[] args) {
    	boolean b;
    	
    	b = ~null;
    }
}