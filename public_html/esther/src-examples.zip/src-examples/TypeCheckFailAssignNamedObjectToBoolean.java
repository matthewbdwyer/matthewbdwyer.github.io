class Object21 {
	
}

public class TypeCheckFailAssignNamedObjectToBoolean {
    public static void main(String[] args) {
    	boolean b;
    	Object21 o;
    	
    	o = new Object21();
    	b = o;
    }
}