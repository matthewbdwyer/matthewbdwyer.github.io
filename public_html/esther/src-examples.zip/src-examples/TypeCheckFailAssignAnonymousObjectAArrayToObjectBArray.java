class Object27 {

}

class Object28 {
	
}

public class TypeCheckFailAssignAnonymousObjectAArrayToObjectBArray {
	public static void main(String[] args) {
		Object28[] o;

		o = new Object27[1];
	}
}