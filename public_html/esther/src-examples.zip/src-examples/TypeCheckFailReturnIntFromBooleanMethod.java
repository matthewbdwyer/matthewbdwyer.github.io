public class TypeCheckFailReturnIntFromBooleanMethod {
    public static void main(String[] args) {
    	
    }
    
    static boolean returnBoolean(){
    	int i;
    	i = 0;
    	return i;
    }
}