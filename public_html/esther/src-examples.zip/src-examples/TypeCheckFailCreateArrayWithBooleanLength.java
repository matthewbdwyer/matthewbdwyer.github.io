public class TypeCheckFailCreateArrayWithBooleanLength {
    public static void main(String[] args) {
    	int[] I;
    	boolean b;
    	
    	b = true;
    	I = new int[b];
    }
}