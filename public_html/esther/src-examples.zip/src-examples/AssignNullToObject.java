public class AssignNullToObject {
	public static void main(String[] args) {
		ANTO o;

		o = null;
	}
}

class ANTO {

}
