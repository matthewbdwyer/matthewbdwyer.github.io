class Object11 {
	
}

class Object12 {
	
}

public class TypeCheckFailAssignAnonymousObjectAToObjectB {
    public static void main(String[] args) {
    	Object11 o;
    	
    	o = new Object12();
    }
}