public class TypeCheckFailAssignFalseToInt {
    public static void main(String[] args) {
    	int i;
    	
    	i = false;
    }
}