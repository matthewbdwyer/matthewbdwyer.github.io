#define NEW(type) (type *)Malloc(sizeof(type))

void *Malloc(unsigned n);
