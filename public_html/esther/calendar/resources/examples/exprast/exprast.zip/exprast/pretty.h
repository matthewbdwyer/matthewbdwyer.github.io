#ifndef __tree_h
#define __tree_h
#include "tree.h"
#endif

void prettyEXP(EXP *e);
