package antlr.explicitast;

public class LiteralAST extends ExprAST
{
	int v = 0;
	
    public LiteralAST(String s)
    {
		v = Integer.parseInt(s);
    } 
	
	public int value() 
	{
		return v;
	}
	
	public String pretty()
	{
		return ""+v;
	}
	
	
	public String toString()
	{
		return ""+v;
	}
	
}
