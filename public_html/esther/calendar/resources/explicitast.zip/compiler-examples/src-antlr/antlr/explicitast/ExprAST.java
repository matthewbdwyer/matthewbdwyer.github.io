package antlr.explicitast;

public abstract class ExprAST 
{
    public abstract int value();
    public abstract String pretty();
}
