// $ANTLR 3.0.1 /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g 2007-09-18 00:57:49

  package antlr.explicitast;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
public class ExplicitExprASTParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "INT", "WS", "'+'", "'-'", "'*'", "'('", "')'"
    };
    public static final int INT=4;
    public static final int WS=5;
    public static final int EOF=-1;

        public ExplicitExprASTParser(TokenStream input) {
            super(input);
            ruleMemo = new HashMap[7+1];
         }
        

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "/Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g"; }



    // $ANTLR start expr
    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:13:1: expr returns [ExprAST e = null;] : l= mexpr ( ( '+' | '-' ) r= mexpr )* ;
    public final ExprAST expr() throws RecognitionException {
        ExprAST e =  null;;
        int expr_StartIndex = input.index();
        ExprAST l = null;

        ExprAST r = null;



           boolean isPlus = true;

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 1) ) { return e; }
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:17:5: (l= mexpr ( ( '+' | '-' ) r= mexpr )* )
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:17:9: l= mexpr ( ( '+' | '-' ) r= mexpr )*
            {
            pushFollow(FOLLOW_mexpr_in_expr57);
            l=mexpr();
            _fsp--;
            if (failed) return e;
            if ( backtracking==0 ) {
               e = l; 
            }
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:18:9: ( ( '+' | '-' ) r= mexpr )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>=6 && LA2_0<=7)) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:19:11: ( '+' | '-' ) r= mexpr
            	    {
            	    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:19:11: ( '+' | '-' )
            	    int alt1=2;
            	    int LA1_0 = input.LA(1);

            	    if ( (LA1_0==6) ) {
            	        alt1=1;
            	    }
            	    else if ( (LA1_0==7) ) {
            	        alt1=2;
            	    }
            	    else {
            	        if (backtracking>0) {failed=true; return e;}
            	        NoViableAltException nvae =
            	            new NoViableAltException("19:11: ( '+' | '-' )", 1, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt1) {
            	        case 1 :
            	            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:19:12: '+'
            	            {
            	            match(input,6,FOLLOW_6_in_expr82); if (failed) return e;
            	            if ( backtracking==0 ) {
            	              isPlus=true;
            	            }

            	            }
            	            break;
            	        case 2 :
            	            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:19:33: '-'
            	            {
            	            match(input,7,FOLLOW_7_in_expr88); if (failed) return e;
            	            if ( backtracking==0 ) {
            	              isPlus=false;
            	            }

            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_mexpr_in_expr106);
            	    r=mexpr();
            	    _fsp--;
            	    if (failed) return e;
            	    if ( backtracking==0 ) {
            	       if (isPlus) {
            	      		e = new PlusNodeAST(e,r);
            	      	    } else {
            	      		e = new MinusNodeAST(e,r);
            	                  }
            	                
            	    }

            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 1, expr_StartIndex); }
        }
        return e;
    }
    // $ANTLR end expr


    // $ANTLR start mexpr
    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:30:1: mexpr returns [ExprAST e = null;] : l= atom ( '*' r= atom )* ;
    public final ExprAST mexpr() throws RecognitionException {
        ExprAST e =  null;;
        int mexpr_StartIndex = input.index();
        ExprAST l = null;

        ExprAST r = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 2) ) { return e; }
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:31:5: (l= atom ( '*' r= atom )* )
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:31:9: l= atom ( '*' r= atom )*
            {
            pushFollow(FOLLOW_atom_in_mexpr160);
            l=atom();
            _fsp--;
            if (failed) return e;
            if ( backtracking==0 ) {
               e = l; 
            }
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:32:9: ( '*' r= atom )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==8) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:32:10: '*' r= atom
            	    {
            	    match(input,8,FOLLOW_8_in_mexpr173); if (failed) return e;
            	    pushFollow(FOLLOW_atom_in_mexpr177);
            	    r=atom();
            	    _fsp--;
            	    if (failed) return e;
            	    if ( backtracking==0 ) {
            	       e = new TimesNodeAST(e,r); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 2, mexpr_StartIndex); }
        }
        return e;
    }
    // $ANTLR end mexpr


    // $ANTLR start atom
    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:35:1: atom returns [ExprAST e = null;] : (i= INT | '(' pe= expr ')' );
    public final ExprAST atom() throws RecognitionException {
        ExprAST e =  null;;
        int atom_StartIndex = input.index();
        Token i=null;
        ExprAST pe = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 3) ) { return e; }
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:36:5: (i= INT | '(' pe= expr ')' )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==INT) ) {
                alt4=1;
            }
            else if ( (LA4_0==9) ) {
                alt4=2;
            }
            else {
                if (backtracking>0) {failed=true; return e;}
                NoViableAltException nvae =
                    new NoViableAltException("35:1: atom returns [ExprAST e = null;] : (i= INT | '(' pe= expr ')' );", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:36:9: i= INT
                    {
                    i=(Token)input.LT(1);
                    match(input,INT,FOLLOW_INT_in_atom211); if (failed) return e;
                    if ( backtracking==0 ) {
                       e = new LiteralAST(i.getText()); 
                    }

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:37:8: '(' pe= expr ')'
                    {
                    match(input,9,FOLLOW_9_in_atom223); if (failed) return e;
                    pushFollow(FOLLOW_expr_in_atom227);
                    pe=expr();
                    _fsp--;
                    if (failed) return e;
                    match(input,10,FOLLOW_10_in_atom229); if (failed) return e;
                    if ( backtracking==0 ) {
                       e = pe; 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 3, atom_StartIndex); }
        }
        return e;
    }
    // $ANTLR end atom


 

    public static final BitSet FOLLOW_mexpr_in_expr57 = new BitSet(new long[]{0x00000000000000C2L});
    public static final BitSet FOLLOW_6_in_expr82 = new BitSet(new long[]{0x0000000000000210L});
    public static final BitSet FOLLOW_7_in_expr88 = new BitSet(new long[]{0x0000000000000210L});
    public static final BitSet FOLLOW_mexpr_in_expr106 = new BitSet(new long[]{0x00000000000000C2L});
    public static final BitSet FOLLOW_atom_in_mexpr160 = new BitSet(new long[]{0x0000000000000102L});
    public static final BitSet FOLLOW_8_in_mexpr173 = new BitSet(new long[]{0x0000000000000210L});
    public static final BitSet FOLLOW_atom_in_mexpr177 = new BitSet(new long[]{0x0000000000000102L});
    public static final BitSet FOLLOW_INT_in_atom211 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_9_in_atom223 = new BitSet(new long[]{0x0000000000000210L});
    public static final BitSet FOLLOW_expr_in_atom227 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_10_in_atom229 = new BitSet(new long[]{0x0000000000000002L});

}