package antlr.explicitast;

public class PlusNodeAST extends BinaryOperatorAST
{
    public PlusNodeAST(ExprAST l, ExprAST r)
    {
    	super(l,r, '+');
    } 
	
	public int value() 
	{
		return left().value() + right().value();
	}
	
	public String pretty()
	{
		return "(" + left().pretty() + " + " + right().pretty() + ")";
	}
	
	public String toString()
	{
		return " +";
	}
	
}
