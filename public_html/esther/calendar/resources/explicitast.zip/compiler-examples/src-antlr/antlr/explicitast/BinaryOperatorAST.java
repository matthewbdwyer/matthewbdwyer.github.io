package antlr.explicitast;

public abstract class BinaryOperatorAST extends ExprAST
{
	ExprAST left;
	ExprAST right;
	char operator;
	
	BinaryOperatorAST(ExprAST l, ExprAST r, char op) 
	{
		left = l;
		right = r;
		operator = op;
	}
	
    public ExprAST left() 
    {
		return left;
    } 
	
	public ExprAST right()
	{
		return right;
	}
}
