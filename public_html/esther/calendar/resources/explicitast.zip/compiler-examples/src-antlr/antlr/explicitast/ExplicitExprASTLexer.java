// $ANTLR 3.0.1 /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g 2007-09-18 00:57:49

  package antlr.explicitast;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class ExplicitExprASTLexer extends Lexer {
    public static final int T10=10;
    public static final int T6=6;
    public static final int T9=9;
    public static final int INT=4;
    public static final int EOF=-1;
    public static final int WS=5;
    public static final int Tokens=11;
    public static final int T8=8;
    public static final int T7=7;
    public ExplicitExprASTLexer() {;} 
    public ExplicitExprASTLexer(CharStream input) {
        super(input);
    }
    public String getGrammarFileName() { return "/Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g"; }

    // $ANTLR start T6
    public final void mT6() throws RecognitionException {
        try {
            int _type = T6;
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:6:4: ( '+' )
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:6:6: '+'
            {
            match('+'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T6

    // $ANTLR start T7
    public final void mT7() throws RecognitionException {
        try {
            int _type = T7;
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:7:4: ( '-' )
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:7:6: '-'
            {
            match('-'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T7

    // $ANTLR start T8
    public final void mT8() throws RecognitionException {
        try {
            int _type = T8;
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:8:4: ( '*' )
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:8:6: '*'
            {
            match('*'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T8

    // $ANTLR start T9
    public final void mT9() throws RecognitionException {
        try {
            int _type = T9;
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:9:4: ( '(' )
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:9:6: '('
            {
            match('('); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T9

    // $ANTLR start T10
    public final void mT10() throws RecognitionException {
        try {
            int _type = T10;
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:10:5: ( ')' )
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:10:7: ')'
            {
            match(')'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T10

    // $ANTLR start INT
    public final void mINT() throws RecognitionException {
        try {
            int _type = INT;
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:40:7: ( ( '0' .. '9' )+ )
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:40:9: ( '0' .. '9' )+
            {
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:40:9: ( '0' .. '9' )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>='0' && LA1_0<='9')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:40:10: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end INT

    // $ANTLR start WS
    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:43:7: ( ( ' ' | '\\r' '\\n' | '\\n' | '\\t' ) )
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:43:9: ( ' ' | '\\r' '\\n' | '\\n' | '\\t' )
            {
            // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:43:9: ( ' ' | '\\r' '\\n' | '\\n' | '\\t' )
            int alt2=4;
            switch ( input.LA(1) ) {
            case ' ':
                {
                alt2=1;
                }
                break;
            case '\r':
                {
                alt2=2;
                }
                break;
            case '\n':
                {
                alt2=3;
                }
                break;
            case '\t':
                {
                alt2=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("43:9: ( ' ' | '\\r' '\\n' | '\\n' | '\\t' )", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:43:11: ' '
                    {
                    match(' '); 

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:43:17: '\\r' '\\n'
                    {
                    match('\r'); 
                    match('\n'); 

                    }
                    break;
                case 3 :
                    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:43:29: '\\n'
                    {
                    match('\n'); 

                    }
                    break;
                case 4 :
                    // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:43:36: '\\t'
                    {
                    match('\t'); 

                    }
                    break;

            }

             channel=HIDDEN; 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end WS

    public void mTokens() throws RecognitionException {
        // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:1:8: ( T6 | T7 | T8 | T9 | T10 | INT | WS )
        int alt3=7;
        switch ( input.LA(1) ) {
        case '+':
            {
            alt3=1;
            }
            break;
        case '-':
            {
            alt3=2;
            }
            break;
        case '*':
            {
            alt3=3;
            }
            break;
        case '(':
            {
            alt3=4;
            }
            break;
        case ')':
            {
            alt3=5;
            }
            break;
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
            {
            alt3=6;
            }
            break;
        case '\t':
        case '\n':
        case '\r':
        case ' ':
            {
            alt3=7;
            }
            break;
        default:
            NoViableAltException nvae =
                new NoViableAltException("1:1: Tokens : ( T6 | T7 | T8 | T9 | T10 | INT | WS );", 3, 0, input);

            throw nvae;
        }

        switch (alt3) {
            case 1 :
                // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:1:10: T6
                {
                mT6(); 

                }
                break;
            case 2 :
                // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:1:13: T7
                {
                mT7(); 

                }
                break;
            case 3 :
                // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:1:16: T8
                {
                mT8(); 

                }
                break;
            case 4 :
                // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:1:19: T9
                {
                mT9(); 

                }
                break;
            case 5 :
                // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:1:22: T10
                {
                mT10(); 

                }
                break;
            case 6 :
                // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:1:26: INT
                {
                mINT(); 

                }
                break;
            case 7 :
                // /Users/dwyer/compilers-workspace/compiler-examples/src-antlr/antlr/explicitast/ExplicitExprAST.g:1:30: WS
                {
                mWS(); 

                }
                break;

        }

    }


 

}