package antlr.explicitast;
import org.antlr.runtime.ANTLRStringStream;
import org.antlr.runtime.CommonTokenStream;

import junit.framework.Assert;
import junit.framework.TestCase;

public class ExprTreeTest extends TestCase
{
    public static void testPass(String input, int result, String pretty)
    {
       try {
            ANTLRStringStream afs = new ANTLRStringStream(input);
            ExplicitExprASTLexer sjl = new ExplicitExprASTLexer(afs);
            CommonTokenStream cts = new CommonTokenStream(sjl);
            ExplicitExprASTParser eeap = new ExplicitExprASTParser(cts);
            
            ExprAST rootExpr = eeap.expr();
             
			int v = rootExpr.value();
            Assert.assertTrue(v == result);
            
			String s = rootExpr.pretty();
			System.out.println(s);
			Assert.assertTrue(s.equals(pretty));
        }
        catch (Exception e)
        {
             e.printStackTrace();
             Assert.assertTrue(e.getMessage(), false);
        }
    }
    
    public void testPlus()
    {
        testPass("1 + 2 + 3 + 4", 10, "(((1 + 2) + 3) + 4)");
    }
    
    public void testMixed()
    {
        testPass("1 - 2 + 3 - 4", -2, "(((1 - 2) + 3) - 4)");
    }
	
	public void testMul()
	{
		testPass("2 * 2 * 2", 8, "((2 * 2) * 2)");
	}
	
	public void testParen()
	{
		testPass("(1 + 3) * 2", 8, "((1 + 3) * 2)");
	}
	
	public void testNoParen()
	{
		testPass("1 + 3 * 2", 7, "(1 + (3 * 2))");
	}
	
	public void testNestedParens()
	{
		testPass("(((1)) + (2 * (((3) + 1)))) - 1", 8, 
				"((1 + (2 * (3 + 1))) - 1)");
	}
    

	
}
