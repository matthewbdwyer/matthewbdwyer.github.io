public class ForEmpty {
    public static void main(String[] args) {
    }
    
    static void empty() {
        for (;;) {
        }
    }
}
