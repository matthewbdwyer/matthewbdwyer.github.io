public class ForMultipleIncOrDecOnly {
    public static void main(String[] args) {
    }
    
    static void multipleIncOrDecOnly() {
        int i;
        int j;
        int k;
        
        i = 0;
        j = 0;
        k = 0;
        for (;; i++, j++, k++) {
        }
    }
}
