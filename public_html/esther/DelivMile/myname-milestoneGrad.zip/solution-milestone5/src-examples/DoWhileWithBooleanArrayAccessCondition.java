public class DoWhileWithBooleanArrayAccessCondition {
	public static void main(String[] args) {
		boolean[] B;
		int i;

		B = new boolean[] { true, false };
		i = 1;
		do {

		} while (B[i]);
	}
}
