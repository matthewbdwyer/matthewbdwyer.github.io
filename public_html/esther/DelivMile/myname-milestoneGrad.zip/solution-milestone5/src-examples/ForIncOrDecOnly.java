public class ForIncOrDecOnly {
    public static void main(String[] args) {
    }
    
    static void incOrDecOnly() {
        int i;
        
        i = 0;
        for (;; i++) {
        }
    }
}
