public class BooleanLiteral {
    public static void main(String[] args) {
        StaticJavaLib.assertTrue( true);
        StaticJavaLib.assertTrue(!false);
    }
}
