public class ForMultipleInitOnly {
    public static void main(String[] args) {
    }
    
    static void multipleInitOnly() {
        int i;
        int j;
        int k;
        
        for (i = 0, j = 0, k = 0;;) {
        }
    }
}
