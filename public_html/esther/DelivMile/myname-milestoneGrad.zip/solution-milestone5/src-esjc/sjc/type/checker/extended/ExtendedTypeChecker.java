package sjc.type.checker.extended;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ArrayAccess;
import org.eclipse.jdt.core.dom.ArrayCreation;
import org.eclipse.jdt.core.dom.ArrayInitializer;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.ConditionalExpression;
import org.eclipse.jdt.core.dom.DoStatement;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.FieldAccess;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.ForStatement;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.NullLiteral;
import org.eclipse.jdt.core.dom.PostfixExpression;
import org.eclipse.jdt.core.dom.PrefixExpression;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SimpleType;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import sjc.annotation.NonNull;
import sjc.annotation.NonNullElements;
import sjc.annotation.ReadOnlyElements;
import sjc.symboltable.SymbolTable;
import sjc.symboltable.extended.ExtendedSymbolTable;
import sjc.type.ArrayType;
import sjc.type.BaseType;
import sjc.type.ClassType;
import sjc.type.NonPrimitiveType;
import sjc.type.NullType;
import sjc.type.Type;
import sjc.type.TypeFactory;
import sjc.type.checker.TypeChecker;
import sjc.type.checker.TypeChecker.Error;
import sjc.util.Pair;

/**
 * This class is used to type check a StaticJava {@link CompilationUnit} with a
 * given {@link SymbolTable}.
 * 
 * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
 */
public class ExtendedTypeChecker
    extends TypeChecker
{
    /**
     * Declared as protected to disallow creation of this object outside from
     * the methods of this class.
     */
    protected ExtendedTypeChecker()
    {
    }

    /**
     * Type checks an ExtendedStaticJava {@link CompilationUnit} with the given
     * {@link ExtendedSymbolTable} and the given {@link TypeFactory}. It also
     * resolves {@link MethodInvocation} of library call (and put its mapping in
     * the {@link ExtendedSymbolTable}).
     * 
     * @param tf
     *            The {@link TypeFactory}.
     * @param cu
     *            The StaticJava {@link CompilationUnit}.
     * @param symbolTable
     *            The {@link ExtendedSymbolTable} of the {@link CompilationUnit}
     * @return The {@link ExtendedTypeTable}.
     * @throws TypeChecker.Error
     *             If the type checker encounter type error in the
     *             {@link CompilationUnit}.
     */
    public static @NonNull ExtendedTypeTable check(
        @NonNull TypeFactory tf,
        @NonNull CompilationUnit cu,
        @NonNull ExtendedSymbolTable symbolTable) throws TypeChecker.Error
    {
        assert tf != null && cu != null && symbolTable != null;

        Visitor v = new Visitor(tf, symbolTable);
        cu.accept(v);
        ExtendedTypeTable result = new ExtendedTypeTable(
            v.resultTypeMap,
            v.resultMethodTypeMap);
        v.dispose();
        return result;
    }

    /**
     * The visitor for {@link ASTNode} to type check an ExtendedStaticJava
     * {@link CompilationUnit}.
     * 
     * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
     */
    protected static class Visitor
        extends TypeChecker.Visitor
    {
        protected @NonNullElements @ReadOnlyElements Map<String, TypeDeclaration> classMap;

        protected @NonNullElements @ReadOnlyElements Map<Pair<String, String>, FieldDeclaration> fieldMap;

        protected Visitor(TypeFactory tf, ExtendedSymbolTable est)
        {
            super(tf, est);
            classMap = est.classMap;
            fieldMap = est.fieldMap;
            for (Pair<String, String> p : est.fieldMap.keySet())
            {
                FieldDeclaration fd = est.fieldMap.get(p);
                Type t = convertType(fd, fd.getType());
                String className = p.first;
                String fieldName = p.second;
                ClassType ct = tf.getClassType(className);
                ct.fieldTypeMap.put(fieldName, t);
            }
        }

        @Override public boolean visit(Assignment node)
        {
            node.getLeftHandSide().accept(this);
            Type lhsType = getResult();
            node.getRightHandSide().accept(this);
            Type rhsType = getResult();
            if (rhsType instanceof NullType
                && lhsType instanceof NonPrimitiveType)
            {
                // no need to set the type result for assignments since
                // assignments in StaticJava are statements,
                // i.e., they are evaluated for their side-effects.
                return false;
            }
            else if (lhsType != rhsType)
            {
                throw new Error(node, "Type mismatch in \"" + node + "\": "
                                      + lhsType + " = " + rhsType);
            }
            // no need to set the type result for assignments since
            // assignments in StaticJava are statements,
            // i.e., they are evaluated for their side-effects.
            return false;
        }

        @Override public boolean visit(InfixExpression node)
        {
            InfixExpression.Operator op = node.getOperator();
            if (op == InfixExpression.Operator.AND
                || op == InfixExpression.Operator.OR
                || op == InfixExpression.Operator.LEFT_SHIFT
                || op == InfixExpression.Operator.RIGHT_SHIFT_SIGNED
                || op == InfixExpression.Operator.RIGHT_SHIFT_UNSIGNED
                || op == InfixExpression.Operator.XOR)
            {
                node.getLeftOperand().accept(this);
                Type lhsType = getResult();
                node.getRightOperand().accept(this);
                Type rhsType = getResult();
                if (lhsType != tf.Int)
                {
                    throw new Error(
                        node,
                        "Expecting an int type expression as the left-hand operand of \""
                                + op + "\" in \"" + node + "\"");
                }
                if (rhsType != tf.Int)
                {
                    throw new Error(
                        node,
                        "Expecting an int type expression as the right-hand operand of \""
                                + op + "\" in \"" + node + "\"");
                }
                setResult(node, tf.Int);
                return false;
            }
            else if (op == InfixExpression.Operator.EQUALS
                     || op == InfixExpression.Operator.NOT_EQUALS)
            {
                node.getLeftOperand().accept(this);
                Type lhsType = getResult();
                node.getRightOperand().accept(this);
                Type rhsType = getResult();
                if (lhsType instanceof NullType
                    && rhsType instanceof NonPrimitiveType
                    || rhsType instanceof NullType
                    && lhsType instanceof NonPrimitiveType)
                {
                    // OK
                }
                else if (lhsType != rhsType)
                {
                    throw new Error(node, "Type mismatch in \"" + node + "\": "
                                          + lhsType + " " + op + " " + rhsType);
                }
                setResult(node, tf.Boolean);
                return false;
            }
            else
            {
                return super.visit(node);
            }
        }

        @Override public boolean visit(PrefixExpression node)
        {
            PrefixExpression.Operator op = node.getOperator();
            if (op == PrefixExpression.Operator.COMPLEMENT)
            {
                node.getOperand().accept(this);
                Type t = getResult();
                if (t != tf.Int)
                {
                    throw new Error(
                        node,
                        "Expecting an int type expression as the operand of \""
                                + op + "\" in \"" + node + "\"");
                }
                setResult(node, tf.Int);
                return false;
            }
            else
            {
                return super.visit(node);
            }
        }

        @Override public boolean visit(ExpressionStatement node)
        {
            Expression e = node.getExpression();
            if (e instanceof PostfixExpression)
            {
                e.accept(this);
                // postfix expression statement should not have a resulting
                // type.
                assert getResult() == null;
                return false;
            }
            else
            {
                return super.visit(node);
            }
        }

        @Override public boolean visit(ForStatement node)
        {
            for (Object o : node.initializers())
            {
                ((ASTNode) o).accept(this);
            }
            Expression e = node.getExpression();
            if (e != null)
            {
                e.accept(this);
                Type t = getResult();
                if (t != tf.Boolean)
                {
                    throw new Error(
                        node,
                        "Expecting a boolean type expression as the condition of a for-statement: \""
                                + node.getExpression() + "\"");
                }
            }
            for (Object o : node.updaters())
            {
                ((ASTNode) o).accept(this);
            }
            node.getBody().accept(this);
            return false;
        }

        @Override public boolean visit(DoStatement node)
        {
            node.getBody().accept(this);
            node.getExpression().accept(this);
            Type t = getResult();
            if (t != tf.Boolean)
            {
                throw new Error(
                    node,
                    "Expecting a boolean type expression as the condition of a while-statement: \""
                            + node.getExpression() + "\"");
            }
            return false;
        }

        @Override public boolean visit(PostfixExpression node)
        {
            node.getOperand().accept(this);
            Type t = getResult();
            if (t != tf.Int)
            {
                throw new Error(
                    node,
                    "Expecting an int type expression as the operand of \'"
                            + node.getOperator() + "\': \"" + node.getOperand()
                            + "\"");
            }
            // no need to set the type result for postfix expressions since
            // postfix expressions in StaticJava are statements,
            // i.e., they are evaluated for their side-effects.
            return false;
        }

        @Override public boolean visit(ClassInstanceCreation node)
        {
            String className = ((SimpleType) node.getType())
                .getName()
                .getFullyQualifiedName();
            if (!classMap.containsKey(className))
            {
                throw new Error(node, "Undeclared class type in \'" + node
                                      + "\"");
            }
            setResult(node, tf.getClassType(className));
            symbolMap.put(node, classMap.get(className));
            return false;
        }

        @Override public boolean visit(ArrayCreation node)
        {
            ArrayType at = (ArrayType) convertType(node, node.getType());
            ArrayInitializer a = node.getInitializer();
            if (a == null)
            {
                ((ASTNode) node.dimensions().get(0)).accept(this);
                Type t = getResult();
                if (t != tf.Int)
                {
                    throw new Error(
                        node,
                        "Expecting an int type expression for the array length in \'"
                                + node + "\'");
                }
            }
            else
            {
                BaseType bt = (BaseType) at.baseType;
                int i = 0;
                for (Object o : a.expressions())
                {
                    ((ASTNode) o).accept(this);
                    Type t = getResult();
                    if (t instanceof NullType && bt instanceof NonPrimitiveType)
                    {
                        // ok
                    }
                    else if (t != bt)
                    {
                        throw new Error(
                            node,
                            "Type mismatch in array initializer element " + i
                                    + " in \'" + node + "\': " + bt + " : " + t);
                    }
                    i++;
                }
            }
            setResult(node, at);
            return false;
        }

        @Override public boolean visit(FieldAccess node)
        {
            node.getExpression().accept(this);
            Type t = getResult();
            if (!(t instanceof ClassType))
            {
                throw new Error(
                    node,
                    "Expecting a class type expression in field access: \'"
                            + node + "\'");
            }
            ClassType ct = (ClassType) t;
            String fieldName = node.getName().getIdentifier();
            Type fieldType = ct.fieldTypeMap.get(fieldName);
            if (fieldType == null)
            {
                throw new Error(
                    node,
                    "Undeclared field in field access of class type \'" + ct
                            + "\': \'" + node + "\'");
            }
            setResult(node, fieldType);
            symbolMap.put(node, fieldMap.get(new Pair<String, String>(
                ct.name,
                fieldName)));
            return false;
        }

        @Override public boolean visit(ArrayAccess node)
        {
            node.getArray().accept(this);
            Type t = getResult();
            if (!(t instanceof ArrayType))
            {
                throw new Error(node, "Expecting an array type in \'" + node
                                      + "\"");
            }
            ArrayType at = (ArrayType) t;
            node.getIndex().accept(this);
            t = getResult();
            if (t != tf.Int)
            {
                throw new Error(
                    node,
                    "Expecting an int type for the index of \'" + node + "\"");
            }
            setResult(node, at.baseType);
            return false;
        }

        @Override public boolean visit(ConditionalExpression node)
        {
            node.getExpression().accept(this);
            Type eType = getResult();
            if (eType != tf.Boolean)
            {
                throw new Error(
                    node,
                    "Expecting a boolean type expression as the condition in \'"
                            + node + "\"");
            }
            node.getThenExpression().accept(this);
            Type thenType = getResult();
            node.getElseExpression().accept(this);
            Type elseType = getResult();
            if (thenType instanceof NullType
                && elseType instanceof NonPrimitiveType)
            {
                setResult(node, elseType);
                return false;
            }
            else if (thenType instanceof NonPrimitiveType
                     && elseType instanceof NullType)
            {
                setResult(node, thenType);
                return false;
            }
            else if (thenType != elseType)
            {
                throw new Error(
                    node,
                    "Type mismatch for conditional expression \'" + node
                            + "\": " + thenType + " : " + elseType);
            }
            setResult(node, thenType);
            return false;
        }

        @Override public boolean visit(NullLiteral node)
        {
            setResult(node, tf.Null);
            return false;
        }

        @Override public boolean visit(ReturnStatement node)
        {
            Expression e = node.getExpression();
            if (methodReturnType != tf.Void && e != null)
            {
                e.accept(this);
                Type t = getResult();
                if (t instanceof NullType
                    && methodReturnType instanceof NonPrimitiveType)
                {
                    // ok
                }
                else if (t != methodReturnType)
                {
                    throw new Error(node, "Expecting " + methodReturnType.name
                                          + " return expression in \"" + node
                                          + "\"");
                }
            }
            else
            {
                super.visit(node);
            }
            return false;
        }

        @Override protected void dispose()
        {
            super.dispose();

            classMap = null;
            fieldMap = null;
        }

        @Override protected Type convertType(
            ASTNode node,
            org.eclipse.jdt.core.dom.Type t)
        {
            if (t instanceof SimpleType)
            {
                SimpleType st = (SimpleType) t;
                String name = st.getName().getFullyQualifiedName();
                if (classMap.containsKey(name))
                {
                    return tf.getClassType(name);
                }
            }
            return super.convertType(node, t);
        }

        protected void typeCheckMethodInvocation(
            MethodInvocation node,
            String className,
            String methodName,
            Type[] argTypes,
            Method m)
        {
            Class[] paramTypeClasses = m.getParameterTypes();
            int numOfParams = paramTypeClasses.length;
            if (argTypes.length != numOfParams)
            {
                throw new Error(
                    node,
                    "Wrong number of arguments to invoke method \""
                            + methodName + "\" in \"" + node + "\"");
            }
            List<Type> paramTypes = new ArrayList<Type>();
            for (int i = 0; i < numOfParams; i++)
            {
                Type t = convertType(node, paramTypeClasses[i]);
                if (argTypes[i] instanceof NullType
                    && t instanceof NonPrimitiveType)
                {
                    // OK
                }
                else if (t != argTypes[i])
                {
                    throw new Error(node, "Type mismatch the " + i
                                          + " argument in \"" + node + "\"");
                }
                paramTypes.add(t);
            }
            Type returnType = convertType(node, m.getReturnType());
            if (!resultMethodTypeMap.containsKey(m))
            {
                resultMethodTypeMap.put(m, new Pair<Type, List<Type>>(
                    returnType,
                    paramTypes));
            }
            setResult(node, returnType);
        }

        protected void typeCheckMethodInvocation(
            MethodInvocation node,
            String className,
            String methodName,
            Type[] argTypes,
            MethodDeclaration md)
        {
            int numOfParams = md.parameters().size();
            if (argTypes.length != numOfParams)
            {
                throw new Error(
                    node,
                    "Wrong number of arguments to invoke method \""
                            + methodName + "\" in \"" + node + "\"");
            }
            for (int i = 0; i < numOfParams; i++)
            {
                Type t = convertType(node, ((SingleVariableDeclaration) md
                    .parameters()
                    .get(i)).getType());
                if (argTypes[i] instanceof NullType
                    && t instanceof NonPrimitiveType)
                {
                    // OK
                }
                else if (t != argTypes[i])
                {
                    throw new Error(node, "Type mismatch the " + i
                                          + " argument in \"" + node + "\"");
                }
            }
            Type returnType = convertType(node, md.getReturnType2());
            setResult(node, returnType);
        }
    }
}
