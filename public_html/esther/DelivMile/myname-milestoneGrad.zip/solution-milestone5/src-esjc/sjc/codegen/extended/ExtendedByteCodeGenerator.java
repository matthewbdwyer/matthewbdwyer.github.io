package sjc.codegen.extended;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ArrayAccess;
import org.eclipse.jdt.core.dom.ArrayCreation;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.ConditionalExpression;
import org.eclipse.jdt.core.dom.DoStatement;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.FieldAccess;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.ForStatement;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.Modifier;
import org.eclipse.jdt.core.dom.NullLiteral;
import org.eclipse.jdt.core.dom.PostfixExpression;
import org.eclipse.jdt.core.dom.PrefixExpression;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.Modifier.ModifierKeyword;

import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Label;
import org.objectweb.asm.Opcodes;
import static org.objectweb.asm.Opcodes.*;

import sjc.annotation.NonNull;
import sjc.annotation.NonNullElements;
import sjc.annotation.ReadOnlyElements;
import sjc.codegen.ByteCodeGenerator;
import sjc.symboltable.extended.ExtendedSymbolTable;
import sjc.type.ArrayType;
import sjc.type.BooleanType;
import sjc.type.ClassType;
import sjc.type.IntType;
import sjc.type.PrimitiveType;
import sjc.type.Type;
import sjc.type.checker.extended.ExtendedTypeTable;
import sjc.util.Pair;

/**
 * This class is used to translate an ExtendedStaticJava {@link CompilationUnit}
 * to {@link ExtendedClassByteCodes} that represent a Java 1.5 class files.
 * 
 * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
 */
public class ExtendedByteCodeGenerator extends ByteCodeGenerator {
	/**
	 * Declared as protected to disallow creation of this object outside from
	 * the methods of this class.
	 */
	protected ExtendedByteCodeGenerator() {
	}

	/**
	 * Generates a {@link ExtendedClassByteCodes} that represents the class
	 * files for the given ExtendedStaticJava {@link CompilationUnit} with the
	 * given {@link ExtendedSymbolTable} and {@link ExtendedTypeTable}.
	 * 
	 * @param cu
	 *            The StaticJava {@link CompilationUnit}.
	 * @param st
	 *            The {@link ExtendedSymbolTable} of the {@link CompilationUnit}.
	 * @param tt
	 *            The {@link ExtendedTypeTable} of the {@link CompilationUnit}.
	 * @return The {@link ExtendedClassByteCodes} that represents the class
	 *         files for the given ExtendedStaticJava {@link CompilationUnit}
	 *         with the given {@link ExtendedSymbolTable} and
	 *         {@link ExtendedTypeTable}.
	 * @throws ByteCodeGenerator.Error
	 *             If the generator encounter unexpected error.
	 */
	public static @NonNull
	ExtendedClassByteCodes generate(@NonNull
	CompilationUnit cu, @NonNull
	ExtendedSymbolTable est, @NonNull
	ExtendedTypeTable ett) throws ByteCodeGenerator.Error {
		assert cu != null && est != null && ett != null;

		Visitor v = new Visitor(est, ett);
		cu.accept(v);
		ExtendedClassByteCodes result = new ExtendedClassByteCodes(
				v.mainClassName, v.mainClassBytes, v.otherClasses);
		v.dispose();
		return result;
	}

	/**
	 * The visitor for {@link ASTNode} to generate bytecodes.
	 * 
	 * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
	 */
	protected static class Visitor extends ByteCodeGenerator.Visitor {
		public @NonNullElements
		Map<String, byte[]> otherClasses = new HashMap<String, byte[]>();

		protected @NonNullElements
		@ReadOnlyElements
		Map<String, TypeDeclaration> classMap;

		protected @NonNullElements
		@ReadOnlyElements
		Map<Pair<String, String>, FieldDeclaration> fieldMap;

		protected Visitor(@NonNull
		ExtendedSymbolTable st, @NonNull
		ExtendedTypeTable tt) {
			super(st, tt);
			this.classMap = st.classMap;
			this.fieldMap = st.fieldMap;
		}

		public boolean visit(TypeDeclaration node) {
			if (hasPublicModifier(node.modifiers())) {
				return super.visit(node);
			}

			String className = node.getName().getIdentifier();
			cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES
					| ClassWriter.COMPUTE_MAXS);
			cw
					.visit(V1_5, ACC_SUPER, className, null,
							"java/lang/Object", null);
			cw.visitSource(null, null);
			generateConstructor(className);
			for (Object o : node.bodyDeclarations()) {
				FieldDeclaration fd = (FieldDeclaration) o;
				VariableDeclarationFragment vdf = (VariableDeclarationFragment) fd
						.fragments().get(0);
				cw.visitField(ACC_PUBLIC, vdf.getName().getIdentifier(),
						convertType(typeMap.get(fd)), null, null).visitEnd();
			}
			cw.visitEnd();
			byte[] classBytes = cw.toByteArray();
			otherClasses.put(className, classBytes);
			cw = null;
			return false;
		}

		@Override
		public boolean visit(Assignment node) {
			ASTNode lhsNode = node.getLeftHandSide();
			if (lhsNode instanceof SimpleName) {
				node.getRightHandSide().accept(this);
				String varName = ((SimpleName) lhsNode).getIdentifier();
				Object lhsDecl = symbolMap.get(lhsNode);
				if (lhsDecl instanceof FieldDeclaration) {
					FieldDeclaration fd = (FieldDeclaration) lhsDecl;
					String className = ((TypeDeclaration) fd.getParent())
							.getName().getIdentifier();
					mv.visitFieldInsn(PUTSTATIC, className, varName,
							convertType(typeMap.get(fd)));
				} else {
					Type t = typeMap.get(lhsNode);
					if (t instanceof PrimitiveType) {
						mv.visitVarInsn(ISTORE, localIndexMap.get(varName)
								.intValue());
					} else {
						mv.visitVarInsn(ASTORE, localIndexMap.get(varName)
								.intValue());
					}
				}
			} else if (lhsNode instanceof FieldAccess) {
				FieldAccess fa = (FieldAccess) lhsNode;
				fa.getExpression().accept(this);
				node.getRightHandSide().accept(this);
				FieldDeclaration fd = (FieldDeclaration) symbolMap.get(fa);
				String className = ((TypeDeclaration) fd.getParent()).getName()
						.getIdentifier();
				mv.visitFieldInsn(PUTFIELD, className, fa.getName()
						.getIdentifier(), convertType(typeMap.get(fd)));
			} else if (lhsNode instanceof ArrayAccess) {
				ArrayAccess aa = (ArrayAccess) lhsNode;
				aa.getArray().accept(this);
				aa.getIndex().accept(this);
				node.getRightHandSide().accept(this);
				Type t = typeMap.get(lhsNode);
				if (t instanceof BooleanType) {
					mv.visitInsn(BASTORE);
				} else if (t instanceof IntType) {
					mv.visitInsn(IASTORE);
				} else {
					mv.visitInsn(AASTORE);
				}
			} else {
				throw new Error(node,
						"Unexpected left-hand side AST node in \'" + node
								+ "\'");
			}
			return false;
		}

		public boolean visit(ReturnStatement node) {
			Expression e = node.getExpression();
			if (e == null) {
				mv.visitInsn(RETURN);
			} else {
				e.accept(this);
				Type t = typeMap.get(e);
				if (t instanceof PrimitiveType) {
					mv.visitInsn(IRETURN);
				} else {
					mv.visitInsn(ARETURN);
				}
			}
			return false;
		}

		@Override
		public boolean visit(PrefixExpression node) {
			if (node.getOperator() == PrefixExpression.Operator.COMPLEMENT) {
				node.getOperand().accept(this);
				mv.visitInsn(ICONST_M1);
				mv.visitInsn(IXOR);
				return false;
			} else {
				return super.visit(node);
			}
		}

		@Override
		public boolean visit(InfixExpression node) {
			InfixExpression.Operator op = node.getOperator();

			int opcode = 10;
			if (op == InfixExpression.Operator.AND) {
				opcode = IAND;
			} else if (op == InfixExpression.Operator.OR) {
				opcode = IOR;
			} else if (op == InfixExpression.Operator.XOR) {
				opcode = IXOR;
			} else if (op == InfixExpression.Operator.LEFT_SHIFT) {
				opcode = ISHL;
			} else if (op == InfixExpression.Operator.RIGHT_SHIFT_SIGNED) {
				opcode = ISHR;
			} else if (op == InfixExpression.Operator.RIGHT_SHIFT_UNSIGNED) {
				opcode = IUSHR;
			} else if (op == InfixExpression.Operator.EQUALS) {
				node.getLeftOperand().accept(this);
				node.getRightOperand().accept(this);
				if (typeMap.get(node.getLeftOperand()) instanceof PrimitiveType) {
					generateRelationalCode(IF_ICMPEQ);
				} else {
					generateRelationalCode(IF_ACMPEQ);
				}
				return false;
			} else if (op == InfixExpression.Operator.NOT_EQUALS) {
				node.getLeftOperand().accept(this);
				node.getRightOperand().accept(this);
				if (typeMap.get(node.getLeftOperand()) instanceof PrimitiveType) {
					generateRelationalCode(IF_ICMPNE);
				} else {
					generateRelationalCode(IF_ACMPNE);
				}
				return false;
			} else {
				return super.visit(node);
			}
			node.getLeftOperand().accept(this);
			node.getRightOperand().accept(this);
			mv.visitInsn(opcode);
			return false;
		}

		@Override
		public boolean visit(ForStatement node) {
			for (Object o : node.initializers()) {
				((ASTNode) o).accept(this);
			}
			Label loopLabel = new Label();
			Label endLabel = new Label();
			mv.visitLabel(loopLabel);
			Expression e = node.getExpression();
			if (e != null) {
				e.accept(this);
				mv.visitJumpInsn(IFEQ, endLabel);
			}
			node.getBody().accept(this);
			for (Object o : node.updaters()) {
				((ASTNode) o).accept(this);
			}
			mv.visitJumpInsn(GOTO, loopLabel);
			mv.visitLabel(endLabel);
			return false;
		}

		@Override
		public boolean visit(DoStatement node) {
			Label loopLabel = new Label();
			mv.visitLabel(loopLabel);
			node.getBody().accept(this);
			node.getExpression().accept(this);
			mv.visitJumpInsn(IFNE, loopLabel);
			return false;
		}

		@Override
		public boolean visit(PostfixExpression node) {
			Expression e = node.getOperand();
			PostfixExpression.Operator op = node.getOperator();
			Object lhsDecl = symbolMap.get(e);

			if (e instanceof SimpleName) {
				if (lhsDecl instanceof FieldDeclaration) {

					e.accept(this);
					if (op == PostfixExpression.Operator.DECREMENT) {
						mv.visitInsn(ICONST_M1);
					} else {
						mv.visitInsn(ICONST_1);
					}
					mv.visitInsn(IADD);
					String varName = ((SimpleName) e).getIdentifier();
					FieldDeclaration fd = (FieldDeclaration) lhsDecl;
					String className = ((TypeDeclaration) fd.getParent())
							.getName().getIdentifier();
					mv.visitFieldInsn(PUTSTATIC, className, varName,
							convertType(typeMap.get(fd)));
				} else {
					String varName = ((SimpleName) e).getIdentifier();
					int increment = op == PostfixExpression.Operator.DECREMENT ? -1
							: 1;
					mv.visitIincInsn(localIndexMap.get(varName).intValue(),
							increment);
				}
			} else if (e instanceof FieldAccess) {
				FieldAccess fa = (FieldAccess) e;
				fa.getExpression().accept(this);
				FieldDeclaration fd = (FieldDeclaration) symbolMap.get(fa);
				String className = ((TypeDeclaration) fd.getParent()).getName()
						.getIdentifier();
				e.accept(this);
				if (op == PostfixExpression.Operator.DECREMENT) {
					mv.visitInsn(ICONST_M1);
				} else {
					mv.visitInsn(ICONST_1);
				}
				mv.visitInsn(IADD);
				mv.visitFieldInsn(PUTFIELD, className, fa.getName()
						.getIdentifier(), convertType(typeMap.get(fd)));
			} else if (e instanceof ArrayAccess) {
				ArrayAccess aa = (ArrayAccess) e;
				aa.getArray().accept(this);
				aa.getIndex().accept(this);
				e.accept(this);
				if (op == PostfixExpression.Operator.DECREMENT) {
					mv.visitInsn(ICONST_M1);
				} else {
					mv.visitInsn(ICONST_1);
				}
				mv.visitInsn(IADD);
				Type t = typeMap.get(e);
				if (t instanceof PrimitiveType) {
					mv.visitInsn(IASTORE);
				} else {
					mv.visitInsn(AASTORE);
				}
			} else {
				throw new Error(node,
						"Unexpected postfix expression node in \'" + node
								+ "\'");
			}
			return false;
		}

		@Override
		public boolean visit(ClassInstanceCreation node) {
			ClassType ct = (ClassType) typeMap.get(node);
			mv.visitTypeInsn(NEW, ct.name);
			mv.visitInsn(DUP);
			mv.visitMethodInsn(INVOKESPECIAL, ct.name, "<init>", "()V");
			return false;
		}

		@Override
		public boolean visit(ArrayCreation node) {
			boolean hasInitializer = false;
			if (node.dimensions().size() > 0) {
				((ASTNode) node.dimensions().get(0)).accept(this);
			} else {
				hasInitializer = true;
				generateIntConst(node.getInitializer().expressions().size());
			}
			ArrayType at = (ArrayType) typeMap.get(node);
			if (at.baseType instanceof BooleanType) {
				mv.visitIntInsn(NEWARRAY, Opcodes.T_BOOLEAN);
			} else if (at.baseType instanceof IntType) {
				mv.visitIntInsn(NEWARRAY, Opcodes.T_INT);
			} else {
				mv.visitTypeInsn(ANEWARRAY, at.baseType.name.replace('.', '/'));
			}
			if (!hasInitializer) {
				return false;
			}
			int i = 0;
			int opcode = at.baseType instanceof BooleanType ? BASTORE
					: at.baseType instanceof IntType ? IASTORE : AASTORE;
			for (Object o : node.getInitializer().expressions()) {
				mv.visitInsn(DUP);
				generateIntConst(i);
				((ASTNode) o).accept(this);
				mv.visitInsn(opcode);
				i++;
			}
			return false;
		}

		@Override
		public boolean visit(FieldAccess node) {
			node.getExpression().accept(this);
			FieldDeclaration fd = (FieldDeclaration) symbolMap.get(node);
			Type t = typeMap.get(fd);
			String className = ((TypeDeclaration) fd.getParent()).getName()
					.getIdentifier();
			mv.visitFieldInsn(GETFIELD, className, node.getName()
					.getIdentifier(), convertType(t));
			return false;
		}

		@Override
		public boolean visit(ArrayAccess node) {
			node.getArray().accept(this);
			node.getIndex().accept(this);
			Type t = typeMap.get(node);
			if (t instanceof BooleanType) {
				mv.visitInsn(BALOAD);
			} else if (t instanceof IntType) {
				mv.visitInsn(IALOAD);
			} else {
				mv.visitInsn(AALOAD);
			}
			return false;
		}

		@Override
		public boolean visit(ConditionalExpression node) {
			Label elseLabel = new Label();
			Label endLabel = new Label();
			node.getExpression().accept(this);
			mv.visitJumpInsn(IFEQ, elseLabel);
			node.getThenExpression().accept(this);
			mv.visitJumpInsn(GOTO, endLabel);
			mv.visitLabel(elseLabel);
			node.getElseExpression().accept(this);
			mv.visitLabel(endLabel);
			return false;
		}

		@Override
		public boolean visit(NullLiteral node) {
			mv.visitInsn(ACONST_NULL);
			return false;
		}

		@Override
		protected void dispose() {
			super.dispose();
			classMap = null;
			fieldMap = null;
		}

		/**
		 * Determines whether a {@link List} of {@link Modifier}s has a public
		 * modifier (a {@link Modifier}'s whose {@link ModifierKeyword} is
		 * {@link ModifierKeyword.PUBLIC_KEYWORD}).
		 * 
		 * @param modifiers
		 * @return True, if the {@link List} contains a public modifier.
		 */
		protected boolean hasPublicModifier(List modifiers) {
			for (Object o : modifiers) {
				if (o instanceof Modifier
						&& ((Modifier) o).getKeyword() == ModifierKeyword.PUBLIC_KEYWORD) {
					return true;
				}
			}
			return false;
		}
	}
}
