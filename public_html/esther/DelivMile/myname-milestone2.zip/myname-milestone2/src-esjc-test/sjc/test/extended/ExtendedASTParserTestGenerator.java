package sjc.test.extended;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;

public class ExtendedASTParserTestGenerator {
	public static void main(String[] args) throws Exception
	{
		FileReader fr = new FileReader("src-esjc-test/sjc/test/extended/ExtendedASTParserTest.template");
		LineNumberReader lnr = new LineNumberReader(fr);
		String s = lnr.readLine();
		while (s != null)
		{
			System.out.println(s);
			s = lnr.readLine();
		}
		
		fr.close();
		File f = new File("src-examples");
		for (String filename : f.list())
		{
			String filenameNoExt = filename.substring(0, filename.length() - ".java".length());
			if (filenameNoExt.startsWith("ParseFail")) {
			    System.out.println("\tpublic void test" + filenameNoExt + "() { testFail(\"src-examples/" + filename + "\"); }");			
			} else {
			    System.out.println("\tpublic void test" + filenameNoExt + "() { testPass(\"src-examples/" + filename + "\"); }");
			}
			System.out.println();
		}
		System.out.println("\n}");
		System.out.flush();
	}
}