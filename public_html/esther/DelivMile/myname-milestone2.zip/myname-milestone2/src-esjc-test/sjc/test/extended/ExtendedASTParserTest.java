package sjc.test.extended;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.ArrayList;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.antlr.runtime.ANTLRFileStream;
import org.antlr.runtime.CommonTokenStream;

import sjc.parser.extended.ExtendedStaticJavaASTLexer;
import sjc.parser.extended.ExtendedStaticJavaASTParser;
import bmsi.util.Diff;
import bmsi.util.DiffPrint;

public class ExtendedASTParserTest extends TestCase
{
    public static void testPass(String filename)
    {
    	PrintWriter pw = new PrintWriter(System.out);
    	System.out.println("*** Begin test: " + filename);
        try {
        	String result;
        	Object[] expectedStrings;
        	{
        		ANTLRFileStream afs = new ANTLRFileStream(filename);
        		ExtendedStaticJavaASTLexer esjl = new ExtendedStaticJavaASTLexer(afs);
        		CommonTokenStream cts = new CommonTokenStream(esjl);
        		ExtendedStaticJavaASTParser esjp = new ExtendedStaticJavaASTParser(cts);
        		result=esjp.compilationUnit().toString();
        	}
        	{
        		ArrayList<Object> list = new ArrayList<Object>();
	        	FileReader fr = new FileReader(filename + ".ast");
	        	BufferedReader br = new BufferedReader(fr);
	        	String temp = br.readLine();
	        	while (temp != null)
	        	{
	        		list.add(temp);
	        		temp = br.readLine();
	        	}
	        	expectedStrings = list.toArray();
	        	fr.close();
        	}
        	Object[] resultStrings = getLines(result);
        	Diff diff = new Diff(resultStrings, expectedStrings);
            Diff.change script = diff.diff_2(false);
            DiffPrint.Base p = new DiffPrint.UnifiedPrint(resultStrings, expectedStrings);
            if (script == null)
        	{
            	System.out.println("*** End PASSING test: " + filename);
            	System.out.println();
            	System.out.flush();
        	}
        	else
        	{
                p.setOutput(pw);
                p.print_script(script);        	
                System.err.flush();
            	System.out.println("*** End FAILING testing: " + filename);
            	System.out.println();
            	System.out.flush();
                Assert.assertTrue("Mismatched AST output", false);
        	}
            
        } catch (Exception e) {
        	System.out.println("Exception "+e+" caught while processing " + filename);
        	System.out.println("*** End FAILING testing: " + filename);
        	System.out.println();
            System.out.flush();
            Assert.assertTrue(e.getMessage(), false);
        }
    }
    
	private static Object[] getLines(String s) throws Exception {
		ArrayList<Object> list = new ArrayList<Object>();
		BufferedReader br = new BufferedReader(new StringReader(s));
		String temp = br.readLine();
		while (temp != null)
		{
			list.add(temp);
			temp = br.readLine();
		}
		br.close();
		return list.toArray();
	}

	public void testAEEmptyTest() { testPass("src-examples/AEEmptyTest.java"); }

	public void testArrayAccessVariable() { testPass("src-examples/ArrayAccessVariable.java"); }

	public void testArrayCreation() { testPass("src-examples/ArrayCreation.java"); }

	public void testArrayCreation2() { testPass("src-examples/ArrayCreation2.java"); }

	public void testArrayIndex() { testPass("src-examples/ArrayIndex.java"); }

	public void testArrayIndexConstant() { testPass("src-examples/ArrayIndexConstant.java"); }

	public void testAssignNullToObject() { testPass("src-examples/AssignNullToObject.java"); }

	public void testBasicTypes() { testPass("src-examples/BasicTypes.java"); }

	public void testBinaryOps() { testPass("src-examples/BinaryOps.java"); }

	public void testBooleanAnd() { testPass("src-examples/BooleanAnd.java"); }

	public void testBooleanLiteral() { testPass("src-examples/BooleanLiteral.java"); }

	public void testBooleanNot() { testPass("src-examples/BooleanNot.java"); }

	public void testBooleanOr() { testPass("src-examples/BooleanOr.java"); }

	public void testConditionalFalse() { testPass("src-examples/ConditionalFalse.java"); }

	public void testConditionalTrue() { testPass("src-examples/ConditionalTrue.java"); }

	public void testConditionalWithNull() { testPass("src-examples/ConditionalWithNull.java"); }

	public void testCreateIntArrayWithIntAndIntLiteralInitializers() { testPass("src-examples/CreateIntArrayWithIntAndIntLiteralInitializers.java"); }

	public void testDoWhile() { testPass("src-examples/DoWhile.java"); }

	public void testDoWhileWithBooleanArrayAccessCondition() { testPass("src-examples/DoWhileWithBooleanArrayAccessCondition.java"); }

	public void testFactorial() { testPass("src-examples/Factorial.java"); }

	public void testFieldAccess() { testPass("src-examples/FieldAccess.java"); }

	public void testFor() { testPass("src-examples/For.java"); }

	public void testForBooleanArrayAccessConditional() { testPass("src-examples/ForBooleanArrayAccessConditional.java"); }

	public void testForBooleanMemberAccessConditional() { testPass("src-examples/ForBooleanMemberAccessConditional.java"); }

	public void testForCondOnly() { testPass("src-examples/ForCondOnly.java"); }

	public void testForEmpty() { testPass("src-examples/ForEmpty.java"); }

	public void testForFull() { testPass("src-examples/ForFull.java"); }

	public void testForIncOrDecOnly() { testPass("src-examples/ForIncOrDecOnly.java"); }

	public void testForInitOnly() { testPass("src-examples/ForInitOnly.java"); }

	public void testForLoop() { testPass("src-examples/ForLoop.java"); }

	public void testForMissingCond() { testPass("src-examples/ForMissingCond.java"); }

	public void testForMissingIncOrDec() { testPass("src-examples/ForMissingIncOrDec.java"); }

	public void testForMissingInit() { testPass("src-examples/ForMissingInit.java"); }

	public void testForMultipleIncOrDecOnly() { testPass("src-examples/ForMultipleIncOrDecOnly.java"); }

	public void testForMultipleInitAndIncOrDec() { testPass("src-examples/ForMultipleInitAndIncOrDec.java"); }

	public void testForMultipleInitOnly() { testPass("src-examples/ForMultipleInitOnly.java"); }

	public void testForwardClassRefs() { testPass("src-examples/ForwardClassRefs.java"); }

	public void testForwardClassTest() { testPass("src-examples/ForwardClassTest.java"); }

	public void testIf() { testPass("src-examples/If.java"); }

	public void testIfFalseEmpty() { testPass("src-examples/IfFalseEmpty.java"); }

	public void testIfFalseSingle() { testPass("src-examples/IfFalseSingle.java"); }

	public void testIfFalseSingleElseEmpty() { testPass("src-examples/IfFalseSingleElseEmpty.java"); }

	public void testIfFalseSingleElseMultiple() { testPass("src-examples/IfFalseSingleElseMultiple.java"); }

	public void testIfFalseSingleElseSingle() { testPass("src-examples/IfFalseSingleElseSingle.java"); }

	public void testIfTrueEmpty() { testPass("src-examples/IfTrueEmpty.java"); }

	public void testIfTrueEmptyElseEmpty() { testPass("src-examples/IfTrueEmptyElseEmpty.java"); }

	public void testIfTrueMultiple() { testPass("src-examples/IfTrueMultiple.java"); }

	public void testIfTrueSingle() { testPass("src-examples/IfTrueSingle.java"); }

	public void testIfTrueSingleElseEmpty() { testPass("src-examples/IfTrueSingleElseEmpty.java"); }

	public void testIfTrueSingleElseSingle() { testPass("src-examples/IfTrueSingleElseSingle.java"); }

	public void testIncIntArrayAccess() { testPass("src-examples/IncIntArrayAccess.java"); }

	public void testIntAdd() { testPass("src-examples/IntAdd.java"); }

	public void testIntComplement() { testPass("src-examples/IntComplement.java"); }

	public void testIntDivide() { testPass("src-examples/IntDivide.java"); }

	public void testIntEqual() { testPass("src-examples/IntEqual.java"); }

	public void testIntGreaterThan() { testPass("src-examples/IntGreaterThan.java"); }

	public void testIntGreaterThanOrEqual() { testPass("src-examples/IntGreaterThanOrEqual.java"); }

	public void testIntLessThan() { testPass("src-examples/IntLessThan.java"); }

	public void testIntLessThanOrEqual() { testPass("src-examples/IntLessThanOrEqual.java"); }

	public void testIntMultiply() { testPass("src-examples/IntMultiply.java"); }

	public void testIntNegate() { testPass("src-examples/IntNegate.java"); }

	public void testIntNotEqual() { testPass("src-examples/IntNotEqual.java"); }

	public void testIntPlus() { testPass("src-examples/IntPlus.java"); }

	public void testIntPostDecrement() { testPass("src-examples/IntPostDecrement.java"); }

	public void testIntPostIncrement() { testPass("src-examples/IntPostIncrement.java"); }

	public void testIntRemainder() { testPass("src-examples/IntRemainder.java"); }

	public void testIntShiftLeft() { testPass("src-examples/IntShiftLeft.java"); }

	public void testIntShiftRight() { testPass("src-examples/IntShiftRight.java"); }

	public void testIntSubtract() { testPass("src-examples/IntSubtract.java"); }

	public void testIntUnsignedShiftRight() { testPass("src-examples/IntUnsignedShiftRight.java"); }

	public void testNewBasic() { testPass("src-examples/NewBasic.java"); }

	public void testNewID() { testPass("src-examples/NewID.java"); }

	public void testNullArgumentForIntArrayParameter() { testPass("src-examples/NullArgumentForIntArrayParameter.java"); }

	public void testNullEqualsNull() { testPass("src-examples/NullEqualsNull.java"); }

	public void testObjectAEqualsReturnedObjectA() { testPass("src-examples/ObjectAEqualsReturnedObjectA.java"); }

	public void testParens() { testPass("src-examples/Parens.java"); }

	public void testPower() { testPass("src-examples/Power.java"); }

	public void testQueue() { testPass("src-examples/Queue.java"); }

	public void testReturnNullFromIntArrayMethod() { testPass("src-examples/ReturnNullFromIntArrayMethod.java"); }

	public void testSAExample() { testPass("src-examples/SAExample.java"); }

	public void testSymbolTableTest() { testPass("src-examples/SymbolTableTest.java"); }

	public void testSyntaxTorture() { testPass("src-examples/SyntaxTorture.java"); }

	public void testTypeCheckFailAssignAnonymousBooleanArrayToBoolean() { testPass("src-examples/TypeCheckFailAssignAnonymousBooleanArrayToBoolean.java"); }

	public void testTypeCheckFailAssignAnonymousBooleanArrayToInt() { testPass("src-examples/TypeCheckFailAssignAnonymousBooleanArrayToInt.java"); }

	public void testTypeCheckFailAssignAnonymousBooleanArrayToIntArray() { testPass("src-examples/TypeCheckFailAssignAnonymousBooleanArrayToIntArray.java"); }

	public void testTypeCheckFailAssignAnonymousBooleanArrayToObject() { testPass("src-examples/TypeCheckFailAssignAnonymousBooleanArrayToObject.java"); }

	public void testTypeCheckFailAssignAnonymousBooleanArrayToObjectArray() { testPass("src-examples/TypeCheckFailAssignAnonymousBooleanArrayToObjectArray.java"); }

	public void testTypeCheckFailAssignAnonymousIntArrayToBoolean() { testPass("src-examples/TypeCheckFailAssignAnonymousIntArrayToBoolean.java"); }

	public void testTypeCheckFailAssignAnonymousIntArrayToBooleanArray() { testPass("src-examples/TypeCheckFailAssignAnonymousIntArrayToBooleanArray.java"); }

	public void testTypeCheckFailAssignAnonymousIntArrayToInt() { testPass("src-examples/TypeCheckFailAssignAnonymousIntArrayToInt.java"); }

	public void testTypeCheckFailAssignAnonymousIntArrayToObject() { testPass("src-examples/TypeCheckFailAssignAnonymousIntArrayToObject.java"); }

	public void testTypeCheckFailAssignAnonymousIntArrayToObjectArray() { testPass("src-examples/TypeCheckFailAssignAnonymousIntArrayToObjectArray.java"); }

	public void testTypeCheckFailAssignAnonymousObjectAArrayToObjectA() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectAArrayToObjectA.java"); }

	public void testTypeCheckFailAssignAnonymousObjectAArrayToObjectB() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectAArrayToObjectB.java"); }

	public void testTypeCheckFailAssignAnonymousObjectAArrayToObjectBArray() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectAArrayToObjectBArray.java"); }

	public void testTypeCheckFailAssignAnonymousObjectArrayToBoolean() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectArrayToBoolean.java"); }

	public void testTypeCheckFailAssignAnonymousObjectArrayToBooleanArray() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectArrayToBooleanArray.java"); }

	public void testTypeCheckFailAssignAnonymousObjectArrayToInt() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectArrayToInt.java"); }

	public void testTypeCheckFailAssignAnonymousObjectArrayToIntArray() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectArrayToIntArray.java"); }

	public void testTypeCheckFailAssignAnonymousObjectAToObjectB() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectAToObjectB.java"); }

	public void testTypeCheckFailAssignAnonymousObjectAToObjectBArray() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectAToObjectBArray.java"); }

	public void testTypeCheckFailAssignAnonymousObjectToBoolean() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectToBoolean.java"); }

	public void testTypeCheckFailAssignAnonymousObjectToBooleanArray() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectToBooleanArray.java"); }

	public void testTypeCheckFailAssignAnonymousObjectToInt() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectToInt.java"); }

	public void testTypeCheckFailAssignAnonymousObjectToIntArray() { testPass("src-examples/TypeCheckFailAssignAnonymousObjectToIntArray.java"); }

	public void testTypeCheckFailAssignBooleanToInt() { testPass("src-examples/TypeCheckFailAssignBooleanToInt.java"); }

	public void testTypeCheckFailAssignBooleanToIntArray() { testPass("src-examples/TypeCheckFailAssignBooleanToIntArray.java"); }

	public void testTypeCheckFailAssignBooleanToObject() { testPass("src-examples/TypeCheckFailAssignBooleanToObject.java"); }

	public void testTypeCheckFailAssignBooleanToObjectArray() { testPass("src-examples/TypeCheckFailAssignBooleanToObjectArray.java"); }

	public void testTypeCheckFailAssignFalseToInt() { testPass("src-examples/TypeCheckFailAssignFalseToInt.java"); }

	public void testTypeCheckFailAssignFalseToIntArray() { testPass("src-examples/TypeCheckFailAssignFalseToIntArray.java"); }

	public void testTypeCheckFailAssignFalseToObject() { testPass("src-examples/TypeCheckFailAssignFalseToObject.java"); }

	public void testTypeCheckFailAssignFalseToObjectArray() { testPass("src-examples/TypeCheckFailAssignFalseToObjectArray.java"); }

	public void testTypeCheckFailAssignNamedBooleanArrayToBoolean() { testPass("src-examples/TypeCheckFailAssignNamedBooleanArrayToBoolean.java"); }

	public void testTypeCheckFailAssignNamedBooleanArrayToInt() { testPass("src-examples/TypeCheckFailAssignNamedBooleanArrayToInt.java"); }

	public void testTypeCheckFailAssignNamedBooleanArrayToIntArray() { testPass("src-examples/TypeCheckFailAssignNamedBooleanArrayToIntArray.java"); }

	public void testTypeCheckFailAssignNamedBooleanArrayToObject() { testPass("src-examples/TypeCheckFailAssignNamedBooleanArrayToObject.java"); }

	public void testTypeCheckFailAssignNamedBooleanArrayToObjectArray() { testPass("src-examples/TypeCheckFailAssignNamedBooleanArrayToObjectArray.java"); }

	public void testTypeCheckFailAssignNamedIntArrayToBoolean() { testPass("src-examples/TypeCheckFailAssignNamedIntArrayToBoolean.java"); }

	public void testTypeCheckFailAssignNamedIntArrayToBooleanArray() { testPass("src-examples/TypeCheckFailAssignNamedIntArrayToBooleanArray.java"); }

	public void testTypeCheckFailAssignNamedIntArrayToInt() { testPass("src-examples/TypeCheckFailAssignNamedIntArrayToInt.java"); }

	public void testTypeCheckFailAssignNamedIntArrayToObject() { testPass("src-examples/TypeCheckFailAssignNamedIntArrayToObject.java"); }

	public void testTypeCheckFailAssignNamedIntArrayToObjectArray() { testPass("src-examples/TypeCheckFailAssignNamedIntArrayToObjectArray.java"); }

	public void testTypeCheckFailAssignNamedObjectAArrayToObjectA() { testPass("src-examples/TypeCheckFailAssignNamedObjectAArrayToObjectA.java"); }

	public void testTypeCheckFailAssignNamedObjectAArrayToObjectB() { testPass("src-examples/TypeCheckFailAssignNamedObjectAArrayToObjectB.java"); }

	public void testTypeCheckFailAssignNamedObjectAArrayToObjectBArray() { testPass("src-examples/TypeCheckFailAssignNamedObjectAArrayToObjectBArray.java"); }

	public void testTypeCheckFailAssignNamedObjectArrayToBoolean() { testPass("src-examples/TypeCheckFailAssignNamedObjectArrayToBoolean.java"); }

	public void testTypeCheckFailAssignNamedObjectArrayToBooleanArray() { testPass("src-examples/TypeCheckFailAssignNamedObjectArrayToBooleanArray.java"); }

	public void testTypeCheckFailAssignNamedObjectArrayToInt() { testPass("src-examples/TypeCheckFailAssignNamedObjectArrayToInt.java"); }

	public void testTypeCheckFailAssignNamedObjectArrayToIntArray() { testPass("src-examples/TypeCheckFailAssignNamedObjectArrayToIntArray.java"); }

	public void testTypeCheckFailAssignNamedObjectAToObjectB() { testPass("src-examples/TypeCheckFailAssignNamedObjectAToObjectB.java"); }

	public void testTypeCheckFailAssignNamedObjectAToObjectBArray() { testPass("src-examples/TypeCheckFailAssignNamedObjectAToObjectBArray.java"); }

	public void testTypeCheckFailAssignNamedObjectToBoolean() { testPass("src-examples/TypeCheckFailAssignNamedObjectToBoolean.java"); }

	public void testTypeCheckFailAssignNamedObjectToBooleanArray() { testPass("src-examples/TypeCheckFailAssignNamedObjectToBooleanArray.java"); }

	public void testTypeCheckFailAssignNamedObjectToInt() { testPass("src-examples/TypeCheckFailAssignNamedObjectToInt.java"); }

	public void testTypeCheckFailAssignNamedObjectToIntArray() { testPass("src-examples/TypeCheckFailAssignNamedObjectToIntArray.java"); }

	public void testTypeCheckFailAssignTrueToInt() { testPass("src-examples/TypeCheckFailAssignTrueToInt.java"); }

	public void testTypeCheckFailAssignTrueToIntArray() { testPass("src-examples/TypeCheckFailAssignTrueToIntArray.java"); }

	public void testTypeCheckFailAssignTrueToObject() { testPass("src-examples/TypeCheckFailAssignTrueToObject.java"); }

	public void testTypeCheckFailAssignTrueToObjectArray() { testPass("src-examples/TypeCheckFailAssignTrueToObjectArray.java"); }

	public void testTypeCheckFailBooleanArrayWithBooleanAccess() { testPass("src-examples/TypeCheckFailBooleanArrayWithBooleanAccess.java"); }

	public void testTypeCheckFailComplementBadExpression() { testPass("src-examples/TypeCheckFailComplementBadExpression.java"); }

	public void testTypeCheckFailComplementBoolean() { testPass("src-examples/TypeCheckFailComplementBoolean.java"); }

	public void testTypeCheckFailComplementNull() { testPass("src-examples/TypeCheckFailComplementNull.java"); }

	public void testTypeCheckFailComplementTrue() { testPass("src-examples/TypeCheckFailComplementTrue.java"); }

	public void testTypeCheckFailConditionalAssignIntToBool() { testPass("src-examples/TypeCheckFailConditionalAssignIntToBool.java"); }

	public void testTypeCheckFailConditionalAssignObjectAToObjectAArray() { testPass("src-examples/TypeCheckFailConditionalAssignObjectAToObjectAArray.java"); }

	public void testTypeCheckFailCreateArrayWithBooleanLength() { testPass("src-examples/TypeCheckFailCreateArrayWithBooleanLength.java"); }

	public void testTypeCheckFailCreateArrayWithFalseLength() { testPass("src-examples/TypeCheckFailCreateArrayWithFalseLength.java"); }

	public void testTypeCheckFailCreateIntArrayForBooleanArray() { testPass("src-examples/TypeCheckFailCreateIntArrayForBooleanArray.java"); }

	public void testTypeCheckFailCreateIntArrayForInt() { testPass("src-examples/TypeCheckFailCreateIntArrayForInt.java"); }

	public void testTypeCheckFailCreateIntArrayWithBooleanInitializer() { testPass("src-examples/TypeCheckFailCreateIntArrayWithBooleanInitializer.java"); }

	public void testTypeCheckFailCreateIntArrayWithIntAndBooleanInitializers() { testPass("src-examples/TypeCheckFailCreateIntArrayWithIntAndBooleanInitializers.java"); }

	public void testTypeCheckFailCreateObjectAForObjectAArray() { testPass("src-examples/TypeCheckFailCreateObjectAForObjectAArray.java"); }

	public void testTypeCheckFailCreateObjectBForObjectA() { testPass("src-examples/TypeCheckFailCreateObjectBForObjectA.java"); }

	public void testTypeCheckFailDoWhileWithBooleanArrayCondition() { testPass("src-examples/TypeCheckFailDoWhileWithBooleanArrayCondition.java"); }

	public void testTypeCheckFailForBooleanArrayConditional() { testPass("src-examples/TypeCheckFailForBooleanArrayConditional.java"); }

	public void testTypeCheckFailForIntCondtional() { testPass("src-examples/TypeCheckFailForIntCondtional.java"); }

	public void testTypeCheckFailIncBoolean() { testPass("src-examples/TypeCheckFailIncBoolean.java"); }

	public void testTypeCheckFailIncIntArray() { testPass("src-examples/TypeCheckFailIncIntArray.java"); }

	public void testTypeCheckFailIntArgumentForBooleanParameter() { testPass("src-examples/TypeCheckFailIntArgumentForBooleanParameter.java"); }

	public void testTypeCheckFailIntConditional() { testPass("src-examples/TypeCheckFailIntConditional.java"); }

	public void testTypeCheckFailIntEqualsBoolean() { testPass("src-examples/TypeCheckFailIntEqualsBoolean.java"); }

	public void testTypeCheckFailIntEqualsIntArray() { testPass("src-examples/TypeCheckFailIntEqualsIntArray.java"); }

	public void testTypeCheckFailIntLiteralConditional() { testPass("src-examples/TypeCheckFailIntLiteralConditional.java"); }

	public void testTypeCheckFailIntPlusBadExpression() { testPass("src-examples/TypeCheckFailIntPlusBadExpression.java"); }

	public void testTypeCheckFailIntPlusObject() { testPass("src-examples/TypeCheckFailIntPlusObject.java"); }

	public void testTypeCheckFailNegateBadExpression() { testPass("src-examples/TypeCheckFailNegateBadExpression.java"); }

	public void testTypeCheckFailNegateBoolean() { testPass("src-examples/TypeCheckFailNegateBoolean.java"); }

	public void testTypeCheckFailNegateIntArray() { testPass("src-examples/TypeCheckFailNegateIntArray.java"); }

	public void testTypeCheckFailNegateObject() { testPass("src-examples/TypeCheckFailNegateObject.java"); }

	public void testTypeCheckFailNullEqualsVoid() { testPass("src-examples/TypeCheckFailNullEqualsVoid.java"); }

	public void testTypeCheckFailObjectAEqualsReturnedObjectB() { testPass("src-examples/TypeCheckFailObjectAEqualsReturnedObjectB.java"); }

	public void testTypeCheckFailObjectEqualsBoolean() { testPass("src-examples/TypeCheckFailObjectEqualsBoolean.java"); }

	public void testTypeCheckFailReturnIntFromBooleanMethod() { testPass("src-examples/TypeCheckFailReturnIntFromBooleanMethod.java"); }

	public void testTypeCheckFailReturnIntLiteralFromVoidMethod() { testPass("src-examples/TypeCheckFailReturnIntLiteralFromVoidMethod.java"); }

	public void testTypeCheckFailTooFewMethodArguments() { testPass("src-examples/TypeCheckFailTooFewMethodArguments.java"); }

	public void testTypeCheckFailTooManyMethodArguments() { testPass("src-examples/TypeCheckFailTooManyMethodArguments.java"); }

	public void testTypeCheckFailUndefinedClass() { testPass("src-examples/TypeCheckFailUndefinedClass.java"); }

	public void testTypesArray() { testPass("src-examples/TypesArray.java"); }

	public void testTypesBasic() { testPass("src-examples/TypesBasic.java"); }

	public void testTypesID() { testPass("src-examples/TypesID.java"); }

	public void testUnaryOps() { testPass("src-examples/UnaryOps.java"); }

	public void testWhile() { testPass("src-examples/While.java"); }

	public void testWhileInitRD() { testPass("src-examples/WhileInitRD.java"); }

}
