// $ANTLR 3.0.1 /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g 2007-10-01 20:13:21

package sjc.parser.extended;

import org.eclipse.jdt.core.dom.*;

import java.math.BigInteger;

import java.util.ArrayList;

/**
 * StaticJava parser.
 *
 * @author robby
 */


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
public class ExtendedStaticJavaASTParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ID", "NUM_INT", "WS", "'public'", "'class'", "'{'", "'}'", "'static'", "'void'", "'('", "'['", "']'", "')'", "';'", "'boolean'", "'int'", "','", "'='", "'if'", "'else'", "'while'", "'return'", "'||'", "'&&'", "'!='", "'=='", "'<'", "'>'", "'<='", "'>='", "'+'", "'-'", "'*'", "'/'", "'%'", "'!'", "'true'", "'false'", "'.'"
    };
    public static final int NUM_INT=5;
    public static final int WS=6;
    public static final int EOF=-1;
    public static final int ID=4;

        public ExtendedStaticJavaASTParser(TokenStream input) {
            super(input);
            ruleMemo = new HashMap[70+1];
         }
        

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "/Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g"; }


    	protected AST ast = AST.newAST(AST.JLS3);
    	
    	protected void mismatch(IntStream input, int ttype, BitSet follow) 
    	throws RecognitionException
    {
    	throw new MismatchedTokenException(ttype, input);
    }

    public void recoverFromMismatchedSet(IntStream input, RecognitionException e, BitSet follow)
    	throws RecognitionException
    {
    	throw e;
    }



    // $ANTLR start compilationUnit
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:55:1: compilationUnit returns [CompilationUnit result = ast.newCompilationUnit()] : td= classDefinition EOF ;
    public final CompilationUnit compilationUnit() throws RecognitionException {
        CompilationUnit result =  ast.newCompilationUnit();
        int compilationUnit_StartIndex = input.index();
        TypeDeclaration td = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 1) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:56:2: (td= classDefinition EOF )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:56:4: td= classDefinition EOF
            {
            pushFollow(FOLLOW_classDefinition_in_compilationUnit59);
            td=classDefinition();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result.types().add(td); 
            }
            match(input,EOF,FOLLOW_EOF_in_compilationUnit82); if (failed) return result;

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 1, compilationUnit_StartIndex); }
        }
        return result;
    }
    // $ANTLR end compilationUnit


    // $ANTLR start classDefinition
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:60:1: classDefinition returns [TypeDeclaration result = ast.newTypeDeclaration()] : 'public' 'class' ID '{' md= mainMethodDeclaration (fd= fieldDeclaration | md= methodDeclaration )* '}' ;
    public final TypeDeclaration classDefinition() throws RecognitionException {
        TypeDeclaration result =  ast.newTypeDeclaration();
        int classDefinition_StartIndex = input.index();
        Token ID1=null;
        MethodDeclaration md = null;

        FieldDeclaration fd = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 2) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:61:2: ( 'public' 'class' ID '{' md= mainMethodDeclaration (fd= fieldDeclaration | md= methodDeclaration )* '}' )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:61:4: 'public' 'class' ID '{' md= mainMethodDeclaration (fd= fieldDeclaration | md= methodDeclaration )* '}'
            {
            match(input,7,FOLLOW_7_in_classDefinition98); if (failed) return result;
            if ( backtracking==0 ) {
               result.modifiers().add(ast.newModifier(Modifier.ModifierKeyword.PUBLIC_KEYWORD)); 
            }
            match(input,8,FOLLOW_8_in_classDefinition128); if (failed) return result;
            ID1=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_classDefinition130); if (failed) return result;
            match(input,9,FOLLOW_9_in_classDefinition132); if (failed) return result;
            if ( backtracking==0 ) {
               result.setName(ast.newSimpleName(ID1.getText())); 
            }
            pushFollow(FOLLOW_mainMethodDeclaration_in_classDefinition166);
            md=mainMethodDeclaration();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result.bodyDeclarations().add(md); 
            }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:64:3: (fd= fieldDeclaration | md= methodDeclaration )*
            loop1:
            do {
                int alt1=3;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11) ) {
                    switch ( input.LA(2) ) {
                    case 12:
                        {
                        alt1=2;
                        }
                        break;
                    case 18:
                        {
                        int LA1_4 = input.LA(3);

                        if ( (LA1_4==ID) ) {
                            int LA1_6 = input.LA(4);

                            if ( (LA1_6==17) ) {
                                alt1=1;
                            }
                            else if ( (LA1_6==13) ) {
                                alt1=2;
                            }


                        }


                        }
                        break;
                    case 19:
                        {
                        int LA1_5 = input.LA(3);

                        if ( (LA1_5==ID) ) {
                            int LA1_6 = input.LA(4);

                            if ( (LA1_6==17) ) {
                                alt1=1;
                            }
                            else if ( (LA1_6==13) ) {
                                alt1=2;
                            }


                        }


                        }
                        break;

                    }

                }


                switch (alt1) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:64:5: fd= fieldDeclaration
            	    {
            	    pushFollow(FOLLOW_fieldDeclaration_in_classDefinition188);
            	    fd=fieldDeclaration();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       result.bodyDeclarations().add(fd); 
            	    }

            	    }
            	    break;
            	case 2 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:65:5: md= methodDeclaration
            	    {
            	    pushFollow(FOLLOW_methodDeclaration_in_classDefinition216);
            	    md=methodDeclaration();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       result.bodyDeclarations().add(md); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            match(input,10,FOLLOW_10_in_classDefinition245); if (failed) return result;

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 2, classDefinition_StartIndex); }
        }
        return result;
    }
    // $ANTLR end classDefinition


    // $ANTLR start mainMethodDeclaration
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:71:1: mainMethodDeclaration returns [MethodDeclaration result = ast.newMethodDeclaration()] : 'public' 'static' 'void' id1= ID {...}? '(' id2= ID {...}? '[' ']' id3= ID ')' '{' b= methodBody '}' ;
    public final MethodDeclaration mainMethodDeclaration() throws RecognitionException {
        MethodDeclaration result =  ast.newMethodDeclaration();
        int mainMethodDeclaration_StartIndex = input.index();
        Token id1=null;
        Token id2=null;
        Token id3=null;
        Block b = null;



        	SingleVariableDeclaration svd = ast.newSingleVariableDeclaration();

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 3) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:75:2: ( 'public' 'static' 'void' id1= ID {...}? '(' id2= ID {...}? '[' ']' id3= ID ')' '{' b= methodBody '}' )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:75:4: 'public' 'static' 'void' id1= ID {...}? '(' id2= ID {...}? '[' ']' id3= ID ')' '{' b= methodBody '}'
            {
            match(input,7,FOLLOW_7_in_mainMethodDeclaration266); if (failed) return result;
            if ( backtracking==0 ) {
               result.modifiers().add(ast.newModifier(Modifier.ModifierKeyword.PUBLIC_KEYWORD)); 
            }
            match(input,11,FOLLOW_11_in_mainMethodDeclaration303); if (failed) return result;
            if ( backtracking==0 ) {
               result.modifiers().add(ast.newModifier(Modifier.ModifierKeyword.STATIC_KEYWORD)); 
            }
            match(input,12,FOLLOW_12_in_mainMethodDeclaration340); if (failed) return result;
            if ( backtracking==0 ) {
               result.setReturnType2(ast.newPrimitiveType(PrimitiveType.VOID)); 
            }
            id1=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_mainMethodDeclaration381); if (failed) return result;
            if ( !("main".equals(id1.getText())) ) {
                if (backtracking>0) {failed=true; return result;}
                throw new FailedPredicateException(input, "mainMethodDeclaration", "\"main\".equals($id1.text)");
            }
            if ( backtracking==0 ) {
               result.setName(ast.newSimpleName("main")); 
            }
            match(input,13,FOLLOW_13_in_mainMethodDeclaration395); if (failed) return result;
            id2=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_mainMethodDeclaration402); if (failed) return result;
            if ( !("String".equals(id2.getText())) ) {
                if (backtracking>0) {failed=true; return result;}
                throw new FailedPredicateException(input, "mainMethodDeclaration", "\"String\".equals($id2.text)");
            }
            if ( backtracking==0 ) {
               svd.setType(ast.newArrayType(ast.newSimpleType(ast.newSimpleName("String")))); 
            }
            match(input,14,FOLLOW_14_in_mainMethodDeclaration413); if (failed) return result;
            match(input,15,FOLLOW_15_in_mainMethodDeclaration415); if (failed) return result;
            id3=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_mainMethodDeclaration419); if (failed) return result;
            if ( backtracking==0 ) {
               svd.setName(ast.newSimpleName(id3.getText()));
              		                                          result.parameters().add(svd); 
            }
            match(input,16,FOLLOW_16_in_mainMethodDeclaration450); if (failed) return result;
            match(input,9,FOLLOW_9_in_mainMethodDeclaration452); if (failed) return result;
            pushFollow(FOLLOW_methodBody_in_mainMethodDeclaration456);
            b=methodBody();
            _fsp--;
            if (failed) return result;
            match(input,10,FOLLOW_10_in_mainMethodDeclaration458); if (failed) return result;
            if ( backtracking==0 ) {
               result.setBody(b); 
            }

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 3, mainMethodDeclaration_StartIndex); }
        }
        return result;
    }
    // $ANTLR end mainMethodDeclaration


    // $ANTLR start fieldDeclaration
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:87:1: fieldDeclaration returns [FieldDeclaration result = null] : 'static' fieldType= type ID ';' ;
    public final FieldDeclaration fieldDeclaration() throws RecognitionException {
        FieldDeclaration result =  null;
        int fieldDeclaration_StartIndex = input.index();
        Token ID2=null;
        Type fieldType = null;



        	VariableDeclarationFragment vdf = ast.newVariableDeclarationFragment();;
        	result = ast.newFieldDeclaration(vdf);

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 4) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:92:2: ( 'static' fieldType= type ID ';' )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:92:4: 'static' fieldType= type ID ';'
            {
            match(input,11,FOLLOW_11_in_fieldDeclaration496); if (failed) return result;
            if ( backtracking==0 ) {
               result.modifiers().add(ast.newModifier(Modifier.ModifierKeyword.STATIC_KEYWORD)); 
            }
            pushFollow(FOLLOW_type_in_fieldDeclaration536);
            fieldType=type();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result.setType(fieldType); 
            }
            ID2=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_fieldDeclaration568); if (failed) return result;
            if ( backtracking==0 ) {
               vdf.setName(ast.newSimpleName(ID2.getText())); 
            }
            match(input,17,FOLLOW_17_in_fieldDeclaration611); if (failed) return result;

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 4, fieldDeclaration_StartIndex); }
        }
        return result;
    }
    // $ANTLR end fieldDeclaration


    // $ANTLR start methodDeclaration
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:98:1: methodDeclaration returns [MethodDeclaration result = ast.newMethodDeclaration()] : 'static' retType= returnType ID '(' (sdvs= params )? ')' '{' b= methodBody '}' ;
    public final MethodDeclaration methodDeclaration() throws RecognitionException {
        MethodDeclaration result =  ast.newMethodDeclaration();
        int methodDeclaration_StartIndex = input.index();
        Token ID3=null;
        Type retType = null;

        ArrayList<SingleVariableDeclaration> sdvs = null;

        Block b = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 5) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:99:2: ( 'static' retType= returnType ID '(' (sdvs= params )? ')' '{' b= methodBody '}' )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:99:4: 'static' retType= returnType ID '(' (sdvs= params )? ')' '{' b= methodBody '}'
            {
            match(input,11,FOLLOW_11_in_methodDeclaration627); if (failed) return result;
            if ( backtracking==0 ) {
               result.modifiers().add(ast.newModifier(Modifier.ModifierKeyword.STATIC_KEYWORD)); 
            }
            pushFollow(FOLLOW_returnType_in_methodDeclaration667);
            retType=returnType();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result.setReturnType2(retType); 
            }
            ID3=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_methodDeclaration694); if (failed) return result;
            match(input,13,FOLLOW_13_in_methodDeclaration696); if (failed) return result;
            if ( backtracking==0 ) {
               result.setName(ast.newSimpleName(ID3.getText())); 
            }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:102:3: (sdvs= params )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( ((LA2_0>=18 && LA2_0<=19)) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:103:4: sdvs= params
                    {
                    pushFollow(FOLLOW_params_in_methodDeclaration739);
                    sdvs=params();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       result.parameters().addAll(sdvs); 
                    }

                    }
                    break;

            }

            match(input,16,FOLLOW_16_in_methodDeclaration776); if (failed) return result;
            match(input,9,FOLLOW_9_in_methodDeclaration778); if (failed) return result;
            pushFollow(FOLLOW_methodBody_in_methodDeclaration782);
            b=methodBody();
            _fsp--;
            if (failed) return result;
            match(input,10,FOLLOW_10_in_methodDeclaration784); if (failed) return result;
            if ( backtracking==0 ) {
               result.setBody(b); 
            }

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 5, methodDeclaration_StartIndex); }
        }
        return result;
    }
    // $ANTLR end methodDeclaration


    // $ANTLR start type
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:108:1: type returns [Type result = null] : ( 'boolean' | 'int' );
    public final Type type() throws RecognitionException {
        Type result =  null;
        int type_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 6) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:109:2: ( 'boolean' | 'int' )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==18) ) {
                alt3=1;
            }
            else if ( (LA3_0==19) ) {
                alt3=2;
            }
            else {
                if (backtracking>0) {failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("108:1: type returns [Type result = null] : ( 'boolean' | 'int' );", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:109:4: 'boolean'
                    {
                    match(input,18,FOLLOW_18_in_type817); if (failed) return result;
                    if ( backtracking==0 ) {
                       result = ast.newPrimitiveType(PrimitiveType.BOOLEAN); 
                    }

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:110:4: 'int'
                    {
                    match(input,19,FOLLOW_19_in_type854); if (failed) return result;
                    if ( backtracking==0 ) {
                       result = ast.newPrimitiveType(PrimitiveType.INT); 
                    }

                    }
                    break;

            }
        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 6, type_StartIndex); }
        }
        return result;
    }
    // $ANTLR end type


    // $ANTLR start returnType
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:113:1: returnType returns [Type result = null] : ( 'void' | t= type );
    public final Type returnType() throws RecognitionException {
        Type result =  null;
        int returnType_StartIndex = input.index();
        Type t = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 7) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:114:2: ( 'void' | t= type )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==12) ) {
                alt4=1;
            }
            else if ( ((LA4_0>=18 && LA4_0<=19)) ) {
                alt4=2;
            }
            else {
                if (backtracking>0) {failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("113:1: returnType returns [Type result = null] : ( 'void' | t= type );", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:114:4: 'void'
                    {
                    match(input,12,FOLLOW_12_in_returnType906); if (failed) return result;
                    if ( backtracking==0 ) {
                       result = ast.newPrimitiveType(PrimitiveType.VOID); 
                    }

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:115:4: t= type
                    {
                    pushFollow(FOLLOW_type_in_returnType946);
                    t=type();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       result = t; 
                    }

                    }
                    break;

            }
        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 7, returnType_StartIndex); }
        }
        return result;
    }
    // $ANTLR end returnType


    // $ANTLR start params
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:118:1: params returns [ArrayList<SingleVariableDeclaration> result = new ArrayList<SingleVariableDeclaration>()] : svd= param ( ',' svd= param )* ;
    public final ArrayList<SingleVariableDeclaration> params() throws RecognitionException {
        ArrayList<SingleVariableDeclaration> result =  new ArrayList<SingleVariableDeclaration>();
        int params_StartIndex = input.index();
        SingleVariableDeclaration svd = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 8) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:119:2: (svd= param ( ',' svd= param )* )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:119:4: svd= param ( ',' svd= param )*
            {
            pushFollow(FOLLOW_param_in_params999);
            svd=param();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result.add(svd); 
            }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:120:3: ( ',' svd= param )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==20) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:120:5: ',' svd= param
            	    {
            	    match(input,20,FOLLOW_20_in_params1038); if (failed) return result;
            	    pushFollow(FOLLOW_param_in_params1042);
            	    svd=param();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       result.add(svd); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);


            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 8, params_StartIndex); }
        }
        return result;
    }
    // $ANTLR end params


    // $ANTLR start param
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:124:1: param returns [SingleVariableDeclaration result = ast.newSingleVariableDeclaration()] : paramType= type ID ;
    public final SingleVariableDeclaration param() throws RecognitionException {
        SingleVariableDeclaration result =  ast.newSingleVariableDeclaration();
        int param_StartIndex = input.index();
        Token ID4=null;
        Type paramType = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 9) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:125:2: (paramType= type ID )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:125:4: paramType= type ID
            {
            pushFollow(FOLLOW_type_in_param1091);
            paramType=type();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result.setType(paramType); 
            }
            ID4=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_param1122); if (failed) return result;
            if ( backtracking==0 ) {
               result.setName(ast.newSimpleName(ID4.getText())); 
            }

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 9, param_StartIndex); }
        }
        return result;
    }
    // $ANTLR end param


    // $ANTLR start methodBody
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:129:1: methodBody returns [Block result = ast.newBlock()] : (l= localDeclaration )* (s= statement )* ;
    public final Block methodBody() throws RecognitionException {
        Block result =  ast.newBlock();
        int methodBody_StartIndex = input.index();
        VariableDeclarationStatement l = null;

        Statement s = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 10) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:130:2: ( (l= localDeclaration )* (s= statement )* )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:131:3: (l= localDeclaration )* (s= statement )*
            {
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:131:3: (l= localDeclaration )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( ((LA6_0>=18 && LA6_0<=19)) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:131:5: l= localDeclaration
            	    {
            	    pushFollow(FOLLOW_localDeclaration_in_methodBody1184);
            	    l=localDeclaration();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       result.statements().add(l); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:133:3: (s= statement )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==ID||LA7_0==22||(LA7_0>=24 && LA7_0<=25)) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:133:5: s= statement
            	    {
            	    pushFollow(FOLLOW_statement_in_methodBody1218);
            	    s=statement();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       result.statements().add(s); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);


            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 10, methodBody_StartIndex); }
        }
        return result;
    }
    // $ANTLR end methodBody


    // $ANTLR start localDeclaration
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:137:1: localDeclaration returns [VariableDeclarationStatement result = null] : localType= type ID ';' ;
    public final VariableDeclarationStatement localDeclaration() throws RecognitionException {
        VariableDeclarationStatement result =  null;
        int localDeclaration_StartIndex = input.index();
        Token ID5=null;
        Type localType = null;



        	VariableDeclarationFragment vdf = ast.newVariableDeclarationFragment();
        	result = ast.newVariableDeclarationStatement(vdf);

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 11) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:142:2: (localType= type ID ';' )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:142:4: localType= type ID ';'
            {
            pushFollow(FOLLOW_type_in_localDeclaration1273);
            localType=type();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result.setType(localType); 
            }
            ID5=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_localDeclaration1304); if (failed) return result;
            match(input,17,FOLLOW_17_in_localDeclaration1306); if (failed) return result;
            if ( backtracking==0 ) {
               vdf.setName(ast.newSimpleName(ID5.getText())); 
            }

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 11, localDeclaration_StartIndex); }
        }
        return result;
    }
    // $ANTLR end localDeclaration


    // $ANTLR start statement
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:146:1: statement returns [Statement result = null] : (a= assignStatement | i= ifStatement | w= whileStatement | in= invokeExpStatement | r= returnStatement ) ;
    public final Statement statement() throws RecognitionException {
        Statement result =  null;
        int statement_StartIndex = input.index();
        ExpressionStatement a = null;

        IfStatement i = null;

        WhileStatement w = null;

        ExpressionStatement in = null;

        ReturnStatement r = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 12) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:147:2: ( (a= assignStatement | i= ifStatement | w= whileStatement | in= invokeExpStatement | r= returnStatement ) )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:147:4: (a= assignStatement | i= ifStatement | w= whileStatement | in= invokeExpStatement | r= returnStatement )
            {
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:147:4: (a= assignStatement | i= ifStatement | w= whileStatement | in= invokeExpStatement | r= returnStatement )
            int alt8=5;
            switch ( input.LA(1) ) {
            case ID:
                {
                int LA8_1 = input.LA(2);

                if ( (LA8_1==13||LA8_1==42) ) {
                    alt8=4;
                }
                else if ( (LA8_1==21) ) {
                    alt8=1;
                }
                else {
                    if (backtracking>0) {failed=true; return result;}
                    NoViableAltException nvae =
                        new NoViableAltException("147:4: (a= assignStatement | i= ifStatement | w= whileStatement | in= invokeExpStatement | r= returnStatement )", 8, 1, input);

                    throw nvae;
                }
                }
                break;
            case 22:
                {
                alt8=2;
                }
                break;
            case 24:
                {
                alt8=3;
                }
                break;
            case 25:
                {
                alt8=5;
                }
                break;
            default:
                if (backtracking>0) {failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("147:4: (a= assignStatement | i= ifStatement | w= whileStatement | in= invokeExpStatement | r= returnStatement )", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:147:6: a= assignStatement
                    {
                    pushFollow(FOLLOW_assignStatement_in_statement1361);
                    a=assignStatement();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       result = a; 
                    }

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:148:5: i= ifStatement
                    {
                    pushFollow(FOLLOW_ifStatement_in_statement1391);
                    i=ifStatement();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       result = i; 
                    }

                    }
                    break;
                case 3 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:149:5: w= whileStatement
                    {
                    pushFollow(FOLLOW_whileStatement_in_statement1425);
                    w=whileStatement();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       result = w; 
                    }

                    }
                    break;
                case 4 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:150:5: in= invokeExpStatement
                    {
                    pushFollow(FOLLOW_invokeExpStatement_in_statement1456);
                    in=invokeExpStatement();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       result = in; 
                    }

                    }
                    break;
                case 5 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:151:5: r= returnStatement
                    {
                    pushFollow(FOLLOW_returnStatement_in_statement1482);
                    r=returnStatement();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       result = r; 
                    }

                    }
                    break;

            }


            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 12, statement_StartIndex); }
        }
        return result;
    }
    // $ANTLR end statement


    // $ANTLR start assignStatement
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:155:1: assignStatement returns [ExpressionStatement result = null] : ID '=' e= exp ';' ;
    public final ExpressionStatement assignStatement() throws RecognitionException {
        ExpressionStatement result =  null;
        int assignStatement_StartIndex = input.index();
        Token ID6=null;
        Expression e = null;



        	Assignment a = ast.newAssignment();
        	result = ast.newExpressionStatement(a);

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 13) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:160:2: ( ID '=' e= exp ';' )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:160:4: ID '=' e= exp ';'
            {
            ID6=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_assignStatement1529); if (failed) return result;
            if ( backtracking==0 ) {
               a.setLeftHandSide(ast.newSimpleName(ID6.getText())); 
            }
            match(input,21,FOLLOW_21_in_assignStatement1572); if (failed) return result;
            pushFollow(FOLLOW_exp_in_assignStatement1576);
            e=exp();
            _fsp--;
            if (failed) return result;
            match(input,17,FOLLOW_17_in_assignStatement1578); if (failed) return result;
            if ( backtracking==0 ) {
               a.setRightHandSide(e); 
            }

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 13, assignStatement_StartIndex); }
        }
        return result;
    }
    // $ANTLR end assignStatement


    // $ANTLR start ifStatement
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:164:1: ifStatement returns [IfStatement result = ast.newIfStatement()] : 'if' '(' condExp= exp ')' '{' (s= statement )* '}' ( 'else' '{' (s= statement )* '}' )? ;
    public final IfStatement ifStatement() throws RecognitionException {
        IfStatement result =  ast.newIfStatement();
        int ifStatement_StartIndex = input.index();
        Expression condExp = null;

        Statement s = null;



        	Block thenStatement = ast.newBlock();
        	result.setThenStatement(thenStatement);
        	Block elseStatement = ast.newBlock();
        	result.setElseStatement(elseStatement);

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 14) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:171:2: ( 'if' '(' condExp= exp ')' '{' (s= statement )* '}' ( 'else' '{' (s= statement )* '}' )? )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:171:4: 'if' '(' condExp= exp ')' '{' (s= statement )* '}' ( 'else' '{' (s= statement )* '}' )?
            {
            match(input,22,FOLLOW_22_in_ifStatement1626); if (failed) return result;
            match(input,13,FOLLOW_13_in_ifStatement1628); if (failed) return result;
            pushFollow(FOLLOW_exp_in_ifStatement1632);
            condExp=exp();
            _fsp--;
            if (failed) return result;
            match(input,16,FOLLOW_16_in_ifStatement1634); if (failed) return result;
            if ( backtracking==0 ) {
               result.setExpression(condExp); 
            }
            match(input,9,FOLLOW_9_in_ifStatement1655); if (failed) return result;
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:173:3: (s= statement )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==ID||LA9_0==22||(LA9_0>=24 && LA9_0<=25)) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:174:4: s= statement
            	    {
            	    pushFollow(FOLLOW_statement_in_ifStatement1667);
            	    s=statement();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       thenStatement.statements().add(s); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

            match(input,10,FOLLOW_10_in_ifStatement1705); if (failed) return result;
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:177:3: ( 'else' '{' (s= statement )* '}' )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==23) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:177:5: 'else' '{' (s= statement )* '}'
                    {
                    match(input,23,FOLLOW_23_in_ifStatement1711); if (failed) return result;
                    match(input,9,FOLLOW_9_in_ifStatement1713); if (failed) return result;
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:178:4: (s= statement )*
                    loop10:
                    do {
                        int alt10=2;
                        int LA10_0 = input.LA(1);

                        if ( (LA10_0==ID||LA10_0==22||(LA10_0>=24 && LA10_0<=25)) ) {
                            alt10=1;
                        }


                        switch (alt10) {
                    	case 1 :
                    	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:179:5: s= statement
                    	    {
                    	    pushFollow(FOLLOW_statement_in_ifStatement1728);
                    	    s=statement();
                    	    _fsp--;
                    	    if (failed) return result;
                    	    if ( backtracking==0 ) {
                    	       elseStatement.statements().add(s); 
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    break loop10;
                        }
                    } while (true);

                    match(input,10,FOLLOW_10_in_ifStatement1762); if (failed) return result;

                    }
                    break;

            }


            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 14, ifStatement_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ifStatement


    // $ANTLR start whileStatement
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:183:1: whileStatement returns [WhileStatement result = ast.newWhileStatement()] : 'while' '(' condExp= exp ')' '{' (s= statement )* '}' ;
    public final WhileStatement whileStatement() throws RecognitionException {
        WhileStatement result =  ast.newWhileStatement();
        int whileStatement_StartIndex = input.index();
        Expression condExp = null;

        Statement s = null;



        	Block whileBody = ast.newBlock();
        	result.setBody(whileBody);

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 15) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:188:2: ( 'while' '(' condExp= exp ')' '{' (s= statement )* '}' )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:188:4: 'while' '(' condExp= exp ')' '{' (s= statement )* '}'
            {
            match(input,24,FOLLOW_24_in_whileStatement1786); if (failed) return result;
            match(input,13,FOLLOW_13_in_whileStatement1788); if (failed) return result;
            pushFollow(FOLLOW_exp_in_whileStatement1792);
            condExp=exp();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result.setExpression(condExp); 
            }
            match(input,16,FOLLOW_16_in_whileStatement1814); if (failed) return result;
            match(input,9,FOLLOW_9_in_whileStatement1816); if (failed) return result;
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:190:3: (s= statement )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==ID||LA12_0==22||(LA12_0>=24 && LA12_0<=25)) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:191:4: s= statement
            	    {
            	    pushFollow(FOLLOW_statement_in_whileStatement1828);
            	    s=statement();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       whileBody.statements().add(s); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

            match(input,10,FOLLOW_10_in_whileStatement1863); if (failed) return result;

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 15, whileStatement_StartIndex); }
        }
        return result;
    }
    // $ANTLR end whileStatement


    // $ANTLR start invokeExpStatement
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:195:1: invokeExpStatement returns [ExpressionStatement result = null] : mi= invokeExp ';' ;
    public final ExpressionStatement invokeExpStatement() throws RecognitionException {
        ExpressionStatement result =  null;
        int invokeExpStatement_StartIndex = input.index();
        MethodInvocation mi = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 16) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:196:2: (mi= invokeExp ';' )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:196:4: mi= invokeExp ';'
            {
            pushFollow(FOLLOW_invokeExp_in_invokeExpStatement1881);
            mi=invokeExp();
            _fsp--;
            if (failed) return result;
            match(input,17,FOLLOW_17_in_invokeExpStatement1883); if (failed) return result;
            if ( backtracking==0 ) {
               result = ast.newExpressionStatement(mi); 
            }

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 16, invokeExpStatement_StartIndex); }
        }
        return result;
    }
    // $ANTLR end invokeExpStatement


    // $ANTLR start returnStatement
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:199:1: returnStatement returns [ReturnStatement result = ast.newReturnStatement()] : 'return' (e= exp )? ';' ;
    public final ReturnStatement returnStatement() throws RecognitionException {
        ReturnStatement result =  ast.newReturnStatement();
        int returnStatement_StartIndex = input.index();
        Expression e = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 17) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:200:2: ( 'return' (e= exp )? ';' )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:200:4: 'return' (e= exp )? ';'
            {
            match(input,25,FOLLOW_25_in_returnStatement1923); if (failed) return result;
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:201:3: (e= exp )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( ((LA13_0>=ID && LA13_0<=NUM_INT)||LA13_0==13||(LA13_0>=34 && LA13_0<=35)||(LA13_0>=39 && LA13_0<=41)) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:202:4: e= exp
                    {
                    pushFollow(FOLLOW_exp_in_returnStatement1936);
                    e=exp();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       result.setExpression(e); 
                    }

                    }
                    break;

            }

            match(input,17,FOLLOW_17_in_returnStatement1977); if (failed) return result;

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 17, returnStatement_StartIndex); }
        }
        return result;
    }
    // $ANTLR end returnStatement


    // $ANTLR start exp
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:206:1: exp returns [Expression result = null] : e= logicalOrExp ;
    public final Expression exp() throws RecognitionException {
        Expression result =  null;
        int exp_StartIndex = input.index();
        Expression e = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 18) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:207:2: (e= logicalOrExp )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:207:4: e= logicalOrExp
            {
            pushFollow(FOLLOW_logicalOrExp_in_exp1995);
            e=logicalOrExp();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result = e; 
            }

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 18, exp_StartIndex); }
        }
        return result;
    }
    // $ANTLR end exp


    // $ANTLR start logicalOrExp
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:210:1: logicalOrExp returns [Expression result = null] : e= logicalAndExp ( '||' e= logicalAndExp )* ;
    public final Expression logicalOrExp() throws RecognitionException {
        Expression result =  null;
        int logicalOrExp_StartIndex = input.index();
        Expression e = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 19) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:211:2: (e= logicalAndExp ( '||' e= logicalAndExp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:211:4: e= logicalAndExp ( '||' e= logicalAndExp )*
            {
            pushFollow(FOLLOW_logicalAndExp_in_logicalOrExp2039);
            e=logicalAndExp();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result = e; 
            }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:212:3: ( '||' e= logicalAndExp )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==26) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:212:5: '||' e= logicalAndExp
            	    {
            	    match(input,26,FOLLOW_26_in_logicalOrExp2074); if (failed) return result;
            	    pushFollow(FOLLOW_logicalAndExp_in_logicalOrExp2078);
            	    e=logicalAndExp();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       InfixExpression ie = ast.newInfixExpression();
            	      											                        ie.setLeftOperand(result);
            	      											                        ie.setOperator(InfixExpression.Operator.CONDITIONAL_OR);
            	      											                        ie.setRightOperand(e); 
            	      											                        result = ie; 
            	    }

            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);


            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 19, logicalOrExp_StartIndex); }
        }
        return result;
    }
    // $ANTLR end logicalOrExp


    // $ANTLR start logicalAndExp
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:220:1: logicalAndExp returns [Expression result = null] : e= equalityExp ( '&&' e= equalityExp )* ;
    public final Expression logicalAndExp() throws RecognitionException {
        Expression result =  null;
        int logicalAndExp_StartIndex = input.index();
        Expression e = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 20) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:221:2: (e= equalityExp ( '&&' e= equalityExp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:221:4: e= equalityExp ( '&&' e= equalityExp )*
            {
            pushFollow(FOLLOW_equalityExp_in_logicalAndExp2118);
            e=equalityExp();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result = e; 
            }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:222:3: ( '&&' e= equalityExp )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==27) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:222:5: '&&' e= equalityExp
            	    {
            	    match(input,27,FOLLOW_27_in_logicalAndExp2153); if (failed) return result;
            	    pushFollow(FOLLOW_equalityExp_in_logicalAndExp2157);
            	    e=equalityExp();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       InfixExpression ie = ast.newInfixExpression();
            	                                                    ie.setLeftOperand(result);
            	                                                    ie.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
            	                                                    ie.setRightOperand(e); 
            	                                                    result = ie; 
            	    }

            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);


            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 20, logicalAndExp_StartIndex); }
        }
        return result;
    }
    // $ANTLR end logicalAndExp


    // $ANTLR start equalityExp
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:230:1: equalityExp returns [Expression result = null] : e= relationalExp ( ( '!=' | '==' ) e= relationalExp )* ;
    public final Expression equalityExp() throws RecognitionException {
        Expression result =  null;
        int equalityExp_StartIndex = input.index();
        Expression e = null;



        	InfixExpression.Operator op = null;

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 21) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:234:2: (e= relationalExp ( ( '!=' | '==' ) e= relationalExp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:234:4: e= relationalExp ( ( '!=' | '==' ) e= relationalExp )*
            {
            pushFollow(FOLLOW_relationalExp_in_equalityExp2205);
            e=relationalExp();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result = e; 
            }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:235:3: ( ( '!=' | '==' ) e= relationalExp )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( ((LA17_0>=28 && LA17_0<=29)) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:236:4: ( '!=' | '==' ) e= relationalExp
            	    {
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:236:4: ( '!=' | '==' )
            	    int alt16=2;
            	    int LA16_0 = input.LA(1);

            	    if ( (LA16_0==28) ) {
            	        alt16=1;
            	    }
            	    else if ( (LA16_0==29) ) {
            	        alt16=2;
            	    }
            	    else {
            	        if (backtracking>0) {failed=true; return result;}
            	        NoViableAltException nvae =
            	            new NoViableAltException("236:4: ( '!=' | '==' )", 16, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt16) {
            	        case 1 :
            	            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:237:5: '!='
            	            {
            	            match(input,28,FOLLOW_28_in_equalityExp2247); if (failed) return result;
            	            if ( backtracking==0 ) {
            	               op = InfixExpression.Operator.NOT_EQUALS; 
            	            }

            	            }
            	            break;
            	        case 2 :
            	            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:238:6: '=='
            	            {
            	            match(input,29,FOLLOW_29_in_equalityExp2287); if (failed) return result;
            	            if ( backtracking==0 ) {
            	               op = InfixExpression.Operator.EQUALS; 
            	            }

            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_relationalExp_in_equalityExp2333);
            	    e=relationalExp();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       InfixExpression ie = ast.newInfixExpression();
            	      											                        ie.setLeftOperand(result);
            	      											                        ie.setOperator(op);
            	      											                        ie.setRightOperand(e); 
            	      											                        result = ie; 
            	    }

            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);


            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 21, equalityExp_StartIndex); }
        }
        return result;
    }
    // $ANTLR end equalityExp


    // $ANTLR start relationalExp
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:248:1: relationalExp returns [Expression result = null] : e= additiveExp ( ( '<' | '>' | '<=' | '>=' ) e= additiveExp )* ;
    public final Expression relationalExp() throws RecognitionException {
        Expression result =  null;
        int relationalExp_StartIndex = input.index();
        Expression e = null;



        	InfixExpression.Operator op = null;

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 22) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:252:2: (e= additiveExp ( ( '<' | '>' | '<=' | '>=' ) e= additiveExp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:252:4: e= additiveExp ( ( '<' | '>' | '<=' | '>=' ) e= additiveExp )*
            {
            pushFollow(FOLLOW_additiveExp_in_relationalExp2385);
            e=additiveExp();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result = e; 
            }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:253:3: ( ( '<' | '>' | '<=' | '>=' ) e= additiveExp )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( ((LA19_0>=30 && LA19_0<=33)) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:254:4: ( '<' | '>' | '<=' | '>=' ) e= additiveExp
            	    {
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:254:4: ( '<' | '>' | '<=' | '>=' )
            	    int alt18=4;
            	    switch ( input.LA(1) ) {
            	    case 30:
            	        {
            	        alt18=1;
            	        }
            	        break;
            	    case 31:
            	        {
            	        alt18=2;
            	        }
            	        break;
            	    case 32:
            	        {
            	        alt18=3;
            	        }
            	        break;
            	    case 33:
            	        {
            	        alt18=4;
            	        }
            	        break;
            	    default:
            	        if (backtracking>0) {failed=true; return result;}
            	        NoViableAltException nvae =
            	            new NoViableAltException("254:4: ( '<' | '>' | '<=' | '>=' )", 18, 0, input);

            	        throw nvae;
            	    }

            	    switch (alt18) {
            	        case 1 :
            	            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:254:6: '<'
            	            {
            	            match(input,30,FOLLOW_30_in_relationalExp2425); if (failed) return result;
            	            if ( backtracking==0 ) {
            	               op = InfixExpression.Operator.LESS; 
            	            }

            	            }
            	            break;
            	        case 2 :
            	            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:255:6: '>'
            	            {
            	            match(input,31,FOLLOW_31_in_relationalExp2466); if (failed) return result;
            	            if ( backtracking==0 ) {
            	               op = InfixExpression.Operator.GREATER; 
            	            }

            	            }
            	            break;
            	        case 3 :
            	            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:256:6: '<='
            	            {
            	            match(input,32,FOLLOW_32_in_relationalExp2507); if (failed) return result;
            	            if ( backtracking==0 ) {
            	               op = InfixExpression.Operator.LESS_EQUALS; 
            	            }

            	            }
            	            break;
            	        case 4 :
            	            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:257:6: '>='
            	            {
            	            match(input,33,FOLLOW_33_in_relationalExp2547); if (failed) return result;
            	            if ( backtracking==0 ) {
            	               op = InfixExpression.Operator.GREATER_EQUALS; 
            	            }

            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_additiveExp_in_relationalExp2593);
            	    e=additiveExp();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       InfixExpression ie = ast.newInfixExpression();
            	      											                        ie.setLeftOperand(result);
            	      											                        ie.setOperator(op);
            	      											                        ie.setRightOperand(e);
            	      											                        result = ie; 
            	    }

            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);


            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 22, relationalExp_StartIndex); }
        }
        return result;
    }
    // $ANTLR end relationalExp


    // $ANTLR start additiveExp
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:267:1: additiveExp returns [Expression result = null] : e= multiplicativeExp ( ( '+' | '-' ) e= multiplicativeExp )* ;
    public final Expression additiveExp() throws RecognitionException {
        Expression result =  null;
        int additiveExp_StartIndex = input.index();
        Expression e = null;



        	InfixExpression.Operator op = null;

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 23) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:271:2: (e= multiplicativeExp ( ( '+' | '-' ) e= multiplicativeExp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:271:4: e= multiplicativeExp ( ( '+' | '-' ) e= multiplicativeExp )*
            {
            pushFollow(FOLLOW_multiplicativeExp_in_additiveExp2647);
            e=multiplicativeExp();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result = e; 
            }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:272:3: ( ( '+' | '-' ) e= multiplicativeExp )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( ((LA21_0>=34 && LA21_0<=35)) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:273:4: ( '+' | '-' ) e= multiplicativeExp
            	    {
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:273:4: ( '+' | '-' )
            	    int alt20=2;
            	    int LA20_0 = input.LA(1);

            	    if ( (LA20_0==34) ) {
            	        alt20=1;
            	    }
            	    else if ( (LA20_0==35) ) {
            	        alt20=2;
            	    }
            	    else {
            	        if (backtracking>0) {failed=true; return result;}
            	        NoViableAltException nvae =
            	            new NoViableAltException("273:4: ( '+' | '-' )", 20, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt20) {
            	        case 1 :
            	            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:273:6: '+'
            	            {
            	            match(input,34,FOLLOW_34_in_additiveExp2680); if (failed) return result;
            	            if ( backtracking==0 ) {
            	               op = InfixExpression.Operator.PLUS; 
            	            }

            	            }
            	            break;
            	        case 2 :
            	            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:274:6: '-'
            	            {
            	            match(input,35,FOLLOW_35_in_additiveExp2721); if (failed) return result;
            	            if ( backtracking==0 ) {
            	               op = InfixExpression.Operator.MINUS; 
            	            }

            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_multiplicativeExp_in_additiveExp2768);
            	    e=multiplicativeExp();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       InfixExpression ie = ast.newInfixExpression();
            	      			                                        ie.setLeftOperand(result);
            	      											                        ie.setOperator(op);
            	      											                        ie.setRightOperand(e); 
            	      											                        result = ie; 
            	    }

            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);


            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 23, additiveExp_StartIndex); }
        }
        return result;
    }
    // $ANTLR end additiveExp


    // $ANTLR start multiplicativeExp
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:284:1: multiplicativeExp returns [Expression result = null] : e= unaryExp ( ( '*' | '/' | '%' ) e= unaryExp )* ;
    public final Expression multiplicativeExp() throws RecognitionException {
        Expression result =  null;
        int multiplicativeExp_StartIndex = input.index();
        Expression e = null;



        	InfixExpression.Operator op = null;

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 24) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:288:2: (e= unaryExp ( ( '*' | '/' | '%' ) e= unaryExp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:288:4: e= unaryExp ( ( '*' | '/' | '%' ) e= unaryExp )*
            {
            pushFollow(FOLLOW_unaryExp_in_multiplicativeExp2816);
            e=unaryExp();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result = e; 
            }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:289:3: ( ( '*' | '/' | '%' ) e= unaryExp )*
            loop23:
            do {
                int alt23=2;
                int LA23_0 = input.LA(1);

                if ( ((LA23_0>=36 && LA23_0<=38)) ) {
                    alt23=1;
                }


                switch (alt23) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:290:4: ( '*' | '/' | '%' ) e= unaryExp
            	    {
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:290:4: ( '*' | '/' | '%' )
            	    int alt22=3;
            	    switch ( input.LA(1) ) {
            	    case 36:
            	        {
            	        alt22=1;
            	        }
            	        break;
            	    case 37:
            	        {
            	        alt22=2;
            	        }
            	        break;
            	    case 38:
            	        {
            	        alt22=3;
            	        }
            	        break;
            	    default:
            	        if (backtracking>0) {failed=true; return result;}
            	        NoViableAltException nvae =
            	            new NoViableAltException("290:4: ( '*' | '/' | '%' )", 22, 0, input);

            	        throw nvae;
            	    }

            	    switch (alt22) {
            	        case 1 :
            	            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:290:6: '*'
            	            {
            	            match(input,36,FOLLOW_36_in_multiplicativeExp2858); if (failed) return result;
            	            if ( backtracking==0 ) {
            	               op = InfixExpression.Operator.TIMES; 
            	            }

            	            }
            	            break;
            	        case 2 :
            	            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:291:6: '/'
            	            {
            	            match(input,37,FOLLOW_37_in_multiplicativeExp2899); if (failed) return result;
            	            if ( backtracking==0 ) {
            	               op = InfixExpression.Operator.DIVIDE; 
            	            }

            	            }
            	            break;
            	        case 3 :
            	            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:292:6: '%'
            	            {
            	            match(input,38,FOLLOW_38_in_multiplicativeExp2940); if (failed) return result;
            	            if ( backtracking==0 ) {
            	               op = InfixExpression.Operator.REMAINDER; 
            	            }

            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_unaryExp_in_multiplicativeExp2986);
            	    e=unaryExp();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       InfixExpression ie = ast.newInfixExpression();
            	      											                        ie.setLeftOperand(result);
            	      											                        ie.setOperator(op);
            	      											                        ie.setRightOperand(e); 
            	      											                        result = ie; 
            	    }

            	    }
            	    break;

            	default :
            	    break loop23;
                }
            } while (true);


            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 24, multiplicativeExp_StartIndex); }
        }
        return result;
    }
    // $ANTLR end multiplicativeExp


    // $ANTLR start unaryExp
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:302:1: unaryExp returns [Expression result = null] : ( '-' e= unaryExp | '+' e= unaryExp | e= unaryExpNotPlusMinus );
    public final Expression unaryExp() throws RecognitionException {
        Expression result =  null;
        int unaryExp_StartIndex = input.index();
        Expression e = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 25) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:303:2: ( '-' e= unaryExp | '+' e= unaryExp | e= unaryExpNotPlusMinus )
            int alt24=3;
            switch ( input.LA(1) ) {
            case 35:
                {
                alt24=1;
                }
                break;
            case 34:
                {
                alt24=2;
                }
                break;
            case ID:
            case NUM_INT:
            case 13:
            case 39:
            case 40:
            case 41:
                {
                alt24=3;
                }
                break;
            default:
                if (backtracking>0) {failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("302:1: unaryExp returns [Expression result = null] : ( '-' e= unaryExp | '+' e= unaryExp | e= unaryExpNotPlusMinus );", 24, 0, input);

                throw nvae;
            }

            switch (alt24) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:303:4: '-' e= unaryExp
                    {
                    match(input,35,FOLLOW_35_in_unaryExp3036); if (failed) return result;
                    pushFollow(FOLLOW_unaryExp_in_unaryExp3040);
                    e=unaryExp();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       PrefixExpression pe = ast.newPrefixExpression();
                      											                        pe.setOperator(PrefixExpression.Operator.MINUS);
                      											                        pe.setOperand(e);
                      											                        result = pe; 
                    }

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:307:4: '+' e= unaryExp
                    {
                    match(input,34,FOLLOW_34_in_unaryExp3072); if (failed) return result;
                    pushFollow(FOLLOW_unaryExp_in_unaryExp3076);
                    e=unaryExp();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       PrefixExpression pe = ast.newPrefixExpression();
                      											                        pe.setOperator(PrefixExpression.Operator.PLUS);
                      											                        pe.setOperand(e);
                      											                        result = pe;
                      										                        
                    }

                    }
                    break;
                case 3 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:312:4: e= unaryExpNotPlusMinus
                    {
                    pushFollow(FOLLOW_unaryExpNotPlusMinus_in_unaryExp3110);
                    e=unaryExpNotPlusMinus();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       result = e; 
                    }

                    }
                    break;

            }
        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 25, unaryExp_StartIndex); }
        }
        return result;
    }
    // $ANTLR end unaryExp


    // $ANTLR start unaryExpNotPlusMinus
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:315:1: unaryExpNotPlusMinus returns [Expression result = null] : ( '!' e= unaryExp | e= primaryExp );
    public final Expression unaryExpNotPlusMinus() throws RecognitionException {
        Expression result =  null;
        int unaryExpNotPlusMinus_StartIndex = input.index();
        Expression e = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 26) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:316:2: ( '!' e= unaryExp | e= primaryExp )
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==39) ) {
                alt25=1;
            }
            else if ( ((LA25_0>=ID && LA25_0<=NUM_INT)||LA25_0==13||(LA25_0>=40 && LA25_0<=41)) ) {
                alt25=2;
            }
            else {
                if (backtracking>0) {failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("315:1: unaryExpNotPlusMinus returns [Expression result = null] : ( '!' e= unaryExp | e= primaryExp );", 25, 0, input);

                throw nvae;
            }
            switch (alt25) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:316:4: '!' e= unaryExp
                    {
                    match(input,39,FOLLOW_39_in_unaryExpNotPlusMinus3145); if (failed) return result;
                    pushFollow(FOLLOW_unaryExp_in_unaryExpNotPlusMinus3149);
                    e=unaryExp();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       PrefixExpression pe = ast.newPrefixExpression();
                      											                        pe.setOperator(PrefixExpression.Operator.NOT);
                      											                        pe.setOperand(e);
                                                                    result = pe; 
                    }

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:320:4: e= primaryExp
                    {
                    pushFollow(FOLLOW_primaryExp_in_unaryExpNotPlusMinus3183);
                    e=primaryExp();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       result = e; 
                    }

                    }
                    break;

            }
        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 26, unaryExpNotPlusMinus_StartIndex); }
        }
        return result;
    }
    // $ANTLR end unaryExpNotPlusMinus


    // $ANTLR start primaryExp
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:323:1: primaryExp returns [Expression result = null] : (n= NUM_INT {...}? | 'true' | 'false' | '(' e= exp ')' | i= invokeExp | ID );
    public final Expression primaryExp() throws RecognitionException {
        Expression result =  null;
        int primaryExp_StartIndex = input.index();
        Token n=null;
        Token ID7=null;
        Expression e = null;

        MethodInvocation i = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 27) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:324:2: (n= NUM_INT {...}? | 'true' | 'false' | '(' e= exp ')' | i= invokeExp | ID )
            int alt26=6;
            switch ( input.LA(1) ) {
            case NUM_INT:
                {
                alt26=1;
                }
                break;
            case 40:
                {
                alt26=2;
                }
                break;
            case 41:
                {
                alt26=3;
                }
                break;
            case 13:
                {
                alt26=4;
                }
                break;
            case ID:
                {
                int LA26_5 = input.LA(2);

                if ( (LA26_5==13||LA26_5==42) ) {
                    alt26=5;
                }
                else if ( (LA26_5==EOF||(LA26_5>=16 && LA26_5<=17)||LA26_5==20||(LA26_5>=26 && LA26_5<=38)) ) {
                    alt26=6;
                }
                else {
                    if (backtracking>0) {failed=true; return result;}
                    NoViableAltException nvae =
                        new NoViableAltException("323:1: primaryExp returns [Expression result = null] : (n= NUM_INT {...}? | 'true' | 'false' | '(' e= exp ')' | i= invokeExp | ID );", 26, 5, input);

                    throw nvae;
                }
                }
                break;
            default:
                if (backtracking>0) {failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("323:1: primaryExp returns [Expression result = null] : (n= NUM_INT {...}? | 'true' | 'false' | '(' e= exp ')' | i= invokeExp | ID );", 26, 0, input);

                throw nvae;
            }

            switch (alt26) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:324:4: n= NUM_INT {...}?
                    {
                    n=(Token)input.LT(1);
                    match(input,NUM_INT,FOLLOW_NUM_INT_in_primaryExp3230); if (failed) return result;
                    if ( !( new BigInteger(n.getText()).bitLength() < 32 ) ) {
                        if (backtracking>0) {failed=true; return result;}
                        throw new FailedPredicateException(input, "primaryExp", " new BigInteger(n.getText()).bitLength() < 32 ");
                    }
                    if ( backtracking==0 ) {
                       NumberLiteral nl = ast.newNumberLiteral();
                      											                        nl.setToken(n.getText());
                      											                        result = nl; 
                    }

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:329:4: 'true'
                    {
                    match(input,40,FOLLOW_40_in_primaryExp3281); if (failed) return result;
                    if ( backtracking==0 ) {
                       result = ast.newBooleanLiteral(true); 
                    }

                    }
                    break;
                case 3 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:330:4: 'false'
                    {
                    match(input,41,FOLLOW_41_in_primaryExp3321); if (failed) return result;
                    if ( backtracking==0 ) {
                       result = ast.newBooleanLiteral(false); 
                    }

                    }
                    break;
                case 4 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:331:4: '(' e= exp ')'
                    {
                    match(input,13,FOLLOW_13_in_primaryExp3360); if (failed) return result;
                    pushFollow(FOLLOW_exp_in_primaryExp3364);
                    e=exp();
                    _fsp--;
                    if (failed) return result;
                    match(input,16,FOLLOW_16_in_primaryExp3366); if (failed) return result;
                    if ( backtracking==0 ) {
                       ParenthesizedExpression pe = ast.newParenthesizedExpression();
                                                                    pe.setExpression(e);
                                                                    result = pe; 
                    }

                    }
                    break;
                case 5 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:334:4: i= invokeExp
                    {
                    pushFollow(FOLLOW_invokeExp_in_primaryExp3401);
                    i=invokeExp();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       result = i; 
                    }

                    }
                    break;
                case 6 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:335:4: ID
                    {
                    ID7=(Token)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_primaryExp3436); if (failed) return result;
                    if ( backtracking==0 ) {
                       result = ast.newSimpleName(ID7.getText()); 
                    }

                    }
                    break;

            }
        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 27, primaryExp_StartIndex); }
        }
        return result;
    }
    // $ANTLR end primaryExp


    // $ANTLR start invokeExp
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:339:1: invokeExp returns [MethodInvocation result = ast.newMethodInvocation()] : (id1= ID '.' )? id2= ID '(' (es= args )? ')' ;
    public final MethodInvocation invokeExp() throws RecognitionException {
        MethodInvocation result =  ast.newMethodInvocation();
        int invokeExp_StartIndex = input.index();
        Token id1=null;
        Token id2=null;
        ArrayList<Expression> es = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 28) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:340:2: ( (id1= ID '.' )? id2= ID '(' (es= args )? ')' )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:340:4: (id1= ID '.' )? id2= ID '(' (es= args )? ')'
            {
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:340:4: (id1= ID '.' )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==ID) ) {
                int LA27_1 = input.LA(2);

                if ( (LA27_1==42) ) {
                    alt27=1;
                }
            }
            switch (alt27) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:341:4: id1= ID '.'
                    {
                    id1=(Token)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_invokeExp3500); if (failed) return result;
                    if ( backtracking==0 ) {
                       result.setExpression(ast.newSimpleName(id1.getText())); 
                    }
                    match(input,42,FOLLOW_42_in_invokeExp3538); if (failed) return result;

                    }
                    break;

            }

            id2=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_invokeExp3559); if (failed) return result;
            if ( backtracking==0 ) {
               result.setName(ast.newSimpleName(id2.getText())); 
            }
            match(input,13,FOLLOW_13_in_invokeExp3598); if (failed) return result;
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:345:7: (es= args )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( ((LA28_0>=ID && LA28_0<=NUM_INT)||LA28_0==13||(LA28_0>=34 && LA28_0<=35)||(LA28_0>=39 && LA28_0<=41)) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:345:9: es= args
                    {
                    pushFollow(FOLLOW_args_in_invokeExp3604);
                    es=args();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                       result.arguments().addAll(es); 
                    }

                    }
                    break;

            }

            match(input,16,FOLLOW_16_in_invokeExp3639); if (failed) return result;

            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 28, invokeExp_StartIndex); }
        }
        return result;
    }
    // $ANTLR end invokeExp


    // $ANTLR start args
    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:349:1: args returns [ArrayList<Expression> result = new ArrayList<Expression>()] : e= exp ( ',' e= exp )* ;
    public final ArrayList<Expression> args() throws RecognitionException {
        ArrayList<Expression> result =  new ArrayList<Expression>();
        int args_StartIndex = input.index();
        Expression e = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 29) ) { return result; }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:350:2: (e= exp ( ',' e= exp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:350:4: e= exp ( ',' e= exp )*
            {
            pushFollow(FOLLOW_exp_in_args3660);
            e=exp();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
               result.add(e); 
            }
            // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:351:3: ( ',' e= exp )*
            loop29:
            do {
                int alt29=2;
                int LA29_0 = input.LA(1);

                if ( (LA29_0==20) ) {
                    alt29=1;
                }


                switch (alt29) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone2/src/sjc/parser/extended/ExtendedStaticJavaAST.g:352:4: ',' e= exp
            	    {
            	    match(input,20,FOLLOW_20_in_args3705); if (failed) return result;
            	    pushFollow(FOLLOW_exp_in_args3709);
            	    e=exp();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	       result.add(e); 
            	    }

            	    }
            	    break;

            	default :
            	    break loop29;
                }
            } while (true);


            }

        }

        catch (RecognitionException re) {
        	throw re;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 29, args_StartIndex); }
        }
        return result;
    }
    // $ANTLR end args


 

    public static final BitSet FOLLOW_classDefinition_in_compilationUnit59 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_compilationUnit82 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_7_in_classDefinition98 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_8_in_classDefinition128 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_classDefinition130 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_9_in_classDefinition132 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_mainMethodDeclaration_in_classDefinition166 = new BitSet(new long[]{0x0000000000000C00L});
    public static final BitSet FOLLOW_fieldDeclaration_in_classDefinition188 = new BitSet(new long[]{0x0000000000000C00L});
    public static final BitSet FOLLOW_methodDeclaration_in_classDefinition216 = new BitSet(new long[]{0x0000000000000C00L});
    public static final BitSet FOLLOW_10_in_classDefinition245 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_7_in_mainMethodDeclaration266 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_11_in_mainMethodDeclaration303 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_12_in_mainMethodDeclaration340 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_mainMethodDeclaration381 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_13_in_mainMethodDeclaration395 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_mainMethodDeclaration402 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_14_in_mainMethodDeclaration413 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_15_in_mainMethodDeclaration415 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_mainMethodDeclaration419 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_mainMethodDeclaration450 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_9_in_mainMethodDeclaration452 = new BitSet(new long[]{0x00000000034C0410L});
    public static final BitSet FOLLOW_methodBody_in_mainMethodDeclaration456 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_10_in_mainMethodDeclaration458 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_fieldDeclaration496 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_type_in_fieldDeclaration536 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_fieldDeclaration568 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_fieldDeclaration611 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_methodDeclaration627 = new BitSet(new long[]{0x00000000000C1000L});
    public static final BitSet FOLLOW_returnType_in_methodDeclaration667 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_methodDeclaration694 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_13_in_methodDeclaration696 = new BitSet(new long[]{0x00000000000D0000L});
    public static final BitSet FOLLOW_params_in_methodDeclaration739 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_methodDeclaration776 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_9_in_methodDeclaration778 = new BitSet(new long[]{0x00000000034C0410L});
    public static final BitSet FOLLOW_methodBody_in_methodDeclaration782 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_10_in_methodDeclaration784 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_type817 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_type854 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_12_in_returnType906 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_type_in_returnType946 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_param_in_params999 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_20_in_params1038 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_param_in_params1042 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_type_in_param1091 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_param1122 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_localDeclaration_in_methodBody1184 = new BitSet(new long[]{0x00000000034C0012L});
    public static final BitSet FOLLOW_statement_in_methodBody1218 = new BitSet(new long[]{0x0000000003400012L});
    public static final BitSet FOLLOW_type_in_localDeclaration1273 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_localDeclaration1304 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_localDeclaration1306 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assignStatement_in_statement1361 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ifStatement_in_statement1391 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_whileStatement_in_statement1425 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_invokeExpStatement_in_statement1456 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_returnStatement_in_statement1482 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_assignStatement1529 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_assignStatement1572 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_exp_in_assignStatement1576 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_assignStatement1578 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_ifStatement1626 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_13_in_ifStatement1628 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_exp_in_ifStatement1632 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_ifStatement1634 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_9_in_ifStatement1655 = new BitSet(new long[]{0x0000000003400410L});
    public static final BitSet FOLLOW_statement_in_ifStatement1667 = new BitSet(new long[]{0x0000000003400410L});
    public static final BitSet FOLLOW_10_in_ifStatement1705 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_23_in_ifStatement1711 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_9_in_ifStatement1713 = new BitSet(new long[]{0x0000000003400410L});
    public static final BitSet FOLLOW_statement_in_ifStatement1728 = new BitSet(new long[]{0x0000000003400410L});
    public static final BitSet FOLLOW_10_in_ifStatement1762 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_24_in_whileStatement1786 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_13_in_whileStatement1788 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_exp_in_whileStatement1792 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_whileStatement1814 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_9_in_whileStatement1816 = new BitSet(new long[]{0x0000000003400410L});
    public static final BitSet FOLLOW_statement_in_whileStatement1828 = new BitSet(new long[]{0x0000000003400410L});
    public static final BitSet FOLLOW_10_in_whileStatement1863 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_invokeExp_in_invokeExpStatement1881 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_invokeExpStatement1883 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_returnStatement1923 = new BitSet(new long[]{0x0000038C00022030L});
    public static final BitSet FOLLOW_exp_in_returnStatement1936 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_returnStatement1977 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logicalOrExp_in_exp1995 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logicalAndExp_in_logicalOrExp2039 = new BitSet(new long[]{0x0000000004000002L});
    public static final BitSet FOLLOW_26_in_logicalOrExp2074 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_logicalAndExp_in_logicalOrExp2078 = new BitSet(new long[]{0x0000000004000002L});
    public static final BitSet FOLLOW_equalityExp_in_logicalAndExp2118 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_27_in_logicalAndExp2153 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_equalityExp_in_logicalAndExp2157 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_relationalExp_in_equalityExp2205 = new BitSet(new long[]{0x0000000030000002L});
    public static final BitSet FOLLOW_28_in_equalityExp2247 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_29_in_equalityExp2287 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_relationalExp_in_equalityExp2333 = new BitSet(new long[]{0x0000000030000002L});
    public static final BitSet FOLLOW_additiveExp_in_relationalExp2385 = new BitSet(new long[]{0x00000003C0000002L});
    public static final BitSet FOLLOW_30_in_relationalExp2425 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_31_in_relationalExp2466 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_32_in_relationalExp2507 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_33_in_relationalExp2547 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_additiveExp_in_relationalExp2593 = new BitSet(new long[]{0x00000003C0000002L});
    public static final BitSet FOLLOW_multiplicativeExp_in_additiveExp2647 = new BitSet(new long[]{0x0000000C00000002L});
    public static final BitSet FOLLOW_34_in_additiveExp2680 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_35_in_additiveExp2721 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_multiplicativeExp_in_additiveExp2768 = new BitSet(new long[]{0x0000000C00000002L});
    public static final BitSet FOLLOW_unaryExp_in_multiplicativeExp2816 = new BitSet(new long[]{0x0000007000000002L});
    public static final BitSet FOLLOW_36_in_multiplicativeExp2858 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_37_in_multiplicativeExp2899 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_38_in_multiplicativeExp2940 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_unaryExp_in_multiplicativeExp2986 = new BitSet(new long[]{0x0000007000000002L});
    public static final BitSet FOLLOW_35_in_unaryExp3036 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_unaryExp_in_unaryExp3040 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_unaryExp3072 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_unaryExp_in_unaryExp3076 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unaryExpNotPlusMinus_in_unaryExp3110 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_39_in_unaryExpNotPlusMinus3145 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_unaryExp_in_unaryExpNotPlusMinus3149 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_primaryExp_in_unaryExpNotPlusMinus3183 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUM_INT_in_primaryExp3230 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_40_in_primaryExp3281 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_41_in_primaryExp3321 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_primaryExp3360 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_exp_in_primaryExp3364 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_primaryExp3366 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_invokeExp_in_primaryExp3401 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_primaryExp3436 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_invokeExp3500 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_42_in_invokeExp3538 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_invokeExp3559 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_13_in_invokeExp3598 = new BitSet(new long[]{0x0000038C00012030L});
    public static final BitSet FOLLOW_args_in_invokeExp3604 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_invokeExp3639 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_exp_in_args3660 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_20_in_args3705 = new BitSet(new long[]{0x0000038C00002030L});
    public static final BitSet FOLLOW_exp_in_args3709 = new BitSet(new long[]{0x0000000000100002L});

}