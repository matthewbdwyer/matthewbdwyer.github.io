class Object39{
	
}

public class TypeCheckFailAssignNamedIntArrayToObjectArray {
    public static void main(String[] args) {
    	Object39[] O;
    	int[] I;
    	
    	I = new int[1];
    	O = I;
    }
}