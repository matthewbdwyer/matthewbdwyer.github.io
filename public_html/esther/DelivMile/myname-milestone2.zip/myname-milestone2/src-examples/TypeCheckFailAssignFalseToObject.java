class Object14{
	
}

public class TypeCheckFailAssignFalseToObject {
    public static void main(String[] args) {
    	Object14 o;
    	
    	o = false;
    }
}