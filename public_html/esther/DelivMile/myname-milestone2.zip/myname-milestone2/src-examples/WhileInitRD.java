public class WhileInitRD
{
    public static void main(String[] args)
    {
        int x;
        while (x == 1)
        {
            x = 2;
        }
    }
}
