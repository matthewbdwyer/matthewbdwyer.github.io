public class TypeCheckFailAssignBooleanToIntArray {
    public static void main(String[] args) {
    	int[] I;
    	boolean b;
    	
    	b = true;
    	I = b;
    }
}