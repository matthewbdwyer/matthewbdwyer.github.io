class Object36{
	
}

public class TypeCheckFailAssignBooleanToObjectArray {
    public static void main(String[] args) {
    	Object36[] O;
    	boolean b;
    	
    	b = true;
    	O = b;
    }
}