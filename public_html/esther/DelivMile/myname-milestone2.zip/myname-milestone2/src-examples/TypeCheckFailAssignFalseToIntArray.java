public class TypeCheckFailAssignFalseToIntArray {
    public static void main(String[] args) {
    	int[] I;
    	
    	I = false;
    }
}