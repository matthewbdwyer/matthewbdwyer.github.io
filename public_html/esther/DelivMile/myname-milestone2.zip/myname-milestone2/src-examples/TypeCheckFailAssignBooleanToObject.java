class Object13{
	
}

public class TypeCheckFailAssignBooleanToObject {
    public static void main(String[] args) {
    	Object13 o;
    	boolean b;
    	
    	b = true;
    	o = b;
    }
}