public class IncIntArrayAccess {
    public static void main(String[] args) {
    	int[] I;
    	
    	I = new int[1];
    	I[0] = 1;
    	I[0]++;
    }
}