public class ParseFailForUpdate {
	public static void main(String[] args) {
		int i;
		for (i = 0; i<10) {
		}
	}
}
