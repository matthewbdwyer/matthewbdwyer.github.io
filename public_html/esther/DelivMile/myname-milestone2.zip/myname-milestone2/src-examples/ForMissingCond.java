public class ForMissingCond {
    public static void main(String[] args) {
    }
    
    static void missingCond() {
        int i;
        
        for (i = 0;; i++) {
        }
    }
}
