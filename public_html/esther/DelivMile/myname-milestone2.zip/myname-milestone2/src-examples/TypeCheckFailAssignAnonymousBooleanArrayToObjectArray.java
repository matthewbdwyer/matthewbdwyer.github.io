class Object25{
	
}

public class TypeCheckFailAssignAnonymousBooleanArrayToObjectArray {
    public static void main(String[] args) {
    	Object25[] o;
     	
    	o = new boolean[1];
    }
}