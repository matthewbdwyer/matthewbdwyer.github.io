class Object47 {
	
}

public class TypeCheckFailAssignNamedObjectToIntArray {
    public static void main(String[] args) {
    	int[] I;
    	Object47 o;
    	
    	o = new Object47();
    	I = o;
    }
}