class Object34 {
	
}

public class TypeCheckFailAssignAnonymousObjectToBooleanArray {
    public static void main(String[] args) {
    	boolean[] b;
    	
    	b = new Object34();
    }
}