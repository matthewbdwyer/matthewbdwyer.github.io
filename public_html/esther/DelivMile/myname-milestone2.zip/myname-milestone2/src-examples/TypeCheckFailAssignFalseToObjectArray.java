class Object37{
	
}

public class TypeCheckFailAssignFalseToObjectArray {
    public static void main(String[] args) {
    	Object37[] O;
    	
    	O = false;
    }
}