public class TypeCheckFailAssignNamedBooleanArrayToInt {
    public static void main(String[] args) {
    	int i;
    	boolean[] B;
    	
    	B = new boolean[1];
    	i = B;
    }
}