public class TypeCheckFailIntConditional {
    public static void main(String[] args) {
    	int i;
     	
    	i = 0;
    	i = i ? 1 : 2;
    }
}