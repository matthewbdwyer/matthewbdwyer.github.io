class Object38{
	
}

public class TypeCheckFailAssignNamedBooleanArrayToObjectArray {
    public static void main(String[] args) {
    	Object38[] O;
    	boolean[] B;
    	
    	B = new boolean[1];
    	O = B;
    }
}