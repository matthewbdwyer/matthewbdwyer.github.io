public class ParseFailFor {
	public static void main(String[] args) {
		int i;
		int j;
		for (i = 0; i < 10; i++; j++) {
		}
	}
}
