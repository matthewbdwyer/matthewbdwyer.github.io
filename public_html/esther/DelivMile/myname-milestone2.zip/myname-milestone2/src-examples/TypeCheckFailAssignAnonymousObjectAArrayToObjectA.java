class Object7 {

}

public class TypeCheckFailAssignAnonymousObjectAArrayToObjectA {
	public static void main(String[] args) {
		Object7 o;

		o = new Object7[1];
	}
}