public class TypeCheckFailComplementBadExpression {
    public static void main(String[] args) {
    	boolean b;
    	
    	b = ~(true || false);
    }
}