public class TypeCheckFailNegateBoolean {
    public static void main(String[] args) {
    	boolean b;
    	
    	b = -b;
    }
}