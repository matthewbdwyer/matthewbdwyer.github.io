class Object49 {
	
}

public class TypeCheckFailIntPlusObject {
    public static void main(String[] args) {
    	Object49 o;
    	int i;
    	
    	o = new Object49();
    	i = i + o;
    }
}