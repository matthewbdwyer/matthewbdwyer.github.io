class Object33 {

}

public class TypeCheckFailAssignAnonymousObjectArrayToIntArray {
	public static void main(String[] args) {
		int[] i;

		i = new Object33[1];
	}
}