public class TypeCheckFailAssignTrueToInt {
    public static void main(String[] args) {
    	int i;
    	
    	i = true;
    }
}