class Object44 {
	
}

class Object45{
	
}

public class TypeCheckFailAssignNamedObjectAToObjectBArray {
    public static void main(String[] args) {
    	Object45[] OB;
    	Object44 oA;
    	
    	oA = new Object44();
    	OB = oA;
    }
}