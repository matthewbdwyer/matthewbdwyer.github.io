class Object29 {

}

public class TypeCheckFailAssignAnonymousObjectArrayToBooleanArray {
	public static void main(String[] args) {
		boolean[] b;

		b = new Object29[1];
	}
}