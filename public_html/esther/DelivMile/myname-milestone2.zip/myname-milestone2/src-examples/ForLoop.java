public class ForLoop
{
    public static void main(String[] args)
    {
        int i;
		int j;
		int x;
		for (x = 0, i = 0, j = 0; i<5; i++, j++) {
			x = x + i + j;
		}
    }

}
