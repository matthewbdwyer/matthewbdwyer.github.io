public class ForInitOnly {
    public static void main(String[] args) {
    }

    static void initOnly() {
        int i;
        
        for (i = 0;;) {
        }
    }
}

