package sjc.test;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.antlr.runtime.ANTLRFileStream;
import org.antlr.runtime.CommonTokenStream;
import org.eclipse.jdt.core.dom.CompilationUnit;

import sjc.analysis.StaticErrorDetection;
import sjc.parser.StaticJavaASTLexer;
import sjc.parser.StaticJavaASTParser;

public class StaticErrorDetectionTest extends TestCase {
	public void testPower() {
		testPass("src-examples/Power.java");
	}

	public void testFactorial() {
		testPass("src-examples/Factorial.java");
	}

	// add your favorite tests here	

	public static void testPass(String filename) {
		try {
		    ANTLRFileStream afs = new ANTLRFileStream(filename);
		    StaticJavaASTLexer sjal = new StaticJavaASTLexer(afs);
		    CommonTokenStream cts = new CommonTokenStream(sjal);
		    StaticJavaASTParser sjap = new StaticJavaASTParser(cts);
		    CompilationUnit cu = sjap.compilationUnit();
			System.out.println("Error reports for " + filename);
			System.out.println();
			StaticErrorDetection.reportErrors(cu);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.assertTrue(e.getMessage(), false);
		}
	}

}
