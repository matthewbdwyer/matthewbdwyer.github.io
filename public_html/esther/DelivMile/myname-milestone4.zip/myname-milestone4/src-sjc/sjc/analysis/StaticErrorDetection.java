package sjc.analysis;

import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import sjc.symboltable.SymbolTable;
import sjc.symboltable.SymbolTableBuilder;
import sjc.util.Pair;

public class StaticErrorDetection {

	public static void reportErrors(CompilationUnit cu) {
		SymbolTable st = SymbolTableBuilder.build(cu);
		for (Object type : cu.types()) {
			if (type instanceof TypeDeclaration) {
				for (Object body : ((TypeDeclaration) type).bodyDeclarations()) {
					if (body instanceof MethodDeclaration) {
						MethodDeclaration md = (MethodDeclaration) body;
						CFG cfg = new CFG(md);

						System.out.println("in method : "
								+ md.getName().getIdentifier());
						System.out.println();

						/**
						 * Detect and report unreachable statements
						 * 
						 * unreachable statements are returned as a Set<Statement>  
						 */ 
						/*
						UnreachableStatementAnalysis usa = new UnreachableStatementAnalysis();
						for (Statement s : usa.unreachableStatements(md, cfg)) {
							System.out.println("unreachable statement : " + s);
						}
						*/

						/**
						 * Detect and report uninitialized references
						 * 
						 * uninitialized references are returned as a Set<Pair<Statement, String>> 
						 * where String is the name of the variable referenced in Statement.
						 */ 
						/*
						UninitializedReferenceAnalysis uva = new UninitializedReferenceAnalysis();
						for (Pair<Statement, String> p : uva
								.uninitializedReferences(md, cfg, st)) {
							System.out.println("uninitialized reference to "
									+ p.second + " in : " + p.first);
						}
						*/

						/**
						 * Detect and report unused assignments
						 * 
						 * unused assignments are returned as a Set<Assignment>  
						 */ 
						/*
						UnusedAssignmentAnalysis uaa = new UnusedAssignmentAnalysis();
						for (Assignment a : uaa.unusedAssignments(md, cfg, st)) {
							System.out.println("unused assignment : " + a);
						}
						*/

						System.out.println();
						System.out.flush();
					}
				}
			}
		}
	}
}

