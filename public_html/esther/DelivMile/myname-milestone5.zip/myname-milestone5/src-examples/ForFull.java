public class ForFull {
    public static void main(String[] args) {
        full();
    }

    static void full() {
        int i;
        
        for (i = 0; i < 10; i++) {
        }
        StaticJavaLib.assertTrue(i == 10);
    }
}
