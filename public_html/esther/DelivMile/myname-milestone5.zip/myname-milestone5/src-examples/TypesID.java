class Foo {
}

public class TypesID {
    public static void main(String[] args) {
        Foo f;
        Foo[] g;
    }
}
    
