public class TypesArray {
    public static void main(String[] args) {
        int[] i;
        boolean[] b;
    }
}
    
