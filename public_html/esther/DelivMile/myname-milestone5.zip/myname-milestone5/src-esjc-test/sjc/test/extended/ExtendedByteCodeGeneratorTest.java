package sjc.test.extended;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.antlr.runtime.ANTLRFileStream;
import org.antlr.runtime.CommonTokenStream;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.util.TraceClassVisitor;

import sjc.codegen.extended.ExtendedByteCodeGenerator;
import sjc.codegen.extended.ExtendedClassByteCodes;
import sjc.parser.extended.ExtendedStaticJavaASTLexer;
import sjc.parser.extended.ExtendedStaticJavaASTParser;
import sjc.symboltable.extended.ExtendedSymbolTable;
import sjc.symboltable.extended.ExtendedSymbolTableBuilder;
import sjc.type.TypeFactory;
import sjc.type.checker.extended.ExtendedTypeChecker;
import sjc.type.checker.extended.ExtendedTypeTable;

public class ExtendedByteCodeGeneratorTest
    extends TestCase
{
	
    public static void testPass(String filename)
    {
    	Object[] args = new Object[] { new String[] {} };
        try
        {
        	ANTLRFileStream afs = new ANTLRFileStream(filename);
    		ExtendedStaticJavaASTLexer esjl = new ExtendedStaticJavaASTLexer(afs);
    		CommonTokenStream cts = new CommonTokenStream(esjl);
    		ExtendedStaticJavaASTParser esjp = new ExtendedStaticJavaASTParser(cts);
    		CompilationUnit cu = esjp.compilationUnit();
            ExtendedSymbolTable est = ExtendedSymbolTableBuilder.build(cu);
            ExtendedTypeTable ett = ExtendedTypeChecker.check(new TypeFactory(), cu, est);
            ExtendedClassByteCodes ecbc = ExtendedByteCodeGenerator.generate(cu, est, ett);
            
            PrintWriter pw = new PrintWriter(System.out);
            outputBytecodes(pw, ecbc.mainClassBytes);
            for (byte[] bytecodes: ecbc.otherClasses.values())
            {
                outputBytecodes(pw, bytecodes);
            }

            CustomClassLoader ccl = new CustomClassLoader();
            for (String className: ecbc.otherClasses.keySet())
            {
                ccl.loadClass(className, ecbc.otherClasses.get(className));
            }
            Class c = ccl.loadClass(ecbc.mainClassName, ecbc.mainClassBytes);
            c.getMethod("main", new Class[]
                {
                    String[].class
                }).invoke(null, args);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.assertTrue(e.getMessage(), false);
            throw new RuntimeException();
        }
    }
    
    static void outputBytecodes(PrintWriter pw, byte[] b)
    {
        ClassReader cr = new ClassReader(b);
        TraceClassVisitor tcv = new TraceClassVisitor(pw);
        cr.accept(tcv, ClassReader.SKIP_FRAMES);  
        pw.flush();
    }

    static class CustomClassLoader
        extends ClassLoader
    {
        public Class loadClass(String name, byte[] bytecodes)
        {
            return defineClass(name, bytecodes, 0, bytecodes.length);
        }
    }
    
	public void testAEEmptyTest() { testPass("src-examples/AEEmptyTest.java"); }

	public void testArrayAccessVariable() { testPass("src-examples/ArrayAccessVariable.java"); }

	public void testArrayCreation() { testPass("src-examples/ArrayCreation.java"); }

	public void testArrayCreation2() { testPass("src-examples/ArrayCreation2.java"); }

	public void testArrayIndex() { testPass("src-examples/ArrayIndex.java"); }

	public void testArrayIndexConstant() { testPass("src-examples/ArrayIndexConstant.java"); }

	public void testAssignNullToObject() { testPass("src-examples/AssignNullToObject.java"); }

	public void testBasicTypes() { testPass("src-examples/BasicTypes.java"); }

	public void testBinaryOps() { testPass("src-examples/BinaryOps.java"); }

	public void testBooleanAnd() { testPass("src-examples/BooleanAnd.java"); }

	public void testBooleanLiteral() { testPass("src-examples/BooleanLiteral.java"); }

	public void testBooleanNot() { testPass("src-examples/BooleanNot.java"); }

	public void testBooleanOr() { testPass("src-examples/BooleanOr.java"); }

	public void testConditionalFalse() { testPass("src-examples/ConditionalFalse.java"); }

	public void testConditionalTrue() { testPass("src-examples/ConditionalTrue.java"); }

	public void testConditionalWithNull() { testPass("src-examples/ConditionalWithNull.java"); }

	public void testCreateIntArrayWithIntAndIntLiteralInitializers() { testPass("src-examples/CreateIntArrayWithIntAndIntLiteralInitializers.java"); }

	public void testDoWhile() { testPass("src-examples/DoWhile.java"); }

	public void testDoWhileWithBooleanArrayAccessCondition() { testPass("src-examples/DoWhileWithBooleanArrayAccessCondition.java"); }

	public void testFactorial() { testPass("src-examples/Factorial.java"); }

	public void testFieldAccess() { testPass("src-examples/FieldAccess.java"); }

	public void testFor() { testPass("src-examples/For.java"); }

	public void testForBooleanArrayAccessConditional() { testPass("src-examples/ForBooleanArrayAccessConditional.java"); }

	public void testForBooleanMemberAccessConditional() { testPass("src-examples/ForBooleanMemberAccessConditional.java"); }

	public void testForCondOnly() { testPass("src-examples/ForCondOnly.java"); }

	public void testForEmpty() { testPass("src-examples/ForEmpty.java"); }

	public void testForFull() { testPass("src-examples/ForFull.java"); }

	public void testForIncOrDecOnly() { testPass("src-examples/ForIncOrDecOnly.java"); }

	public void testForInitOnly() { testPass("src-examples/ForInitOnly.java"); }

	public void testForLoop() { testPass("src-examples/ForLoop.java"); }

	public void testForMissingCond() { testPass("src-examples/ForMissingCond.java"); }

	public void testForMissingIncOrDec() { testPass("src-examples/ForMissingIncOrDec.java"); }

	public void testForMissingInit() { testPass("src-examples/ForMissingInit.java"); }

	public void testForMultipleIncOrDecOnly() { testPass("src-examples/ForMultipleIncOrDecOnly.java"); }

	public void testForMultipleInitAndIncOrDec() { testPass("src-examples/ForMultipleInitAndIncOrDec.java"); }

	public void testForMultipleInitOnly() { testPass("src-examples/ForMultipleInitOnly.java"); }

	public void testForwardClassTest() { testPass("src-examples/ForwardClassTest.java"); }

	public void testIf() { testPass("src-examples/If.java"); }

	public void testIfFalseEmpty() { testPass("src-examples/IfFalseEmpty.java"); }

	public void testIfFalseSingle() { testPass("src-examples/IfFalseSingle.java"); }

	public void testIfFalseSingleElseEmpty() { testPass("src-examples/IfFalseSingleElseEmpty.java"); }

	public void testIfFalseSingleElseMultiple() { testPass("src-examples/IfFalseSingleElseMultiple.java"); }

	public void testIfFalseSingleElseSingle() { testPass("src-examples/IfFalseSingleElseSingle.java"); }

	public void testIfTrueEmpty() { testPass("src-examples/IfTrueEmpty.java"); }

	public void testIfTrueEmptyElseEmpty() { testPass("src-examples/IfTrueEmptyElseEmpty.java"); }

	public void testIfTrueMultiple() { testPass("src-examples/IfTrueMultiple.java"); }

	public void testIfTrueSingle() { testPass("src-examples/IfTrueSingle.java"); }

	public void testIfTrueSingleElseEmpty() { testPass("src-examples/IfTrueSingleElseEmpty.java"); }

	public void testIfTrueSingleElseSingle() { testPass("src-examples/IfTrueSingleElseSingle.java"); }

	public void testIncIntArrayAccess() { testPass("src-examples/IncIntArrayAccess.java"); }

	public void testIntAdd() { testPass("src-examples/IntAdd.java"); }

	public void testIntComplement() { testPass("src-examples/IntComplement.java"); }

	public void testIntDivide() { testPass("src-examples/IntDivide.java"); }

	public void testIntEqual() { testPass("src-examples/IntEqual.java"); }

	public void testIntGreaterThan() { testPass("src-examples/IntGreaterThan.java"); }

	public void testIntGreaterThanOrEqual() { testPass("src-examples/IntGreaterThanOrEqual.java"); }

	public void testIntLessThan() { testPass("src-examples/IntLessThan.java"); }

	public void testIntLessThanOrEqual() { testPass("src-examples/IntLessThanOrEqual.java"); }

	public void testIntMultiply() { testPass("src-examples/IntMultiply.java"); }

	public void testIntNegate() { testPass("src-examples/IntNegate.java"); }

	public void testIntNotEqual() { testPass("src-examples/IntNotEqual.java"); }

	public void testIntPlus() { testPass("src-examples/IntPlus.java"); }

	public void testIntPostDecrement() { testPass("src-examples/IntPostDecrement.java"); }

	public void testIntPostIncrement() { testPass("src-examples/IntPostIncrement.java"); }

	public void testIntRemainder() { testPass("src-examples/IntRemainder.java"); }

	public void testIntShiftLeft() { testPass("src-examples/IntShiftLeft.java"); }

	public void testIntShiftRight() { testPass("src-examples/IntShiftRight.java"); }

	public void testIntSubtract() { testPass("src-examples/IntSubtract.java"); }

	public void testIntUnsignedShiftRight() { testPass("src-examples/IntUnsignedShiftRight.java"); }

	public void testNewBasic() { testPass("src-examples/NewBasic.java"); }

	public void testNewID() { testPass("src-examples/NewID.java"); }

	public void testNullArgumentForIntArrayParameter() { testPass("src-examples/NullArgumentForIntArrayParameter.java"); }

	public void testNullEqualsNull() { testPass("src-examples/NullEqualsNull.java"); }

	public void testObjectAEqualsReturnedObjectA() { testPass("src-examples/ObjectAEqualsReturnedObjectA.java"); }

	public void testParens() { testPass("src-examples/Parens.java"); }

	public void testPower() { testPass("src-examples/Power.java"); }

	public void testQueue() { testPass("src-examples/Queue.java"); }

	public void testReturnNullFromIntArrayMethod() { testPass("src-examples/ReturnNullFromIntArrayMethod.java"); }

	public void testSAExample() { testPass("src-examples/SAExample.java"); }

	public void testSymbolTableTest() { testPass("src-examples/SymbolTableTest.java"); }

	public void testSyntaxTorture() { testPass("src-examples/SyntaxTorture.java"); }
    

}
