
public class UnusedAssignExample {
	
	public static void main(String[] args) {
		foo();
	}
	
	static void foo() {
		int x;
		int y;
		x = 1;
		y = 1;
		x = y;
		y = x;	
	}

}
