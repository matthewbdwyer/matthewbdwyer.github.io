
public class UninitVarExample {
	
	public static void main(String[] args) {
		foo(7);
	}
	
	static void foo(int p) {
		int x;
		int y;
		int z;
		x = 1;
		if (p > 0) {
			y = 1;
		} else {
			z = 1;
		}
		x = y;
		while (x == y) {
			z = z * 2;
		}
		x = bar(bar(bar(1+z))+1);
	}
	
	static int bar(int x) { return x; }

}
