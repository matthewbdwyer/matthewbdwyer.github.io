
public class LiveVarExample {
	
	public static void main(String[] args) {
		foo();
	}
	
	static void foo() {
		int x;
		int y;
		int z;
		x = 1;
		y = 1;
		if (x > 0) {
			z = bar(x);
			x = bar(z + 1);
			y = 2;
		} else {
			z = y;
			z = z + 3;
			z = 4;
		}
		z = 5;
		
	}
	
	static int bar(int x) { return x; }

}
