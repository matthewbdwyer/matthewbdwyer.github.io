
public class UnreachableExample {
	
	public static void main(String[] args) {
		foo();
	}
	
	static void foo() {
		int x;
		int y;
		int z;
		x = 1;
		y = 1;
		if (x == y) {
			if (x > 0) {
				return;
				z = 1;
			} else {
				x = x + 1;
			}
		}
		if (x > 0) {
			return;
			x = bar(z + 1);
			y = 2;
		} else {
			return;
			if (y == 1) {
				x = 1;
			}
		}
		z = 5;
		
	}
	
	static int bar(int x) { 
		x = 1;
		return x; 
	}
	
	static int bat() {
		int result;
		int i;

		result = 10;
		i = 20;

		if (true) {
			i = i + 1;
			return i;
			if (i < 0) {
				i = i - 1;
				result = 5;
			} else {
				i = 1;
			}
		} else {
			result = result - 1;
			return result;
		}

	}

}
