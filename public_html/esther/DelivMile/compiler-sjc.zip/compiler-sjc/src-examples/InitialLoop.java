public class InitialLoop
{
    public static void main(String[] args)
    {
        foo();
    }

    static void foo()
    {
        int x;
        int y;
        y = 1;
        while (x==1) {
        		x = 2;
        }
    }
}
