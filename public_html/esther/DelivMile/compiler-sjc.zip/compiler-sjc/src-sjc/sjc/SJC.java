package sjc;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import org.eclipse.jdt.core.dom.CompilationUnit;

import antlr.RecognitionException;
import antlr.TokenStreamException;

import sjc.codegen.ByteCodeGenerator;
import sjc.codegen.ClassByteCodes;
import sjc.parser.ASTLexer;
import sjc.parser.ASTParser;
import sjc.symboltable.SymbolTable;
import sjc.symboltable.SymbolTableBuilder;
import sjc.type.TypeFactory;
import sjc.type.checker.TypeChecker;
import sjc.type.checker.TypeTable;

/**
 * This class is the main class of the StaticJava compiler; it provides a
 * command-line interface (CLI) for the compiler.
 * 
 * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
 */
public class SJC
{
    protected SJC()
    {
    }

    public static void main(String[] args)
    {
        if (args.length != 1)
        {
            System.out.println("Usage: sjc <static-java-filename>");
            System.out.flush();
            return;
        }

        String filename = args[0];

        if (!filename.endsWith(".java"))
        {
            System.out.println("Filename must have .java extension");
            System.out.flush();
            return;
        }

        File file = new File(filename);
        String className = file.getName();
        className = className.substring(0, className.length() - 5);

        FileReader fr;

        try
        {
            fr = new FileReader(filename);
        }
        catch (FileNotFoundException e1)
        {
            System.out.println("Could not find file \'" + filename + "\'");
            System.out.flush();
            return;
        }
        ASTLexer lexer = new ASTLexer(fr);
        ASTParser parser = new ASTParser(lexer);
        CompilationUnit cu;
        try
        {
            cu = parser.compilationUnit();
        }
        catch (RecognitionException re)
        {
            System.out.println("line " + re.getLine() + ":"
                               + re.getColumn() + ": " + re.getMessage());
            System.out.flush();
            return;
        }
        catch (TokenStreamException tse)
        {
            System.out.println("Parser error: " + tse.getMessage());
            System.out.flush();
            return;
        }
        catch (Exception e)
        {
            return;
        }
        try
        {
            fr.close();
        }
        catch (IOException e1)
        {
        }

        SymbolTable st = SymbolTableBuilder.build(cu);
        TypeTable tt = TypeChecker.check(new TypeFactory(), cu, st);
        ClassByteCodes cbc = ByteCodeGenerator.generate(cu, st, tt);

        if (!className.equals(cbc.mainClassName))
        {
            System.out
                .println("The main class should be defined in its own Java file");
            System.out.flush();
            return;
        }

        String classFilename = filename.substring(0, filename.length() - 5) + ".class";
        try
        {
            FileOutputStream fos = new FileOutputStream(classFilename);
            fos.write(cbc.mainClassBytes);
            fos.close();
        }
        catch (IOException e)
        {
            System.out
                .println("Unable to write file \'" + classFilename + "\'");
            System.out.flush();
        }
    }
}
