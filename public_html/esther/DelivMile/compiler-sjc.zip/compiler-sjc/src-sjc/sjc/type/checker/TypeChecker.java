package sjc.type.checker;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.BooleanLiteral;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.NumberLiteral;
import org.eclipse.jdt.core.dom.ParenthesizedExpression;
import org.eclipse.jdt.core.dom.PrefixExpression;
import org.eclipse.jdt.core.dom.PrimitiveType;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SimpleType;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import org.eclipse.jdt.core.dom.WhileStatement;

import sjc.annotation.NonNull;
import sjc.annotation.NonNullElements;
import sjc.annotation.ReadOnly;
import sjc.symboltable.SymbolTable;
import sjc.type.ArrayType;
import sjc.type.BaseType;
import sjc.type.ClassType;
import sjc.type.Type;
import sjc.type.TypeFactory;
import sjc.util.Pair;

/**
 * This class is used to type check a StaticJava {@link CompilationUnit} with a
 * given {@link SymbolTable}.
 * 
 * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
 */
public class TypeChecker
{
    /**
     * This class is used to signal an error in the process of type checking. It
     * contains the {@link ASTNode} that causes the error.
     * 
     * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
     */
    public static class Error
        extends RuntimeException
    {
        /**
         * Holds the {@link ASTNode} that causes this error.
         */
        public final @NonNull @ReadOnly ASTNode node;

        /**
         * Constructs an error from a type checker.
         * 
         * @param node
         *            The {@link ASTNode} that causes this error.
         * @param msg
         *            The message that indicates the cause of this error.
         */
        public Error(@NonNull ASTNode node, @NonNull String msg)
        {
            super(msg);
            assert msg != null && node != null;
            this.node = node;
        }
    }

    /**
     * Declared as protected to disallow creation of this object outside from
     * the methods of this class.
     */
    protected TypeChecker()
    {
    }

    /**
     * Type checks a StaticJava {@link CompilationUnit} with the given
     * {@link SymbolTable} and the given {@link TypeFactory}. It also resolves
     * {@link MethodInvocation} of library call (and put its mapping in the
     * {@link SymbolTable}).
     * 
     * @param tf
     *            The {@link TypeFactory}.
     * @param cu
     *            The StaticJava {@link CompilationUnit}.
     * @param symbolTable
     *            The {@link SymbolTable} of the {@link CompilationUnit}
     * @return The {@link TypeTable}.
     * @throws TypeChecker.Error
     *             If the type checker encounter type error in the
     *             {@link CompilationUnit}.
     */
    public static @NonNull TypeTable check(
        @NonNull TypeFactory tf,
        @NonNull CompilationUnit cu,
        @NonNull SymbolTable symbolTable) throws TypeChecker.Error
    {
        assert tf != null && cu != null && symbolTable != null;

        Visitor v = new Visitor(tf, symbolTable);
        cu.accept(v);
        TypeTable result = new TypeTable(v.resultTypeMap, v.resultMethodTypeMap);
        v.dispose();
        return result;
    }

    /**
     * The visitor for {@link ASTNode} to type check a StaticJava
     * {@link CompilationUnit}.
     * 
     * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
     */
    protected static class Visitor
        extends ASTVisitor
    {
        /**
         * Holds the symbol map of the StaticJava {@link CompilationUnit}.
         */
        protected @NonNullElements Map<ASTNode, Object> symbolMap;

        /**
         * Holds a map of {@link ASTNode} to its {@link Type}.
         */
        public @NonNullElements Map<ASTNode, Type> resultTypeMap;

        /**
         * Holds a map of {@link MethodDeclaration} to its return {@link Type}
         * and its parameter {@link Type}s.
         */
        public @NonNullElements Map<Object, Pair<Type, List<Type>>> resultMethodTypeMap;

        /**
         * The {@link TypeFactory}.
         */
        protected @NonNull TypeFactory tf;

        /**
         * Holds the string {@link ArrayType}.
         */
        protected @NonNull ArrayType stringArrayType;

        /**
         * Holds the main class of this StaticJava {@link CompilationUnit}.
         */
        protected String className;

        /**
         * Holds a method's return {@link Type}.
         */
        protected Type methodReturnType = null;

        /**
         * Holds an expression's {@link Type}.
         */
        protected Type resultingType = null;

        /**
         * Constructs a visitor to type check a StaticJava
         * {@link CompilationUnit} with the given {@link SymbolTable} and the
         * given {@link TypeFactory}.
         * 
         * @param tf
         *            The {@link TypeFactory}.
         * @param st
         *            The {@link SymbolTable} for the {@link CompilationUnit}.
         */
        protected Visitor(@NonNull TypeFactory tf, @NonNull SymbolTable st)
        {
            this.tf = tf;
            this.symbolMap = st.symbolMap;
            resultTypeMap = new HashMap<ASTNode, Type>();
            resultMethodTypeMap = new HashMap<Object, Pair<Type, List<Type>>>();
            stringArrayType = tf.getArrayType(tf
                .getClassType("java.lang.String"));
        }

        @Override public boolean visit(TypeDeclaration node)
        {
            className = node.getName().getIdentifier();
            resultTypeMap.put(node, tf.getClassType(className));
            return super.visit(node);
        }

        @Override public boolean visit(MethodDeclaration node)
        {
            methodReturnType = convertType(node, node.getReturnType2());
            List<Type> paramTypes = new ArrayList<Type>();
            for (Object o : node.parameters())
            {
                SingleVariableDeclaration sdv = (SingleVariableDeclaration) o;
                Type t = convertType(node, sdv.getType());
                paramTypes.add(t);
                resultTypeMap.put(sdv, t);
            }
            resultMethodTypeMap.put(node, new Pair<Type, List<Type>>(
                methodReturnType,
                paramTypes));
            node.getBody().accept(this);
            methodReturnType = null;
            return false;
        }

        @Override public boolean visit(FieldDeclaration node)
        {
            resultTypeMap.put(node, convertType(node, node.getType()));
            return false;
        }

        @Override public boolean visit(VariableDeclarationStatement node)
        {
            resultTypeMap.put(node, convertType(node, node.getType()));
            return false;
        }

        @Override public boolean visit(Assignment node)
        {
            node.getLeftHandSide().accept(this);
            Type lhsType = getResult();
            node.getRightHandSide().accept(this);
            Type rhsType = getResult();
            if (lhsType != rhsType)
            {
                throw new Error(node, "Type mismatch in \"" + node + "\": "
                                      + lhsType + " = " + rhsType);
            }
            // no need to set the type result for assignments since
            // assignments in StaticJava are statements,
            // i.e., they are evaluated for their side-effects.
            return false;
        }

        @Override public boolean visit(BooleanLiteral node)
        {
            setResult(node, tf.Boolean);
            return false;
        }

        @Override public boolean visit(InfixExpression node)
        {
            node.getLeftOperand().accept(this);
            Type lhsType = getResult();
            node.getRightOperand().accept(this);
            Type rhsType = getResult();
            InfixExpression.Operator op = node.getOperator();
            if (op == InfixExpression.Operator.TIMES
                || op == InfixExpression.Operator.DIVIDE
                || op == InfixExpression.Operator.REMAINDER
                || op == InfixExpression.Operator.PLUS
                || op == InfixExpression.Operator.MINUS)
            {
                if (lhsType != tf.Int)
                {
                    throw new Error(
                        node,
                        "Expecting an int type expression as the left-hand operand of \""
                                + op + "\" in \"" + node + "\"");
                }
                if (rhsType != tf.Int)
                {
                    throw new Error(
                        node,
                        "Expecting an int type expression as the right-hand operand of \""
                                + op + "\" in \"" + node + "\"");
                }
                setResult(node, tf.Int);
            }
            else if (op == InfixExpression.Operator.LESS
                     || op == InfixExpression.Operator.GREATER
                     || op == InfixExpression.Operator.LESS_EQUALS
                     || op == InfixExpression.Operator.GREATER_EQUALS)
            {
                if (lhsType != tf.Int)
                {
                    throw new Error(
                        node,
                        "Expecting an int type expression as the left-hand operand of \""
                                + op + "\" in \"" + node + "\"");
                }
                if (rhsType != tf.Int)
                {
                    throw new Error(
                        node,
                        "Expecting an int type expression as the right-hand operand of \""
                                + op + "\" in \"" + node + "\"");
                }
                setResult(node, tf.Boolean);
            }
            else if (op == InfixExpression.Operator.CONDITIONAL_AND
                     || op == InfixExpression.Operator.CONDITIONAL_OR)
            {
                if (lhsType != tf.Boolean)
                {
                    throw new Error(
                        node,
                        "Expecting a boolean type expression as the left-hand operand of \""
                                + op + "\" in \"" + node + "\"");
                }
                if (rhsType != tf.Boolean)
                {
                    throw new Error(
                        node,
                        "Expecting a boolean type expression as the right-hand operand of \""
                                + op + "\" in \"" + node + "\"");
                }
                setResult(node, tf.Boolean);
            }
            else if (op == InfixExpression.Operator.EQUALS
                     || op == InfixExpression.Operator.NOT_EQUALS)
            {
                if (lhsType != rhsType)
                {
                    throw new Error(node, "Type mismatch in \"" + node + "\": "
                        + lhsType + " " + op + " " + rhsType);
                }
                setResult(node, tf.Boolean);
            }
            else
            {
                throw new Error(node, "Unexpected InfixExpression: \'" + node
                                      + "\'");
            }
            return false;
        }

        @Override public boolean visit(MethodInvocation node)
        {
            // note that we don't visit the MethodInvocation's simple name
            // because we want visit(SimpleName) to resolve variable references
            // instead of method names
            String className = node.getExpression() == null
                ? this.className
                : ((SimpleName) node.getExpression()).getIdentifier();
            String methodName = node.getName().getIdentifier();
            int numOfArgs = node.arguments().size();
            Type[] argTypes = new Type[numOfArgs];
            for (int i = 0; i < numOfArgs; i++)
            {
                ((Expression) node.arguments().get(i)).accept(this);
                argTypes[i] = getResult();
            }
            MethodDeclaration md = (MethodDeclaration) symbolMap.get(node);
            if (md == null)
            {
                Method m = resolveMethod(node, className, methodName, argTypes);
                typeCheckMethodInvocation(
                    node,
                    className,
                    methodName,
                    argTypes,
                    m);
            }
            else
            {
                typeCheckMethodInvocation(
                    node,
                    className,
                    methodName,
                    argTypes,
                    md);
            }
            return false;
        }

        @Override public boolean visit(NumberLiteral node)
        {
            setResult(node, tf.Int);
            return false;
        }

        @Override public boolean visit(ParenthesizedExpression node)
        {
            node.getExpression().accept(this);
            setResult(node, getResult());
            return false;
        }

        @Override public boolean visit(PrefixExpression node)
        {
            node.getOperand().accept(this);
            Type t = getResult();
            PrefixExpression.Operator op = node.getOperator();
            if (op == PrefixExpression.Operator.PLUS
                || op == PrefixExpression.Operator.MINUS)
            {
                if (t != tf.Int)
                {
                    throw new Error(
                        node,
                        "Expecting an int type expression as the operand of \""
                                + op + "\" in \"" + node + "\"");
                }
                setResult(node, tf.Int);
            }
            else if (op == PrefixExpression.Operator.NOT)
            {
                if (t != tf.Boolean)
                {
                    throw new Error(
                        node,
                        "Expecting a boolean type expression as the operand of \""
                                + op + "\" in \"" + node + "\"");
                }
                setResult(node, tf.Boolean);
            }
            else
            {
                throw new Error(node, "Unexpected PrefixExpression: \'" + node
                                      + "\'");
            }
            return false;
        }

        @Override public boolean visit(SimpleName node)
        {
            ASTNode parent = node.getParent();
            if (parent instanceof Expression || parent instanceof Statement)
            {
                Object o = symbolMap.get(node);
                if (o instanceof FieldDeclaration)
                {
                    FieldDeclaration fd = (FieldDeclaration) o;
                    setResult(node, convertType(node, fd.getType()));
                }
                else if (o instanceof SingleVariableDeclaration)
                {
                    SingleVariableDeclaration svd = (SingleVariableDeclaration) o;
                    setResult(node, convertType(node, svd.getType()));
                }
                else if (o instanceof VariableDeclarationStatement)
                {
                    VariableDeclarationStatement vds = (VariableDeclarationStatement) o;
                    setResult(node, convertType(node, vds.getType()));
                }
                else
                {
                    throw new Error(node, "Unexpected SimpleName: \'" + node
                                          + "\'");
                }
            }
            return false;
        }

        @Override public boolean visit(ExpressionStatement node)
        {
            Expression e = node.getExpression();
            e.accept(this);
            if (e instanceof Assignment)
            {
                // assignment should not have a resulting type.
                assert getResult() == null;
            }
            else if (node.getExpression() instanceof MethodInvocation)
            {
                // method invocation's result can be any type (including void)
                // so we can ignore it.
                getResult();
            }
            else
            {
                throw new Error(node, "Unexpected SimpleName: \'" + node + "\'");
            }
            return false;
        }

        @Override public boolean visit(IfStatement node)
        {
            node.getExpression().accept(this);
            if (getResult() != tf.Boolean)
            {
                throw new Error(
                    node,
                    "Expecting a boolean type expression as the condition of an if-statement: \""
                            + node.getExpression() + "\"");
            }
            node.getThenStatement().accept(this);
            node.getElseStatement().accept(this);
            return false;
        }

        @Override public boolean visit(ReturnStatement node)
        {
            Expression e = node.getExpression();
            if (methodReturnType == tf.Void && e != null)
            {
                throw new Error(node, "Unexpected return's expression in \""
                                      + node + "\"");
            }
            else if (methodReturnType != tf.Void && e == null)
            {
                throw new Error(node, "Expecting a return's expression in \""
                                      + node + "\"");
            }
            else if (methodReturnType != tf.Void && e != null)
            {
                e.accept(this);
                Type t = getResult();
                if (t != methodReturnType)
                {
                    throw new Error(node, "Expecting " + methodReturnType.name
                                          + " return expression in \"" + node
                                          + "\"");
                }
            }
            return false;
        }

        @Override public boolean visit(WhileStatement node)
        {
            node.getExpression().accept(this);
            Type t = getResult();
            if (t != tf.Boolean)
            {
                throw new Error(
                    node,
                    "Expecting a boolean type expression as the condition of a while-statement: \""
                            + node.getExpression() + "\"");
            }
            node.getBody().accept(this);
            return false;
        }

        protected void dispose()
        {
            symbolMap = null;
            resultTypeMap = null;
            tf = null;
            stringArrayType = null;
            className = null;
            methodReturnType = null;
            resultingType = null;
        }

        protected Type getResult()
        {
            Type result = resultingType;
            resultingType = null;
            return result;
        }

        protected void setResult(Expression e, Type t)
        {
            assert t != null;
            resultTypeMap.put(e, t);
            resultingType = t;
        }

        protected Type convertType(ASTNode node, org.eclipse.jdt.core.dom.Type t)
        {
            if (t instanceof PrimitiveType)
            {
                PrimitiveType.Code ptc = ((PrimitiveType) t)
                    .getPrimitiveTypeCode();
                if (ptc == PrimitiveType.BOOLEAN)
                {
                    return tf.Boolean;
                }
                else if (ptc == PrimitiveType.INT)
                {
                    return tf.Int;
                }
                else if (ptc == PrimitiveType.VOID)
                {
                    return tf.Void;
                }
            }
            else if (t instanceof SimpleType)
            {
                SimpleType st = (SimpleType) t;
                String name = st.getName().getFullyQualifiedName();
                if ("String".equals(name.toString())
                    || "java.lang.String".equals(name.toString()))
                {
                    return stringArrayType.baseType;
                }
            }
            else if (t instanceof org.eclipse.jdt.core.dom.ArrayType)
            {
                org.eclipse.jdt.core.dom.ArrayType at = (org.eclipse.jdt.core.dom.ArrayType) t;
                BaseType bt = (BaseType) convertType(node, at.getElementType());
                return tf.getArrayType(bt);
            }
            throw new Error(null, "Unexpected Type: \'" + t + "\'");
        }

        protected Type convertType(ASTNode node, Class c)
        {
            if (c == void.class)
            {
                return tf.Void;
            }
            if (c == boolean.class)
            {
                return tf.Boolean;
            }
            else if (c == int.class)
            {
                return tf.Int;
            }
            else if (c == String[].class)
            {
                return stringArrayType;
            }
            else if (c.isPrimitive())
            {
                throw new Error(null, "Unexpected primitive type (Class): \'"
                                      + c.getName() + "\'");
            }
            else if (!c.isArray())
            {
                return tf.getClassType(className);
            }
            else
            {
                return tf.getArrayType((BaseType) convertType(node, c
                    .getComponentType()));
            }
        }

        protected Class convertType(ASTNode node, Type t)
        {
            if (t == tf.Void)
            {
                return void.class;
            }
            else if (t == tf.Boolean)
            {
                return boolean.class;
            }
            else if (t == tf.Int)
            {
                return int.class;
            }
            else if (t == stringArrayType)
            {
                return String[].class;
            }
            else if (t instanceof ClassType)
            {
                try
                {
                    return Class.forName(((ClassType) t).name);
                }
                catch (ClassNotFoundException e)
                {
                    throw new Error(node, "Unresolvable Type: \'" + t + "\'");
                }
            }
            else if (t instanceof ArrayType)
            {
                ArrayType at = (ArrayType) t;
                BaseType bt = at.baseType;
                if (bt == tf.Boolean)
                {
                    return boolean[].class;
                }
                else if (bt == tf.Int)
                {
                    return int[].class;
                }
                else if (bt instanceof ClassType)
                {
                    try
                    {
                        return Class
                            .forName("[L" + ((ClassType) bt).name + ";");
                    }
                    catch (ClassNotFoundException e)
                    {
                        throw new Error(node, "Unresolvable Type: \'" + t
                                              + "\'");
                    }
                }
                else
                {
                    throw new Error(node, "Unexpected BaseType: \'" + t + "\'");
                }
            }
            else
            {
                throw new Error(node, "Unexpected Type: \'" + t + "\'");
            }
        }

        protected Method resolveMethod(
            MethodInvocation node,
            String className,
            String methodName,
            Type[] argTypes)
        {
            try
            {
                int numOfArgs = argTypes.length;
                Class[] paramTypes = new Class[numOfArgs];
                for (int i = 0; i < numOfArgs; i++)
                {
                    paramTypes[i] = convertType(node, argTypes[i]);
                }
                Class c = Class.forName(className);
                Method m = c.getMethod(methodName, paramTypes);
                symbolMap.put(node, m);
                return m;
            }
            catch (ClassNotFoundException e)
            {
                throw new Error(node, "Unresolvable class \"" + className
                                      + "\"");
            }
            catch (SecurityException e)
            {
                throw new Error(node, "Unresolvable method \"" + className
                                      + "." + methodName + "\"");
            }
            catch (NoSuchMethodException e)
            {
                throw new Error(node, "Unresolvable method \"" + className
                                      + "." + methodName + "\"");
            }
        }

        protected void typeCheckMethodInvocation(
            MethodInvocation node,
            String className,
            String methodName,
            Type[] argTypes,
            Method m)
        {
            Class[] paramTypeClasses = m.getParameterTypes();
            int numOfParams = paramTypeClasses.length;
            if (argTypes.length != numOfParams)
            {
                throw new Error(
                    node,
                    "Wrong number of arguments to invoke method \""
                            + methodName + "\" in \"" + node + "\"");
            }
            List<Type> paramTypes = new ArrayList<Type>();
            for (int i = 0; i < numOfParams; i++)
            {
                Type t = convertType(node, paramTypeClasses[i]);
                if (t != argTypes[i])
                {
                    throw new Error(node, "Type mismatch the " + i
                                          + " argument in \"" + node + "\"");
                }
                paramTypes.add(t);
            }
            Type returnType = convertType(node, m.getReturnType());
            if (!resultMethodTypeMap.containsKey(m))
            {
                resultMethodTypeMap.put(m, new Pair<Type, List<Type>>(
                    returnType,
                    paramTypes));
            }
            setResult(node, returnType);
        }

        protected void typeCheckMethodInvocation(
            MethodInvocation node,
            String className,
            String methodName,
            Type[] argTypes,
            MethodDeclaration md)
        {
            int numOfParams = md.parameters().size();
            if (argTypes.length != numOfParams)
            {
                throw new Error(
                    node,
                    "Wrong number of arguments to invoke method \""
                            + methodName + "\" in \"" + node + "\"");
            }
            for (int i = 0; i < numOfParams; i++)
            {
                Type t = convertType(node, ((SingleVariableDeclaration) md
                    .parameters()
                    .get(i)).getType());
                if (t != argTypes[i])
                {
                    throw new Error(node, "Type mismatch the " + i
                                          + " argument in \"" + node + "\"");
                }
            }
            Type returnType = convertType(node, md.getReturnType2());
            setResult(node, returnType);
        }
    }
}
