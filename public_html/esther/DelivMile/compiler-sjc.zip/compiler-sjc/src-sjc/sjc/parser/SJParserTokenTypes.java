// $ANTLR : "sj.g" -> "SJLexer.java"$

package sjc.parser;
	
import java.io.Reader;

import java.math.BigInteger;

public interface SJParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int LITERAL_public = 4;
	int LITERAL_class = 5;
	int IDENT = 6;
	int LCURLY = 7;
	int LITERAL_static = 8;
	int SEMI = 9;
	int RCURLY = 10;
	int LITERAL_void = 11;
	int LPAREN = 12;
	int LBRACK = 13;
	int RBRACK = 14;
	int RPAREN = 15;
	int LITERAL_boolean = 16;
	int LITERAL_int = 17;
	int COMMA = 18;
	int ASSIGN = 19;
	int LITERAL_if = 20;
	int LITERAL_else = 21;
	int LITERAL_while = 22;
	int LITERAL_return = 23;
	int LOR = 24;
	int LAND = 25;
	int NOT_EQUAL = 26;
	int EQUAL = 27;
	int LT = 28;
	int GT = 29;
	int LE = 30;
	int GE = 31;
	int PLUS = 32;
	int MINUS = 33;
	int STAR = 34;
	int DIV = 35;
	int MOD = 36;
	int NOT = 37;
	int NUM_INT = 38;
	int LITERAL_true = 39;
	int LITERAL_false = 40;
	int LITERAL_null = 41;
	int DOT = 42;
	int WS = 43;
}
