package sjc.analysis;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import org.eclipse.jdt.core.dom.WhileStatement;

import sjc.annotation.NonNull;
import sjc.symboltable.SymbolTable;
import sjc.util.Pair;

public class UninitializedReferenceAnalysis {
	public Set<Pair<Statement, String>> uninitializedReferences(ASTNode method, CFG cfg, SymbolTable st) {
		ReachingDefinitionAnalysis rda = new ReachingDefinitionAnalysis(st, cfg);
        rda.computeFixPoint();
		VariableReferenceVisitor vrv = new VariableReferenceVisitor(st.symbolMap);
		StatementVisitor stmtVisitor = new StatementVisitor();
		return stmtVisitor.findUninitializedReferences(method, cfg, vrv, rda);
    }
	
	protected static class StatementVisitor extends ASTVisitor { 
		protected @NonNull Set<Pair<Statement, String>> result;
		protected @NonNull CFG cfg;
		protected @NonNull VariableReferenceVisitor vrv;
		protected @NonNull ReachingDefinitionAnalysis rda;
		
	    Set<Pair<Statement, String>> findUninitializedReferences(ASTNode method, CFG cfg, 
				VariableReferenceVisitor vrv, ReachingDefinitionAnalysis rda) {
		    result = new HashSet<Pair<Statement, String>>();
		    this.cfg = cfg;
			this.vrv = vrv;
			this.rda = rda;
		    method.accept(this);
		    return result;
	    }
		
		
		
		@Override public boolean visit(IfStatement s) {
			Set<String> varRefs = vrv.collectVarRefs(s.getExpression());
			addUninitializedReferences(s, varRefs);
			return true;
		}
		
		@Override public boolean visit(ExpressionStatement s) {
			Set<String> varRefs;
            Expression e = s.getExpression();
            if (e instanceof Assignment) {
				e = ((Assignment)e).getRightHandSide();
				varRefs = vrv.collectVarRefs(e);
			} else if (e instanceof MethodInvocation) {
				varRefs = vrv.collectVarRefs(e);
			} else {
				return false;
			}
			addUninitializedReferences(s, varRefs);
			return false;
		}
		
		@Override public boolean visit(ReturnStatement s) {
			Set<String> varRefs;
			if (s.getExpression() != null) {
				varRefs = vrv.collectVarRefs(s.getExpression());
				addUninitializedReferences(s, varRefs);
			}
			return false;
		}
		
		@Override public boolean visit(WhileStatement s) {
			Set<String> varRefs = vrv.collectVarRefs(s.getExpression());
			addUninitializedReferences(s, varRefs);
			return true;
		}
		
		protected void addUninitializedReferences(Statement s, Set<String> varRefs) {	
			if (!varRefs.isEmpty()) {
				Set<Pair<String, ASTNode>> defs = rda.getInSet(s);
				// Look for reaching definitions for referenced variables
				for (Pair<String, ASTNode> p : defs) {
					if (varRefs.contains(p.first)) {
						// check to see if any of the reaching definitions is
						// a VariableDeclarationStatement, i.e., the indicator for 
						// no definition
						if (p.second instanceof VariableDeclarationStatement) {
							VariableDeclarationFragment vdf = 
								(VariableDeclarationFragment)((VariableDeclarationStatement)p.second).fragments().get(0);
							result.add(new Pair<Statement, String>(s, vdf.getName().getIdentifier()));
						}
					}
				}
			}
		}	
	}
	
	/**
     * The visitor for {@link ASTNode} to gather referenced names.
     * This is identical to the visitor in LiveVariableAnalysis and could
     * be refactored to reduce the duplication.
     * 
     * Actually, because the RD analysis represents variables as Strings instead
     * of decl nodes, I have to modify the LV visitor to return a set of Strings - Yuck!
     */
    protected static class VariableReferenceVisitor extends ASTVisitor { 
		/**
	     * Holds the declarations for simple names (looked up via symbolMap).
	     */
		protected @NonNull Set<String> result;
		protected @NonNull Map<ASTNode, Object> symbolMap;
		
		VariableReferenceVisitor(Map<ASTNode, Object> symbolMap) {
			super();
			this.symbolMap = symbolMap;
		}
	   
	    Set<String> collectVarRefs(ASTNode node) {
		   result = new HashSet<String>();
		   node.accept(this);
		   return result;
	    }
		
        @Override public boolean visit(SimpleName node)
        {
           ASTNode parent = node.getParent();

           // Note that we have to make sure that at this point, the node
           // only corresponds to a variable reference
		   if (parent instanceof Expression) {
			   ASTNode decl = (ASTNode)symbolMap.get(node);
			   if (decl instanceof VariableDeclarationFragment || 
				   decl instanceof VariableDeclarationStatement ||
				   decl instanceof SingleVariableDeclaration ||
				   decl instanceof FieldDeclaration) {
				   result.add(node.getIdentifier());
				   //System.out.println("Found name " + node + " with decl " + decl);
			   }
           }
           return false;
        }
    }	
}
