package sjc.analysis;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import sjc.annotation.NonNull;
import sjc.symboltable.SymbolTable;
import sjc.util.Pair;
import sjc.util.Util;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;

/**
 * An instance of MonotonicDataFlowFramework to compute reaching definition. The
 * lattice element of this analysis is a {@link Pair} of {@link String} which
 * represents a field, a parameter, or a local variable name, and
 * {@link FieldDeclaration}, {@link SingleVariableDeclaration},
 * {@link Assignment} (in {@link ExpressionStatement}), respectively, which
 * indicates the last definition of the variable (i.e., a field or a method
 * parameter declaration is considered as the field or the parameter initial
 * definition).
 * 
 * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
 */
public class ReachingDefinitionAnalysis
    extends MonotonicDataFlowFramework<Pair<String, ASTNode>>
{
    protected Map<ASTNode, Object> symbolMap;

    /**
     * Create a Reaching Definition analysis with the given {@link SymbolTable}
     * and {@link CFG}.
     * 
     * @param symbolTable
     *            The {@link SymbolTable}.
     * @param cfg
     *            The {@link CFG}.
     */
    public ReachingDefinitionAnalysis(
        @NonNull SymbolTable symbolTable,
        @NonNull CFG cfg)
    {
        super(cfg, true, true);
        assert symbolTable != null;
        symbolMap = symbolTable.symbolMap;
    }

    @Override public void computeFixPoint()
    {
        Set<Pair<String, ASTNode>> init = new HashSet<Pair<String, ASTNode>>();
        for (ASTNode n : symbolMap.keySet())
        {
            if (n instanceof SimpleName)
            {
                Object o = symbolMap.get(n);
                if (o instanceof FieldDeclaration)
                {
                    init.add(new Pair<String, ASTNode>(((SimpleName) n)
                        .getIdentifier(), (FieldDeclaration) o));
                }
            }
        }
        for (Object o : cfg.md.parameters())
        {
            SingleVariableDeclaration svd = (SingleVariableDeclaration) o;
            init.add(new Pair<String, ASTNode>(
                svd.getName().getIdentifier(),
                svd));
        }
        for (Object o : cfg.md.getBody().statements())
        {
            if (o instanceof VariableDeclarationStatement)
            {
                VariableDeclarationStatement vdf = (VariableDeclarationStatement) o;
                init.add(new Pair<String, ASTNode>(
                    ((VariableDeclarationFragment) vdf.fragments().get(0))
                        .getName()
                        .getIdentifier(),
                    vdf));
            }
            else
            {
                break;
            }
        }
        computeFixPoint(init);
    }

    @Override public String getAnalysisName()
    {
        return "Reaching Definition";
    }

    @Override public String toString(Pair<String, ASTNode> e)
    {
        return Util.getFirstLine(e.second);
    }

    @Override protected Set<Pair<String, ASTNode>> gen(
        Set<Pair<String, ASTNode>> set,
        Statement s)
    {
        Set<Pair<String, ASTNode>> result = new HashSet<Pair<String, ASTNode>>();
        String lhsLocalName = getLHSVarName(s);
        if (lhsLocalName != null)
        {
            result.add(new Pair<String, ASTNode>(lhsLocalName, s));
        }
        return result;
    }

    @Override protected Set<Pair<String, ASTNode>> kill(
        Set<Pair<String, ASTNode>> set,
        Statement s)
    {
        Set<Pair<String, ASTNode>> result = new HashSet<Pair<String, ASTNode>>();
        String lhsLocalName = getLHSVarName(s);
        if (lhsLocalName != null)
        {
            for (Pair<String, ASTNode> p : set)
            {
                if (p.first.equals(lhsLocalName))
                {
                    result.add(p);
                }
            }
        }
        return result;
    }

    protected String getLHSVarName(ASTNode s)
    {
        if (s instanceof ExpressionStatement)
        {
            ExpressionStatement es = (ExpressionStatement) s;
            Expression e = es.getExpression();
            if (e instanceof Assignment)
            {
                Assignment a = (Assignment) e;
                Expression lhs = a.getLeftHandSide();
                SimpleName sn = (SimpleName) lhs;
                return sn.getIdentifier();
            }
        }
        return null;
    }
}
