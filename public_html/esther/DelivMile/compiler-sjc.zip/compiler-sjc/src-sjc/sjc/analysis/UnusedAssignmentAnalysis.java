package sjc.analysis;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.Statement;

import sjc.annotation.NonNull;
import sjc.symboltable.SymbolTable;

public class UnusedAssignmentAnalysis {
	public Set<Assignment> unusedAssignments(ASTNode method, CFG cfg, SymbolTable st) {
		LiveVariableAnalysis lva = new LiveVariableAnalysis(st, cfg);
        lva.computeFixPoint();
		//System.out.println(lva.getResultString());
        //System.out.println();
		AssignmentVisitor assignVisitor = new AssignmentVisitor();
		return assignVisitor.findUnusedAssignments(method, cfg, lva, st);
    }
	
	protected static class AssignmentVisitor extends ASTVisitor { 
		protected @NonNull Set<Assignment> result;
		protected @NonNull CFG cfg;
		protected @NonNull LiveVariableAnalysis lva;
		protected @NonNull Map<ASTNode, Object> symbolMap;
		
	    Set<Assignment> findUnusedAssignments(ASTNode method, CFG cfg, 
											  LiveVariableAnalysis lva,
											  SymbolTable st) {
		    result = new HashSet<Assignment>();
		    this.cfg = cfg;
			this.lva = lva;
			this.symbolMap = st.symbolMap;
		    method.accept(this);
		    return result;
	    }
		
		/**
		 * This method implementation assumes that an Assignment only appears
		 * under an ExpressionStatement and that the LHS is a SimpleName.
		 */
		@Override public boolean visit(Assignment s) {
			Set<ASTNode> subsequentUses = lva.getInSet((Statement)s.getParent());
			// Here we make the SJ specific assumption that the 
			SimpleName lhs = (SimpleName)((Assignment)s).getLeftHandSide();
			if (!subsequentUses.contains((ASTNode)symbolMap.get(lhs))) {
				result.add(s);
			} 
			return true;
		}	
	}
	
	
}
