package sjc.analysis;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import org.eclipse.jdt.core.dom.WhileStatement;

import sjc.annotation.NonNull;
import sjc.symboltable.SymbolTable;


/**
 * @author dwyer@cse.unl.edu
 * 
 * This analysis is formulated over the powerset-lattice of declaration {@link ASTNode}s.
 * Unfortunately, there are four different kinds of declaration nodes in our ASTs 
 * this makes for some ugliness in handling the four different cases.   It would be
 * simpler to formulate the analysis over the powerset-lattice of variable names (encoded
 * as strings).  Since our symbol table doesn't allow querying by name, I decided to
 * go with the decl nodes; there is also the added advantage of disambiguating variable names
 * that are reused in multiple classes.
 *
 * This analysis makes no attempt to reason about the liveness of fields since that is
 * a fundamentally inter-procedural analysis.
 */
public class LiveVariableAnalysis extends MonotonicDataFlowFramework<ASTNode> {
	protected Map<ASTNode, Object> symbolMap;
	
	protected Visitor varRefVisitor;

    /**
     * Create a Live Variable analysis with the given {@link SymbolTable}
     * and {@link CFG}.
     * 
     * @param symbolTable
     *            The {@link SymbolTable}.
     * @param cfg
     *            The {@link CFG}.
     */
    public LiveVariableAnalysis(
        @NonNull SymbolTable symbolTable,
        @NonNull CFG cfg)
    {
		// backward flow, may analysis
        super(cfg, false, true);
        assert symbolTable != null;
        symbolMap = symbolTable.symbolMap;
		varRefVisitor = new Visitor(symbolMap);
    }
	
	/**
	 * The initial value at the extremal (i.e., last node) for this analysis
	 * is the empty set (i.e., there are no subsequent uses of parameters or locals).
	 */
	@Override public void computeFixPoint() {
		Set<ASTNode> init = new HashSet<ASTNode>();
        computeFixPoint(init);
	}

	/**
	 * Need to handle the four different kinds of declaration nodes here.
	 * We return the name of the variable only to support clean printouts of
	 * dataflow facts by the MDF.
	 */
	@Override public String toString(ASTNode n) {
		if (n instanceof VariableDeclarationFragment) {
			return ((VariableDeclarationFragment)n).getName().toString();
		} else if (n instanceof SingleVariableDeclaration) {
			return ((SingleVariableDeclaration)n).getName().toString();
		} else if (n instanceof VariableDeclarationStatement) {
			VariableDeclarationFragment vdf = 
				(VariableDeclarationFragment) ((VariableDeclarationStatement)n).fragments().get(0);
			return vdf.getName().toString();
		} else if (n instanceof FieldDeclaration) {
			VariableDeclarationFragment vdf = 
				(VariableDeclarationFragment) ((FieldDeclaration)n).fragments().get(0);
			return vdf.getName().toString();
		} else {
			assert false;
			return "error";
		}
	}

	@Override public String getAnalysisName() {
		return "Live Variables";
	}

	/**
	 * For statements that evaluate an expression, all variables referenced
	 * in the expression are live prior to executing this statement.
	 * We handle all such statements, e.g., assignments, if, while, method call,
	 * in a visitor.
	 */
	@Override protected Set<ASTNode> gen(Set<ASTNode> set, Statement s) {
		Set<ASTNode> genSet = new HashSet<ASTNode>();
		
		// Any statement not caught in one of these cases has an empty gen set
		if (s instanceof ExpressionStatement) {
			ExpressionStatement es = (ExpressionStatement) s;
            Expression e = es.getExpression();
            if (e instanceof Assignment) {
				e = ((Assignment)e).getRightHandSide();
				genSet = varRefVisitor.collectVarRefs(e);
			} else if (e instanceof MethodInvocation) {
				genSet = varRefVisitor.collectVarRefs(e);
			}
		} else if (s instanceof IfStatement) {
			Expression e = ((IfStatement)s).getExpression();
			genSet = varRefVisitor.collectVarRefs(e);
		} else if (s instanceof WhileStatement) {
			Expression e = ((WhileStatement)s).getExpression();
			genSet = varRefVisitor.collectVarRefs(e);
			
		}
		//System.out.println("Gen set for " + s + " = " + genSet);
        return genSet;
	}

	/**
	 * Only assignment statements kill liveness information.
	 */
	@Override protected Set<ASTNode> kill(Set<ASTNode> set, Statement s) {
		Set<ASTNode> killSet = new HashSet<ASTNode>();
		if (s instanceof ExpressionStatement) {
            ExpressionStatement es = (ExpressionStatement) s;
            Expression e = es.getExpression();
            if (e instanceof Assignment) {
				// Access the declaration of the LHS variable.  Here we
				// assume that the LHS is a SimpleName.
				// In general, we would use a visitor to access the name.
				Expression lhs = ((Assignment)e).getLeftHandSide();
				if (lhs instanceof SimpleName) {
					killSet.add((ASTNode)symbolMap.get(lhs));
				}
            }
        }
		//System.out.println("Kill set for " + s + " = " + killSet);
        return killSet;
	}
	
	/**
     * The visitor for {@link ASTNode} to gather referenced names.
     *
     */
    protected static class Visitor
       extends ASTVisitor
    { 
		/**
	     * Holds the declarations for simple names (looked up via symbolMap).
	     */
		protected @NonNull Set<ASTNode> result;
		protected @NonNull Map<ASTNode, Object> symbolMap;
		
		Visitor(Map<ASTNode, Object> symbolMap) {
			super();
			this.symbolMap = symbolMap;
		}
	   
	    Set<ASTNode> collectVarRefs(ASTNode node) {
		   result = new HashSet<ASTNode>();
		   node.accept(this);
		   return result;
	    }
		
        @Override public boolean visit(SimpleName node)
        {
           ASTNode parent = node.getParent();

           // Note that we have to make sure that at this point, the node
           // only corresponds to a variable reference
		   if (parent instanceof Expression) {
			   ASTNode decl = (ASTNode)symbolMap.get(node);
			   if (decl instanceof VariableDeclarationFragment || 
				   decl instanceof VariableDeclarationStatement ||
				   decl instanceof SingleVariableDeclaration ||
				   decl instanceof FieldDeclaration) {
				   result.add(decl);
				   //System.out.println("Found name " + node + " with decl " + decl);
			   }
           }
           return false;
        }
    }
}
