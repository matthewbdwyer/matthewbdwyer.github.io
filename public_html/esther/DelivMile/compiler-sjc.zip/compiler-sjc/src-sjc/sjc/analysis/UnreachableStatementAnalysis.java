package sjc.analysis;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.WhileStatement;

import sjc.annotation.NonNull;

public class UnreachableStatementAnalysis {
	
	public Set<Statement> unreachableStatements(ASTNode method, CFG cfg) {
		return (new Visitor()).findUnreachableStatements(method, cfg);
    }
	
	protected static class Visitor extends ASTVisitor
    { 
		protected @NonNull Set<Statement> result;
		protected @NonNull CFG cfg;
		
	    Set<Statement> findUnreachableStatements(ASTNode method, CFG cfg) {
			assert cfg != null;
		    result = new HashSet<Statement>();
		    this.cfg = cfg;
		    method.accept(this);
		    return result;
	    }
		
		@Override public boolean visit(IfStatement s) {
			if (noPredsSuccs(s)) {
				result.add(s);
				return false;
			} else {
				return true;
			}
		}
		
		@Override public boolean visit(ExpressionStatement s) {
			if (noPredsSuccs(s)) {
				result.add(s);
			} 
			return false;
		}
		
		@Override public boolean visit(ReturnStatement s) {
			if (noPredsSuccs(s)) {
				result.add(s);
			} 
			return false;
		}
		
		@Override public boolean visit(WhileStatement s) {
			if (noPredsSuccs(s)) {
				result.add(s);
				return false;
			} else {
				return true;
			}
		}	
		
		private boolean noPredsSuccs(Statement s) {
			return cfg.succs.get(s) == null && cfg.preds.get(s) == null;
		}
		
	}
}
