package sjc.codegen;

import static org.objectweb.asm.Opcodes.*;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.BooleanLiteral;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.Modifier;
import org.eclipse.jdt.core.dom.NumberLiteral;
import org.eclipse.jdt.core.dom.PrefixExpression;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import org.eclipse.jdt.core.dom.WhileStatement;
import org.eclipse.jdt.core.dom.Modifier.ModifierKeyword;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;

import sjc.annotation.NonNull;
import sjc.annotation.NonNullElements;
import sjc.annotation.NonNullElementsOnly;
import sjc.annotation.PossiblyNull;
import sjc.annotation.ReadOnly;
import sjc.annotation.ReadOnlyElements;
import sjc.symboltable.SymbolTable;
import sjc.type.ArrayType;
import sjc.type.BooleanType;
import sjc.type.ClassType;
import sjc.type.IntType;
import sjc.type.Type;
import sjc.type.VoidType;
import sjc.type.checker.TypeTable;
import sjc.util.Pair;

/**
 * This class is used to translate a StaticJava {@link CompilationUnit} to
 * {@link ClassByteCodes} that represent a Java 1.5 class files.
 * 
 * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
 */
public class ByteCodeGenerator
{
    /**
     * This class is used to signal an error in the process of generating
     * bytecode. It contains the {@link ASTNode} that causes the error.
     * 
     * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
     */
    public static class Error
        extends RuntimeException
    {
        /**
         * Holds the {@link ASTNode} that causes this error.
         */
        public final @NonNull @ReadOnly ASTNode node;

        /**
         * Constructs an error of bytecode generation.
         * 
         * @param node
         *            The {@link ASTNode} that causes this error.
         * @param msg
         *            The message that indicates the cause of this error.
         */
        public Error(@NonNull ASTNode node, @NonNull String msg)
        {
            super(msg);
            assert msg != null && node != null;
            this.node = node;
        }
    }

    /**
     * Declared as protected to disallow creation of this object outside from
     * the methods of this class.
     */
    protected ByteCodeGenerator()
    {
    }

    /**
     * Generates a {@link ClassByteCodes} that represents the class files for
     * the given StaticJava {@link CompilationUnit} with the given
     * {@link SymbolTable} and {@link TypeTable}.
     * 
     * @param cu
     *            The StaticJava {@link CompilationUnit}.
     * @param st
     *            The {@link SymbolTable} of the {@link CompilationUnit}.
     * @param tt
     *            The {@link TypeTable} of the {@link CompilationUnit}.
     * @return The {@link ClassByteCodes} that represents the class files for
     *         the given StaticJava {@link CompilationUnit} with the given
     *         {@link SymbolTable} and {@link TypeTable}.
     * @throws ByteCodeGenerator.Error
     *             If the generator encounter unexpected error.
     */
    public static @NonNull ClassByteCodes generate(
        @NonNull CompilationUnit cu,
        @NonNull SymbolTable st,
        @NonNull TypeTable tt) throws ByteCodeGenerator.Error
    {
        assert cu != null && st != null && tt != null;

        Visitor v = new Visitor(st, tt);
        cu.accept(v);
        ClassByteCodes result = new ClassByteCodes(
            v.mainClassName,
            v.mainClassBytes);
        v.dispose();
        return result;
    }

    /**
     * The visitor for {@link ASTNode} to generate bytecodes.
     * 
     * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
     */
    protected static class Visitor
        extends ASTVisitor
    {
        protected @NonNull ClassWriter cw;

        protected @PossiblyNull FieldVisitor fv;

        protected @PossiblyNull MethodVisitor mv;

        public @PossiblyNull String mainClassName;

        public @PossiblyNull byte[] mainClassBytes;

        protected @NonNullElements @ReadOnlyElements Map<ASTNode, Object> symbolMap;

        protected @NonNullElements @ReadOnlyElements Map<ASTNode, Type> typeMap;

        protected @NonNullElements @ReadOnlyElements Map<Object, Pair<Type, List<Type>>> methodTypeMap;

        protected @NonNull @NonNullElementsOnly List<Pair<String, Type>> localNamesTypes = new ArrayList<Pair<String, Type>>();

        protected @NonNull @NonNullElementsOnly Map<String, Integer> localIndexMap = new HashMap<String, Integer>();

        protected Visitor(@NonNull SymbolTable st, @NonNull TypeTable tt)
        {
            assert st != null && tt != null;
            symbolMap = st.symbolMap;
            typeMap = tt.typeMap;
            methodTypeMap = tt.methodTypeMap;
        }

        @Override public boolean visit(TypeDeclaration node)
        {
            mainClassName = node.getName().getIdentifier();
            cw = new ClassWriter(true, false);
            cw.visit(
                V1_5,
                ACC_PUBLIC + ACC_SUPER,
                mainClassName,
                null,
                "java/lang/Object",
                null);
            cw.visitSource(null, null);
            generateConstructor(mainClassName);
            for (Object o : node.bodyDeclarations())
            {
                ((ASTNode) o).accept(this);
            }
            cw.visitEnd();
            mainClassBytes = cw.toByteArray();
            cw = null;
            return false;
        }

        @Override public boolean visit(MethodDeclaration node)
        {
            String methodName = node.getName().getIdentifier();
            int modifiers = convertModifiers(node, node.modifiers());
            Pair<Type, List<Type>> methodType = methodTypeMap.get(node);
            String methodDesc = getMethodDescriptor(
                methodType.first,
                methodType.second);
            mv = cw.visitMethod(modifiers, methodName, methodDesc, null, null);
            mv.visitCode();
            Label initLabel = new Label();
            mv.visitLabel(initLabel);

            buildLocalIndexTable(node);

            Statement lastStatement = null;
            for (Object o : node.getBody().statements())
            {
                if (!(o instanceof VariableDeclarationStatement))
                {
                    ((ASTNode) o).accept(this);
                }
                lastStatement = (Statement) o;
            }

            // TODO: this is a hack, we need an analysis to see whether we need
            // a return statement or not.
            if (!(lastStatement instanceof ReturnStatement))
            {
                if (methodType.first instanceof VoidType)
                {
                    mv.visitInsn(RETURN);
                }
            }

            Label endLabel = new Label();
            mv.visitLabel(endLabel);

            int i = 0;
            for (Pair<String, Type> p : localNamesTypes)
            {
                mv.visitLocalVariable(
                    p.first,
                    convertType(p.second),
                    null,
                    initLabel,
                    endLabel,
                    i);
                i++;
            }

            mv.visitMaxs(0, 0);
            mv.visitEnd();

            localNamesTypes.clear();
            localIndexMap.clear();
            return false;
        }

        @Override public boolean visit(FieldDeclaration node)
        {
            int modifiers = convertModifiers(node, node.modifiers());
            VariableDeclarationFragment vdf = (VariableDeclarationFragment) node
                .fragments()
                .get(0);
            cw.visitField(
                modifiers,
                vdf.getName().getIdentifier(),
                convertType(typeMap.get(node)),
                null,
                null).visitEnd();

            return false;
        }

        @Override public boolean visit(Assignment node)
        {
            node.getRightHandSide().accept(this);
            ASTNode lhsNode = node.getLeftHandSide();
            String varName = ((SimpleName) lhsNode).getIdentifier();
            Object lhsDecl = symbolMap.get(lhsNode);
            if (lhsDecl instanceof FieldDeclaration)
            {
                FieldDeclaration fd = (FieldDeclaration) lhsDecl;
                String className = ((TypeDeclaration) fd.getParent())
                    .getName()
                    .getIdentifier();
                mv.visitFieldInsn(
                    PUTSTATIC,
                    className,
                    varName,
                    convertType(typeMap.get(fd)));
            }
            else
            {
                mv.visitVarInsn(ISTORE, localIndexMap.get(varName).intValue());
            }
            return false;
        }

        @Override public boolean visit(IfStatement node)
        {
            Label elseOrEndLabel = new Label();
            node.getExpression().accept(this);
            mv.visitJumpInsn(IFEQ, elseOrEndLabel);
            node.getThenStatement().accept(this);
            Block elseBlock = (Block) node.getElseStatement();
            if (elseBlock == null)
            {
                mv.visitLabel(elseOrEndLabel);
            }
            else
            {
                Label endLabel = new Label();
                mv.visitJumpInsn(GOTO, endLabel);
                mv.visitLabel(elseOrEndLabel);
                elseBlock.accept(this);
                mv.visitLabel(endLabel);
            }
            return false;
        }

        @Override public boolean visit(WhileStatement node)
        {
            Label loopLabel = new Label();
            Label endLabel = new Label();
            mv.visitLabel(loopLabel);
            node.getExpression().accept(this);
            mv.visitJumpInsn(IFEQ, endLabel);
            node.getBody().accept(this);
            mv.visitJumpInsn(GOTO, loopLabel);
            mv.visitLabel(endLabel);
            return false;
        }

        @Override public boolean visit(ExpressionStatement node)
        {
            Expression e = node.getExpression();
            e.accept(this);
            Type t = typeMap.get(e);
            if (t == null || t instanceof VoidType)
            {
                // skip
            }
            else
            {
                mv.visitInsn(POP);
            }
            return false;
        }

        @Override public boolean visit(ReturnStatement node)
        {
            Expression e = node.getExpression();
            if (e == null)
            {
                mv.visitInsn(RETURN);
            }
            else
            {
                e.accept(this);
                mv.visitInsn(IRETURN);
            }
            return false;
        }

        @Override public boolean visit(BooleanLiteral node)
        {
            if (node.booleanValue())
            {
                mv.visitInsn(ICONST_1);
            }
            else
            {
                mv.visitInsn(ICONST_0);
            }
            return false;
        }

        @Override public boolean visit(NumberLiteral node)
        {
            generateIntConst(Integer.parseInt(node.getToken()));
            return false;
        }

        @Override public boolean visit(PrefixExpression node)
        {
            node.getOperand().accept(this);
            PrefixExpression.Operator op = node.getOperator();
            if (op == PrefixExpression.Operator.PLUS)
            {
                // do nothing
            }
            else if (op == PrefixExpression.Operator.MINUS)
            {
                mv.visitInsn(INEG);
            }
            else if (op == PrefixExpression.Operator.NOT)
            {
                Label falseLabel = new Label();
                Label endLabel = new Label();
                mv.visitJumpInsn(IFEQ, falseLabel);
                mv.visitInsn(ICONST_0);
                mv.visitJumpInsn(GOTO, endLabel);
                mv.visitLabel(falseLabel);
                mv.visitInsn(ICONST_1);
                mv.visitLabel(endLabel);
            }
            return false;
        }

        @Override public boolean visit(InfixExpression node)
        {
            InfixExpression.Operator op = node.getOperator();
            node.getLeftOperand().accept(this);
            if (op == InfixExpression.Operator.CONDITIONAL_AND)
            {
                mv.visitInsn(DUP);
                Label falseLabel = new Label();
                mv.visitJumpInsn(IFEQ, falseLabel);
                mv.visitInsn(POP);
                node.getRightOperand().accept(this);
                mv.visitLabel(falseLabel);
            }
            else if (op == InfixExpression.Operator.CONDITIONAL_OR)
            {
                mv.visitInsn(DUP);
                Label trueLabel = new Label();
                mv.visitJumpInsn(IFNE, trueLabel);
                mv.visitInsn(POP);
                node.getRightOperand().accept(this);
                mv.visitLabel(trueLabel);
            }
            else
            {
                node.getRightOperand().accept(this);
                if (op == InfixExpression.Operator.PLUS)
                {
                    mv.visitInsn(IADD);
                }
                else if (op == InfixExpression.Operator.MINUS)
                {
                    mv.visitInsn(ISUB);
                }
                else if (op == InfixExpression.Operator.TIMES)
                {
                    mv.visitInsn(IMUL);
                }
                else if (op == InfixExpression.Operator.DIVIDE)
                {
                    mv.visitInsn(IDIV);
                }
                else if (op == InfixExpression.Operator.REMAINDER)
                {
                    mv.visitInsn(IREM);
                }
                else if (op == InfixExpression.Operator.GREATER)
                {
                    generateRelationalCode(IF_ICMPGT);
                }
                else if (op == InfixExpression.Operator.GREATER_EQUALS)
                {
                    generateRelationalCode(IF_ICMPGE);
                }
                else if (op == InfixExpression.Operator.EQUALS)
                {
                    generateRelationalCode(IF_ICMPEQ);
                }
                else if (op == InfixExpression.Operator.NOT_EQUALS)
                {
                    generateRelationalCode(IF_ICMPNE);
                }
                else if (op == InfixExpression.Operator.LESS)
                {
                    generateRelationalCode(IF_ICMPLT);
                }
                else if (op == InfixExpression.Operator.LESS_EQUALS)
                {
                    generateRelationalCode(IF_ICMPLE);
                }
            }
            return false;
        }

        @Override public boolean visit(MethodInvocation node)
        {
            for (Object o : node.arguments())
            {
                ((ASTNode) o).accept(this);
            }
            Object o = symbolMap.get(node);
            if (o instanceof MethodDeclaration)
            {
                MethodDeclaration md = (MethodDeclaration) o;
                String className = ((TypeDeclaration) md.getParent())
                    .getName()
                    .getIdentifier();
                String methodName = node.getName().getIdentifier();
                Pair<Type, List<Type>> p = methodTypeMap.get(md);
                mv.visitMethodInsn(
                    INVOKESTATIC,
                    className,
                    methodName,
                    getMethodDescriptor(p.first, p.second));
            }
            else if (o instanceof Method)
            {
                Method m = (Method) o;
                String className = m.getDeclaringClass().getName().replace(
                    '.',
                    '/');
                String methodName = m.getName();
                Pair<Type, List<Type>> p = methodTypeMap.get(m);
                mv.visitMethodInsn(
                    INVOKESTATIC,
                    className,
                    methodName,
                    getMethodDescriptor(p.first, p.second));
            }
            return false;
        }

        @Override public boolean visit(SimpleName node)
        {
            ASTNode parent = node.getParent();
            if (parent instanceof Expression || parent instanceof Statement)
            {
                String varName = node.getIdentifier();
                Object decl = symbolMap.get(node);
                if (decl instanceof FieldDeclaration)
                {
                    FieldDeclaration fd = (FieldDeclaration) decl;
                    String className = ((TypeDeclaration) fd.getParent())
                        .getName()
                        .getIdentifier();
                    mv.visitFieldInsn(
                        GETSTATIC,
                        className,
                        varName,
                        convertType(typeMap.get(fd)));
                }
                else
                {
                    Type t = typeMap.get(node);
                    if (t instanceof IntType || t instanceof BooleanType)
                    {
                        mv.visitVarInsn(ILOAD, localIndexMap
                            .get(varName)
                            .intValue());
                    }
                    else
                    {
                        mv.visitVarInsn(ALOAD, localIndexMap
                            .get(varName)
                            .intValue());
                    }
                }
            }
            return false;
        }

        protected void generateIntConst(int i)
        {
            switch (i)
            {
                case -1:
                    mv.visitInsn(ICONST_M1);
                    break;
                case 0:
                    mv.visitInsn(ICONST_0);
                    break;
                case 1:
                    mv.visitInsn(ICONST_1);
                    break;
                case 2:
                    mv.visitInsn(ICONST_2);
                    break;
                case 3:
                    mv.visitInsn(ICONST_3);
                    break;
                case 4:
                    mv.visitInsn(ICONST_4);
                    break;
                case 5:
                    mv.visitInsn(ICONST_5);
                    break;
                default:
                    if (i >= Byte.MIN_VALUE && i <= Byte.MAX_VALUE)
                    {
                        mv.visitIntInsn(BIPUSH, i);
                    }
                    else if (i >= Short.MIN_VALUE && i <= Short.MAX_VALUE)
                    {
                        mv.visitIntInsn(SIPUSH, i);
                    }
                    else
                    {
                        mv.visitLdcInsn(new Integer(i));
                    }
            }
        }

        protected void generateConstructor(String className)
        {
            mv = cw.visitMethod(ACC_PUBLIC, "<init>", "()V", null, null);
            mv.visitCode();
            Label l0 = new Label();
            mv.visitLabel(l0);
            mv.visitVarInsn(ALOAD, 0);
            mv.visitMethodInsn(
                INVOKESPECIAL,
                "java/lang/Object",
                "<init>",
                "()V");
            mv.visitInsn(RETURN);
            Label l1 = new Label();
            mv.visitLabel(l1);
            mv.visitLocalVariable(
                "this",
                "L" + className + ";",
                null,
                l0,
                l1,
                0);
            mv.visitMaxs(1, 1);
            mv.visitEnd();
        }

        protected void generateRelationalCode(int opcode)
        {
            Label thenLabel = new Label();
            Label endLabel = new Label();
            mv.visitJumpInsn(opcode, thenLabel);
            mv.visitInsn(ICONST_0);
            mv.visitJumpInsn(GOTO, endLabel);
            mv.visitLabel(thenLabel);
            mv.visitInsn(ICONST_1);
            mv.visitLabel(endLabel);
        }

        protected void buildLocalIndexTable(MethodDeclaration md)
        {
            int i = 0;
            for (Object o : md.parameters())
            {
                SingleVariableDeclaration svd = (SingleVariableDeclaration) o;
                String paramName = svd.getName().getIdentifier();
                localNamesTypes.add(new Pair<String, Type>(paramName, typeMap
                    .get(svd)));
                localIndexMap.put(paramName, new Integer(i));
                i++;
            }
            for (Object o : md.getBody().statements())
            {
                if (!(o instanceof VariableDeclarationStatement))
                {
                    break;
                }
                VariableDeclarationStatement vds = (VariableDeclarationStatement) o;
                VariableDeclarationFragment vdf = (VariableDeclarationFragment) vds
                    .fragments()
                    .get(0);
                String localName = vdf.getName().getIdentifier();
                localNamesTypes.add(new Pair<String, Type>(localName, typeMap
                    .get(vds)));
                localIndexMap.put(localName, new Integer(i));
                i++;
            }
        }

        protected int convertModifiers(ASTNode node, List l)
        {
            int result = 0;
            for (Object o : l)
            {
                if (o instanceof Modifier)
                {
                    ModifierKeyword mk = ((Modifier) o).getKeyword();
                    if (mk == ModifierKeyword.PUBLIC_KEYWORD)
                    {
                        result += ACC_PUBLIC;
                    }
                    else if (mk == ModifierKeyword.STATIC_KEYWORD)
                    {
                        result += ACC_STATIC;
                    }
                    else
                    {
                        throw new Error(node, "Unexpected modifier \'" + o
                                              + "\' in \'" + node.getParent()
                                              + "\'");
                    }
                }
            }
            return result;
        }

        protected String convertType(Type t)
        {
            if (t instanceof VoidType)
            {
                return "V";
            }
            else if (t instanceof BooleanType)
            {
                return "Z";
            }
            else if (t instanceof IntType)
            {
                return "I";
            }
            else if (t instanceof ClassType)
            {
                return "L" + ((ClassType) t).name.replace('.', '/') + ";";
            }
            else
            {
                return "[" + convertType(((ArrayType) t).baseType);
            }
        }

        protected String getMethodDescriptor(
            Type returnType,
            List<Type> parameterTypes)
        {
            StringBuilder sb = new StringBuilder();
            sb.append('(');
            for (Type t : parameterTypes)
            {
                sb.append(convertType(t));
            }
            sb.append(')');
            sb.append(convertType(returnType));
            return sb.toString();
        }

        protected void dispose()
        {
            cw = null;
            symbolMap = null;
            typeMap = null;
            methodTypeMap = null;
            localNamesTypes = null;
            localIndexMap = null;
            mainClassName = null;
            mainClassBytes = null;
        }
    }
}
