package sjc.test;

import java.io.FileReader;

import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import sjc.analysis.CFG;
import sjc.analysis.UnreachableStatementAnalysis;
import sjc.parser.ASTParser;
import sjc.symboltable.SymbolTable;
import sjc.symboltable.SymbolTableBuilder;
import junit.framework.Assert;
import junit.framework.TestCase;

public class UnreachableCodeTest extends TestCase {
	    /*public void testPower()
	    {
	        testPass("src-examples/Power.java");
	    }

	    public void testFactorial()
	    {
	        testPass("src-examples/Factorial.java");
	    }*/
	
		public void testSimpleExpr() {
			testPass("src-examples/UnreachableExample.java");
		}

	    public static void testPass(String filename) {
	        try {
	            FileReader fr = new FileReader(filename);
	            CompilationUnit cu = ASTParser.parse(fr);
	            fr.close();
	            SymbolTable st = SymbolTableBuilder.build(cu);
	            for (Object o : cu.types()) {
	                if (o instanceof TypeDeclaration) {
	                    for (Object o2 : ((TypeDeclaration) o).bodyDeclarations()) {
	                        if (o2 instanceof MethodDeclaration) {
	                            MethodDeclaration md = (MethodDeclaration) o2;
	                            UnreachableStatementAnalysis usa = new UnreachableStatementAnalysis();
	                            for (Statement s : usa.unreachableStatements(md, new CFG(md))) {
									System.out.println("unreachable statement : " + s);
	                            }
	                        }
	                    }
	                }
	            }
	            System.out.flush();
	        } catch (Exception e) {
	            e.printStackTrace();
	            Assert.assertTrue(e.getMessage(), false);
	        }
	    }


}
