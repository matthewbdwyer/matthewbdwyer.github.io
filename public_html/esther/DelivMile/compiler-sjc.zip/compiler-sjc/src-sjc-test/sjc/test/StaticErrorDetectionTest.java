package sjc.test;

import java.io.FileReader;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.eclipse.jdt.core.dom.CompilationUnit;

import sjc.analysis.StaticErrorDetection;
import sjc.parser.ASTParser;

public class StaticErrorDetectionTest extends TestCase {
	public void testPower() {
		testPass("src-examples/Power.java");
	}

	public void testFactorial() {
		testPass("src-examples/Factorial.java");
	}

	public void testUnusedAssignExample() {
		testPass("src-examples/UnusedAssignExample.java");
	}

	public void testUninitVarExample() {
		testPass("src-examples/UninitVarExample.java");
	}

	public void testUnreachableExample() {
		testPass("src-examples/UnreachableExample.java");
	}

	public static void testPass(String filename) {
		try {
			FileReader fr = new FileReader(filename);
			CompilationUnit cu = ASTParser.parse(fr);
			fr.close();
			System.out.println("Error reports for " + filename);
			System.out.println();
			StaticErrorDetection.reportErrors(cu);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.assertTrue(e.getMessage(), false);
		}
	}

}
