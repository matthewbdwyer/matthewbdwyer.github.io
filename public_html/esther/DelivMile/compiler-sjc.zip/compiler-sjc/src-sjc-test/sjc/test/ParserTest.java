package sjc.test;

import java.io.FileReader;

import junit.framework.Assert;
import junit.framework.TestCase;

import sjc.parser.SJParser;

/**
 * Test cases for {@link SJParser}.
 * 
 * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
 */
public class ParserTest extends TestCase
{
    public void testPower()
    {
        testPass("src-examples/Power.java");
    }
    
    public void testFactorial()
    {
        testPass("src-examples/Factorial.java");
    }
    
    public static void testPass(String filename)
    {
        try
        {
            FileReader fr = new FileReader(filename);
            SJParser.parse(fr);
            fr.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.assertTrue(e.getMessage(), false);
        }
    }
}
