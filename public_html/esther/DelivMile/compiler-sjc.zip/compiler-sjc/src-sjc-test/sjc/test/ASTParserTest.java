package sjc.test;

import java.io.FileReader;

import junit.framework.Assert;
import junit.framework.TestCase;

import sjc.parser.ASTParser;

/**
 * Test cases for {@link ASTParser}.
 * 
 * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
 */
public class ASTParserTest extends TestCase
{
    public void testPower()
    {
        testPass("src-examples/Power.java");
    }
    
    public void testFactorial()
    {
        testPass("src-examples/Factorial.java");
    }
    
    public static void testPass(String filename)
    {
        try
        {
            FileReader fr = new FileReader(filename);
            System.out.println(ASTParser.parse(fr).toString());
            System.out.flush();
            fr.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.assertTrue(e.getMessage(), false);
        }
    }
}
