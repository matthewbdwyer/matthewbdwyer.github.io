package sjc.test;

import java.io.FileReader;
import java.io.PrintWriter;

import org.eclipse.jdt.core.dom.CompilationUnit;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.util.TraceClassVisitor;

import junit.framework.Assert;
import junit.framework.TestCase;

import sjc.codegen.ByteCodeGenerator;
import sjc.codegen.ClassByteCodes;
import sjc.parser.ASTParser;
import sjc.symboltable.SymbolTable;
import sjc.symboltable.SymbolTableBuilder;
import sjc.type.TypeFactory;
import sjc.type.checker.TypeChecker;
import sjc.type.checker.TypeTable;

/**
 * Test cases for {@link TypeChecker}.
 * 
 * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
 */
public class ByteCodeGeneratorTest
    extends TestCase
{
    public void testPower2To2()
    {
        testPass("src-examples/Power.java", new Object[]
            {
                new String[]
                    {
                        "2", "2"
                    }
            });
    }

    public void testFactorial3()
    {
        testPass("src-examples/Factorial.java", new Object[]
            {
                new String[]
                    {
                        "3"
                    }
            });
    }

    public static void testPass(String filename, Object[] args)
    {
        try
        {
            FileReader fr = new FileReader(filename);
            CompilationUnit cu = ASTParser.parse(fr);
            fr.close();
            SymbolTable st = SymbolTableBuilder.build(cu);
            TypeTable tt = TypeChecker.check(new TypeFactory(), cu, st);
            ClassByteCodes cbc = ByteCodeGenerator.generate(cu, st, tt);
            ClassReader cr = new ClassReader(cbc.mainClassBytes);
            TraceClassVisitor tcv = new TraceClassVisitor(new PrintWriter(
                System.out));
            cr.accept(tcv, false);
            System.out.flush();

            CustomClassLoader ccl = new CustomClassLoader();
            Class c = ccl.loadClass(cbc.mainClassName, cbc.mainClassBytes);
            c.getMethod("main", new Class[]
                {
                    String[].class
                }).invoke(null, args);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.assertTrue(e.getMessage(), false);
            throw new RuntimeException();
        }
    }

    static class CustomClassLoader
        extends ClassLoader
    {
        public Class loadClass(String name, byte[] bytecodes)
        {
            return defineClass(name, bytecodes, 0, bytecodes.length);
        }
    }
}
