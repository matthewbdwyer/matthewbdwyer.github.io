package sjc.test;

import java.io.FileReader;

import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import sjc.analysis.CFG;
import sjc.analysis.LiveVariableAnalysis;
import sjc.parser.ASTParser;
import sjc.symboltable.SymbolTable;
import sjc.symboltable.SymbolTableBuilder;
import junit.framework.Assert;
import junit.framework.TestCase;

public class LiveVariableAnalysisTest extends TestCase {
	    /*public void testPower()
	    {
	        testPass("src-examples/Power.java");
	    }

	    public void testFactorial()
	    {
	        testPass("src-examples/Factorial.java");
	    }*/
	
		public void testSimpleExpr()
		{
			testPass("src-examples/LiveVarExample.java");
		}

	    public static void testPass(String filename)
	    {
	        try
	        {
	            FileReader fr = new FileReader(filename);
	            CompilationUnit cu = ASTParser.parse(fr);
	            fr.close();
	            SymbolTable st = SymbolTableBuilder.build(cu);
	            for (Object o : cu.types())
	            {
	                if (o instanceof TypeDeclaration)
	                {
	                    for (Object o2 : ((TypeDeclaration) o).bodyDeclarations())
	                    {
	                        if (o2 instanceof MethodDeclaration)
	                        {
	                            MethodDeclaration md = (MethodDeclaration) o2;
	                            LiveVariableAnalysis lva = new LiveVariableAnalysis(
	                                st,
	                                new CFG(md));
	                            lva.computeFixPoint();
	                            System.out.println(lva.getResultString());
	                            System.out.println();
	                        }
	                    }
	                }
	            }
	            System.out.flush();
	        }
	        catch (Exception e)
	        {
	            e.printStackTrace();
	            Assert.assertTrue(e.getMessage(), false);
	        }
	    }


}
