package sjc.test;

import java.io.FileReader;

import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import junit.framework.Assert;
import junit.framework.TestCase;

import sjc.analysis.CFG;
import sjc.parser.ASTParser;
import sjc.type.checker.TypeChecker;

/**
 * Test cases for {@link TypeChecker}.
 * 
 * @author <a href="mailto:robby@cis.ksu.edu">Robby</a>
 */
public class CFGTest
    extends TestCase
{
    public void testPower()
    {
        testPass("src-examples/Power.java");
    }

    public void testFactorial()
    {
        testPass("src-examples/Factorial.java");
    }

    public static void testPass(String filename)
    {
        try
        {
            FileReader fr = new FileReader(filename);
            CompilationUnit cu = ASTParser.parse(fr);
            for (Object o: cu.types())
            {
                if (o instanceof TypeDeclaration)
                {
                    for (Object o2: ((TypeDeclaration) o).bodyDeclarations())
                    {
                        if (o2 instanceof MethodDeclaration)
                        {
                            System.out.println(new CFG((MethodDeclaration) o2));
                            System.out.println();
                        }
                    }
                }
            }
            fr.close();
            System.out.println();
            System.out.flush();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.assertTrue(e.getMessage(), false);
        }
    }
}
