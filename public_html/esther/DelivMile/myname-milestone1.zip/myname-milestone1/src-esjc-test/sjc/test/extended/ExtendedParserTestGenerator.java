package sjc.test.extended;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;

public class ExtendedParserTestGenerator {
	public static void main(String[] args) throws Exception
	{
		FileReader fr = new FileReader("src-esjc-test/sjc/test/extended/ExtendedParserTest.template");
		LineNumberReader lnr = new LineNumberReader(fr);
		String s = lnr.readLine();
		while (s != null)
		{
			System.out.println(s);
			s = lnr.readLine();
		}
		
		fr.close();
		File f = new File("src-examples");
		for (String filename : f.list())
		{
			String filenameNoExt = filename.substring(0, filename.length() - ".java".length());
			System.out.println("\tpublic void test" + filenameNoExt + "() { testPass(\"src-examples/" + filename + "\"); }");
			System.out.println();
		}
		System.out.println("}");
		System.out.flush();
	}
}