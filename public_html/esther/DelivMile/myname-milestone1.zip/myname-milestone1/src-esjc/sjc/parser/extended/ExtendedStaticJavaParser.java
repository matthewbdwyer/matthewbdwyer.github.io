// $ANTLR 3.0.1 /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g 2007-09-19 22:31:16

package sjc.parser.extended;

import java.math.BigInteger;

/**
 * Extended StaticJava parser.
 *
 * @author <myname>
 */


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
public class ExtendedStaticJavaParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ID", "NUM_INT", "MAIN", "STRING", "WS", "'public'", "'class'", "'{'", "'}'", "'static'", "'void'", "'('", "'['", "']'", "')'", "';'", "'boolean'", "'int'", "','", "'='", "'if'", "'else'", "'while'", "'return'", "'||'", "'&&'", "'!='", "'=='", "'<'", "'>'", "'<='", "'>='", "'+'", "'-'", "'*'", "'/'", "'%'", "'!'", "'true'", "'false'", "'null'", "'.'"
    };
    public static final int MAIN=6;
    public static final int WS=8;
    public static final int EOF=-1;
    public static final int STRING=7;
    public static final int NUM_INT=5;
    public static final int ID=4;

        public ExtendedStaticJavaParser(TokenStream input) {
            super(input);
            ruleMemo = new HashMap[71+1];
         }
        

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "/Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g"; }


    protected void mismatch(IntStream input, int ttype, BitSet follow) 
    	throws RecognitionException
    {
    	throw new MismatchedTokenException(ttype, input);
    }

    public void recoverFromMismatchedSet(IntStream input, RecognitionException e, BitSet follow)
    	throws RecognitionException
    {
    	throw e;
    }



    // $ANTLR start compilationUnit
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:51:1: compilationUnit : classDefinition EOF ;
    public final void compilationUnit() throws RecognitionException {
        int compilationUnit_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 1) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:60:2: ( classDefinition EOF )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:60:4: classDefinition EOF
            {
            pushFollow(FOLLOW_classDefinition_in_compilationUnit59);
            classDefinition();
            _fsp--;
            if (failed) return ;
            match(input,EOF,FOLLOW_EOF_in_compilationUnit63); if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 1, compilationUnit_StartIndex); }
        }
        return ;
    }
    // $ANTLR end compilationUnit


    // $ANTLR start classDefinition
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:64:1: classDefinition : 'public' 'class' ID '{' mainMethodDeclaration ( fieldDeclaration | methodDeclaration )* '}' ;
    public final void classDefinition() throws RecognitionException {
        int classDefinition_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 2) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:65:2: ( 'public' 'class' ID '{' mainMethodDeclaration ( fieldDeclaration | methodDeclaration )* '}' )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:65:4: 'public' 'class' ID '{' mainMethodDeclaration ( fieldDeclaration | methodDeclaration )* '}'
            {
            match(input,9,FOLLOW_9_in_classDefinition74); if (failed) return ;
            match(input,10,FOLLOW_10_in_classDefinition76); if (failed) return ;
            match(input,ID,FOLLOW_ID_in_classDefinition78); if (failed) return ;
            match(input,11,FOLLOW_11_in_classDefinition80); if (failed) return ;
            pushFollow(FOLLOW_mainMethodDeclaration_in_classDefinition85);
            mainMethodDeclaration();
            _fsp--;
            if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:67:3: ( fieldDeclaration | methodDeclaration )*
            loop1:
            do {
                int alt1=3;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==13) ) {
                    int LA1_2 = input.LA(2);

                    if ( (LA1_2==14) ) {
                        alt1=2;
                    }
                    else if ( ((LA1_2>=20 && LA1_2<=21)) ) {
                        int LA1_4 = input.LA(3);

                        if ( (LA1_4==ID) ) {
                            int LA1_5 = input.LA(4);

                            if ( (LA1_5==15) ) {
                                alt1=2;
                            }
                            else if ( (LA1_5==19) ) {
                                alt1=1;
                            }


                        }


                    }


                }


                switch (alt1) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:67:5: fieldDeclaration
            	    {
            	    pushFollow(FOLLOW_fieldDeclaration_in_classDefinition91);
            	    fieldDeclaration();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;
            	case 2 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:68:5: methodDeclaration
            	    {
            	    pushFollow(FOLLOW_methodDeclaration_in_classDefinition97);
            	    methodDeclaration();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            match(input,12,FOLLOW_12_in_classDefinition104); if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 2, classDefinition_StartIndex); }
        }
        return ;
    }
    // $ANTLR end classDefinition


    // $ANTLR start mainMethodDeclaration
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:72:1: mainMethodDeclaration : 'public' 'static' 'void' id1= ID {...}? '(' id2= ID '[' ']' {...}? ID ')' '{' methodBody '}' ;
    public final void mainMethodDeclaration() throws RecognitionException {
        int mainMethodDeclaration_StartIndex = input.index();
        Token id1=null;
        Token id2=null;

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 3) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:73:2: ( 'public' 'static' 'void' id1= ID {...}? '(' id2= ID '[' ']' {...}? ID ')' '{' methodBody '}' )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:73:4: 'public' 'static' 'void' id1= ID {...}? '(' id2= ID '[' ']' {...}? ID ')' '{' methodBody '}'
            {
            match(input,9,FOLLOW_9_in_mainMethodDeclaration115); if (failed) return ;
            match(input,13,FOLLOW_13_in_mainMethodDeclaration117); if (failed) return ;
            match(input,14,FOLLOW_14_in_mainMethodDeclaration119); if (failed) return ;
            id1=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_mainMethodDeclaration128); if (failed) return ;
            if ( !( "main".equals(id1.getText()) ) ) {
                if (backtracking>0) {failed=true; return ;}
                throw new FailedPredicateException(input, "mainMethodDeclaration", " \"main\".equals(id1.getText()) ");
            }
            match(input,15,FOLLOW_15_in_mainMethodDeclaration143); if (failed) return ;
            id2=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_mainMethodDeclaration147); if (failed) return ;
            match(input,16,FOLLOW_16_in_mainMethodDeclaration149); if (failed) return ;
            match(input,17,FOLLOW_17_in_mainMethodDeclaration151); if (failed) return ;
            if ( !( "String".equals(id2.getText()) ) ) {
                if (backtracking>0) {failed=true; return ;}
                throw new FailedPredicateException(input, "mainMethodDeclaration", " \"String\".equals(id2.getText()) ");
            }
            match(input,ID,FOLLOW_ID_in_mainMethodDeclaration166); if (failed) return ;
            match(input,18,FOLLOW_18_in_mainMethodDeclaration173); if (failed) return ;
            match(input,11,FOLLOW_11_in_mainMethodDeclaration175); if (failed) return ;
            pushFollow(FOLLOW_methodBody_in_mainMethodDeclaration177);
            methodBody();
            _fsp--;
            if (failed) return ;
            match(input,12,FOLLOW_12_in_mainMethodDeclaration179); if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 3, mainMethodDeclaration_StartIndex); }
        }
        return ;
    }
    // $ANTLR end mainMethodDeclaration


    // $ANTLR start fieldDeclaration
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:82:1: fieldDeclaration : 'static' type ID ';' ;
    public final void fieldDeclaration() throws RecognitionException {
        int fieldDeclaration_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 4) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:83:2: ( 'static' type ID ';' )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:83:4: 'static' type ID ';'
            {
            match(input,13,FOLLOW_13_in_fieldDeclaration191); if (failed) return ;
            pushFollow(FOLLOW_type_in_fieldDeclaration193);
            type();
            _fsp--;
            if (failed) return ;
            match(input,ID,FOLLOW_ID_in_fieldDeclaration195); if (failed) return ;
            match(input,19,FOLLOW_19_in_fieldDeclaration197); if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 4, fieldDeclaration_StartIndex); }
        }
        return ;
    }
    // $ANTLR end fieldDeclaration


    // $ANTLR start methodDeclaration
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:86:1: methodDeclaration : 'static' returnType ID '(' ( params )? ')' '{' methodBody '}' ;
    public final void methodDeclaration() throws RecognitionException {
        int methodDeclaration_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 5) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:87:2: ( 'static' returnType ID '(' ( params )? ')' '{' methodBody '}' )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:87:4: 'static' returnType ID '(' ( params )? ')' '{' methodBody '}'
            {
            match(input,13,FOLLOW_13_in_methodDeclaration209); if (failed) return ;
            pushFollow(FOLLOW_returnType_in_methodDeclaration211);
            returnType();
            _fsp--;
            if (failed) return ;
            match(input,ID,FOLLOW_ID_in_methodDeclaration213); if (failed) return ;
            match(input,15,FOLLOW_15_in_methodDeclaration217); if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:88:7: ( params )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( ((LA2_0>=20 && LA2_0<=21)) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:88:9: params
                    {
                    pushFollow(FOLLOW_params_in_methodDeclaration221);
                    params();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;

            }

            match(input,18,FOLLOW_18_in_methodDeclaration226); if (failed) return ;
            match(input,11,FOLLOW_11_in_methodDeclaration230); if (failed) return ;
            pushFollow(FOLLOW_methodBody_in_methodDeclaration232);
            methodBody();
            _fsp--;
            if (failed) return ;
            match(input,12,FOLLOW_12_in_methodDeclaration234); if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 5, methodDeclaration_StartIndex); }
        }
        return ;
    }
    // $ANTLR end methodDeclaration


    // $ANTLR start type
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:92:1: type : ( 'boolean' | 'int' );
    public final void type() throws RecognitionException {
        int type_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 6) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:93:2: ( 'boolean' | 'int' )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:
            {
            if ( (input.LA(1)>=20 && input.LA(1)<=21) ) {
                input.consume();
                errorRecovery=false;failed=false;
            }
            else {
                if (backtracking>0) {failed=true; return ;}
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recoverFromMismatchedSet(input,mse,FOLLOW_set_in_type0);    throw mse;
            }


            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 6, type_StartIndex); }
        }
        return ;
    }
    // $ANTLR end type


    // $ANTLR start returnType
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:95:1: returnType : ( 'void' | type );
    public final void returnType() throws RecognitionException {
        int returnType_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 7) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:96:2: ( 'void' | type )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==14) ) {
                alt3=1;
            }
            else if ( ((LA3_0>=20 && LA3_0<=21)) ) {
                alt3=2;
            }
            else {
                if (backtracking>0) {failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("95:1: returnType : ( 'void' | type );", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:96:4: 'void'
                    {
                    match(input,14,FOLLOW_14_in_returnType260); if (failed) return ;

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:96:13: type
                    {
                    pushFollow(FOLLOW_type_in_returnType264);
                    type();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;

            }
        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 7, returnType_StartIndex); }
        }
        return ;
    }
    // $ANTLR end returnType


    // $ANTLR start params
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:99:1: params : param ( ',' param )* ;
    public final void params() throws RecognitionException {
        int params_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 8) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:100:2: ( param ( ',' param )* )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:100:4: param ( ',' param )*
            {
            pushFollow(FOLLOW_param_in_params276);
            param();
            _fsp--;
            if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:100:10: ( ',' param )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==22) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:100:12: ',' param
            	    {
            	    match(input,22,FOLLOW_22_in_params280); if (failed) return ;
            	    pushFollow(FOLLOW_param_in_params282);
            	    param();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 8, params_StartIndex); }
        }
        return ;
    }
    // $ANTLR end params


    // $ANTLR start param
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:103:1: param : type ID ;
    public final void param() throws RecognitionException {
        int param_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 9) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:104:2: ( type ID )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:104:4: type ID
            {
            pushFollow(FOLLOW_type_in_param297);
            type();
            _fsp--;
            if (failed) return ;
            match(input,ID,FOLLOW_ID_in_param299); if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 9, param_StartIndex); }
        }
        return ;
    }
    // $ANTLR end param


    // $ANTLR start methodBody
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:107:1: methodBody : ( localDeclaration )* ( statement )* ;
    public final void methodBody() throws RecognitionException {
        int methodBody_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 10) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:108:2: ( ( localDeclaration )* ( statement )* )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:108:4: ( localDeclaration )* ( statement )*
            {
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:108:4: ( localDeclaration )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( ((LA5_0>=20 && LA5_0<=21)) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:0:0: localDeclaration
            	    {
            	    pushFollow(FOLLOW_localDeclaration_in_methodBody310);
            	    localDeclaration();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:109:3: ( statement )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==ID||LA6_0==24||(LA6_0>=26 && LA6_0<=27)) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:0:0: statement
            	    {
            	    pushFollow(FOLLOW_statement_in_methodBody316);
            	    statement();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);


            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 10, methodBody_StartIndex); }
        }
        return ;
    }
    // $ANTLR end methodBody


    // $ANTLR start localDeclaration
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:112:1: localDeclaration : type ID ';' ;
    public final void localDeclaration() throws RecognitionException {
        int localDeclaration_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 11) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:113:2: ( type ID ';' )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:113:4: type ID ';'
            {
            pushFollow(FOLLOW_type_in_localDeclaration328);
            type();
            _fsp--;
            if (failed) return ;
            match(input,ID,FOLLOW_ID_in_localDeclaration330); if (failed) return ;
            match(input,19,FOLLOW_19_in_localDeclaration332); if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 11, localDeclaration_StartIndex); }
        }
        return ;
    }
    // $ANTLR end localDeclaration


    // $ANTLR start statement
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:116:1: statement : ( assignStatement | ifStatement | whileStatement | invokeExpStatement | returnStatement ) ;
    public final void statement() throws RecognitionException {
        int statement_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 12) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:117:2: ( ( assignStatement | ifStatement | whileStatement | invokeExpStatement | returnStatement ) )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:117:4: ( assignStatement | ifStatement | whileStatement | invokeExpStatement | returnStatement )
            {
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:117:4: ( assignStatement | ifStatement | whileStatement | invokeExpStatement | returnStatement )
            int alt7=5;
            switch ( input.LA(1) ) {
            case ID:
                {
                int LA7_1 = input.LA(2);

                if ( (LA7_1==15||LA7_1==45) ) {
                    alt7=4;
                }
                else if ( (LA7_1==23) ) {
                    alt7=1;
                }
                else {
                    if (backtracking>0) {failed=true; return ;}
                    NoViableAltException nvae =
                        new NoViableAltException("117:4: ( assignStatement | ifStatement | whileStatement | invokeExpStatement | returnStatement )", 7, 1, input);

                    throw nvae;
                }
                }
                break;
            case 24:
                {
                alt7=2;
                }
                break;
            case 26:
                {
                alt7=3;
                }
                break;
            case 27:
                {
                alt7=5;
                }
                break;
            default:
                if (backtracking>0) {failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("117:4: ( assignStatement | ifStatement | whileStatement | invokeExpStatement | returnStatement )", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:117:6: assignStatement
                    {
                    pushFollow(FOLLOW_assignStatement_in_statement346);
                    assignStatement();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:118:5: ifStatement
                    {
                    pushFollow(FOLLOW_ifStatement_in_statement352);
                    ifStatement();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;
                case 3 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:119:5: whileStatement
                    {
                    pushFollow(FOLLOW_whileStatement_in_statement358);
                    whileStatement();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;
                case 4 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:120:5: invokeExpStatement
                    {
                    pushFollow(FOLLOW_invokeExpStatement_in_statement364);
                    invokeExpStatement();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;
                case 5 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:121:5: returnStatement
                    {
                    pushFollow(FOLLOW_returnStatement_in_statement370);
                    returnStatement();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;

            }


            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 12, statement_StartIndex); }
        }
        return ;
    }
    // $ANTLR end statement


    // $ANTLR start assignStatement
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:125:1: assignStatement : ID '=' exp ';' ;
    public final void assignStatement() throws RecognitionException {
        int assignStatement_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 13) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:126:2: ( ID '=' exp ';' )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:126:4: ID '=' exp ';'
            {
            match(input,ID,FOLLOW_ID_in_assignStatement386); if (failed) return ;
            match(input,23,FOLLOW_23_in_assignStatement388); if (failed) return ;
            pushFollow(FOLLOW_exp_in_assignStatement390);
            exp();
            _fsp--;
            if (failed) return ;
            match(input,19,FOLLOW_19_in_assignStatement392); if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 13, assignStatement_StartIndex); }
        }
        return ;
    }
    // $ANTLR end assignStatement


    // $ANTLR start ifStatement
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:129:1: ifStatement : 'if' '(' exp ')' '{' ( statement )* '}' ( 'else' '{' ( statement )* '}' )? ;
    public final void ifStatement() throws RecognitionException {
        int ifStatement_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 14) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:130:2: ( 'if' '(' exp ')' '{' ( statement )* '}' ( 'else' '{' ( statement )* '}' )? )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:130:4: 'if' '(' exp ')' '{' ( statement )* '}' ( 'else' '{' ( statement )* '}' )?
            {
            match(input,24,FOLLOW_24_in_ifStatement404); if (failed) return ;
            match(input,15,FOLLOW_15_in_ifStatement406); if (failed) return ;
            pushFollow(FOLLOW_exp_in_ifStatement408);
            exp();
            _fsp--;
            if (failed) return ;
            match(input,18,FOLLOW_18_in_ifStatement410); if (failed) return ;
            match(input,11,FOLLOW_11_in_ifStatement414); if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:131:7: ( statement )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==ID||LA8_0==24||(LA8_0>=26 && LA8_0<=27)) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:131:9: statement
            	    {
            	    pushFollow(FOLLOW_statement_in_ifStatement418);
            	    statement();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            match(input,12,FOLLOW_12_in_ifStatement423); if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:132:3: ( 'else' '{' ( statement )* '}' )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==25) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:132:5: 'else' '{' ( statement )* '}'
                    {
                    match(input,25,FOLLOW_25_in_ifStatement429); if (failed) return ;
                    match(input,11,FOLLOW_11_in_ifStatement431); if (failed) return ;
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:132:16: ( statement )*
                    loop9:
                    do {
                        int alt9=2;
                        int LA9_0 = input.LA(1);

                        if ( (LA9_0==ID||LA9_0==24||(LA9_0>=26 && LA9_0<=27)) ) {
                            alt9=1;
                        }


                        switch (alt9) {
                    	case 1 :
                    	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:132:18: statement
                    	    {
                    	    pushFollow(FOLLOW_statement_in_ifStatement435);
                    	    statement();
                    	    _fsp--;
                    	    if (failed) return ;

                    	    }
                    	    break;

                    	default :
                    	    break loop9;
                        }
                    } while (true);

                    match(input,12,FOLLOW_12_in_ifStatement442); if (failed) return ;

                    }
                    break;

            }


            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 14, ifStatement_StartIndex); }
        }
        return ;
    }
    // $ANTLR end ifStatement


    // $ANTLR start whileStatement
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:136:1: whileStatement : 'while' '(' exp ')' '{' ( statement )* '}' ;
    public final void whileStatement() throws RecognitionException {
        int whileStatement_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 15) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:137:2: ( 'while' '(' exp ')' '{' ( statement )* '}' )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:137:4: 'while' '(' exp ')' '{' ( statement )* '}'
            {
            match(input,26,FOLLOW_26_in_whileStatement457); if (failed) return ;
            match(input,15,FOLLOW_15_in_whileStatement459); if (failed) return ;
            pushFollow(FOLLOW_exp_in_whileStatement461);
            exp();
            _fsp--;
            if (failed) return ;
            match(input,18,FOLLOW_18_in_whileStatement463); if (failed) return ;
            match(input,11,FOLLOW_11_in_whileStatement467); if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:138:7: ( statement )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==ID||LA11_0==24||(LA11_0>=26 && LA11_0<=27)) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:138:9: statement
            	    {
            	    pushFollow(FOLLOW_statement_in_whileStatement471);
            	    statement();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            match(input,12,FOLLOW_12_in_whileStatement476); if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 15, whileStatement_StartIndex); }
        }
        return ;
    }
    // $ANTLR end whileStatement


    // $ANTLR start invokeExpStatement
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:141:1: invokeExpStatement : invokeExp ';' ;
    public final void invokeExpStatement() throws RecognitionException {
        int invokeExpStatement_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 16) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:142:2: ( invokeExp ';' )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:142:4: invokeExp ';'
            {
            pushFollow(FOLLOW_invokeExp_in_invokeExpStatement488);
            invokeExp();
            _fsp--;
            if (failed) return ;
            match(input,19,FOLLOW_19_in_invokeExpStatement490); if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 16, invokeExpStatement_StartIndex); }
        }
        return ;
    }
    // $ANTLR end invokeExpStatement


    // $ANTLR start returnStatement
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:145:1: returnStatement : 'return' ( exp )? ';' ;
    public final void returnStatement() throws RecognitionException {
        int returnStatement_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 17) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:146:2: ( 'return' ( exp )? ';' )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:146:4: 'return' ( exp )? ';'
            {
            match(input,27,FOLLOW_27_in_returnStatement502); if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:146:13: ( exp )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( ((LA12_0>=ID && LA12_0<=NUM_INT)||LA12_0==15||(LA12_0>=36 && LA12_0<=37)||(LA12_0>=41 && LA12_0<=44)) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:146:15: exp
                    {
                    pushFollow(FOLLOW_exp_in_returnStatement506);
                    exp();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;

            }

            match(input,19,FOLLOW_19_in_returnStatement511); if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 17, returnStatement_StartIndex); }
        }
        return ;
    }
    // $ANTLR end returnStatement


    // $ANTLR start exp
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:149:1: exp : logicalOrExp ;
    public final void exp() throws RecognitionException {
        int exp_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 18) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:150:2: ( logicalOrExp )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:150:4: logicalOrExp
            {
            pushFollow(FOLLOW_logicalOrExp_in_exp523);
            logicalOrExp();
            _fsp--;
            if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 18, exp_StartIndex); }
        }
        return ;
    }
    // $ANTLR end exp


    // $ANTLR start logicalOrExp
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:153:1: logicalOrExp : logicalAndExp ( '||' logicalAndExp )* ;
    public final void logicalOrExp() throws RecognitionException {
        int logicalOrExp_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 19) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:154:2: ( logicalAndExp ( '||' logicalAndExp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:154:4: logicalAndExp ( '||' logicalAndExp )*
            {
            pushFollow(FOLLOW_logicalAndExp_in_logicalOrExp535);
            logicalAndExp();
            _fsp--;
            if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:154:18: ( '||' logicalAndExp )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==28) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:154:20: '||' logicalAndExp
            	    {
            	    match(input,28,FOLLOW_28_in_logicalOrExp539); if (failed) return ;
            	    pushFollow(FOLLOW_logicalAndExp_in_logicalOrExp541);
            	    logicalAndExp();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);


            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 19, logicalOrExp_StartIndex); }
        }
        return ;
    }
    // $ANTLR end logicalOrExp


    // $ANTLR start logicalAndExp
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:157:1: logicalAndExp : equalityExp ( '&&' equalityExp )* ;
    public final void logicalAndExp() throws RecognitionException {
        int logicalAndExp_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 20) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:158:2: ( equalityExp ( '&&' equalityExp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:158:4: equalityExp ( '&&' equalityExp )*
            {
            pushFollow(FOLLOW_equalityExp_in_logicalAndExp556);
            equalityExp();
            _fsp--;
            if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:158:16: ( '&&' equalityExp )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==29) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:158:18: '&&' equalityExp
            	    {
            	    match(input,29,FOLLOW_29_in_logicalAndExp560); if (failed) return ;
            	    pushFollow(FOLLOW_equalityExp_in_logicalAndExp562);
            	    equalityExp();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);


            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 20, logicalAndExp_StartIndex); }
        }
        return ;
    }
    // $ANTLR end logicalAndExp


    // $ANTLR start equalityExp
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:161:1: equalityExp : relationalExp ( ( '!=' | '==' ) relationalExp )* ;
    public final void equalityExp() throws RecognitionException {
        int equalityExp_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 21) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:162:2: ( relationalExp ( ( '!=' | '==' ) relationalExp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:162:4: relationalExp ( ( '!=' | '==' ) relationalExp )*
            {
            pushFollow(FOLLOW_relationalExp_in_equalityExp577);
            relationalExp();
            _fsp--;
            if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:162:18: ( ( '!=' | '==' ) relationalExp )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( ((LA15_0>=30 && LA15_0<=31)) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:162:20: ( '!=' | '==' ) relationalExp
            	    {
            	    if ( (input.LA(1)>=30 && input.LA(1)<=31) ) {
            	        input.consume();
            	        errorRecovery=false;failed=false;
            	    }
            	    else {
            	        if (backtracking>0) {failed=true; return ;}
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_equalityExp581);    throw mse;
            	    }

            	    pushFollow(FOLLOW_relationalExp_in_equalityExp589);
            	    relationalExp();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);


            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 21, equalityExp_StartIndex); }
        }
        return ;
    }
    // $ANTLR end equalityExp


    // $ANTLR start relationalExp
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:165:1: relationalExp : additiveExp ( ( '<' | '>' | '<=' | '>=' ) additiveExp )* ;
    public final void relationalExp() throws RecognitionException {
        int relationalExp_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 22) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:166:2: ( additiveExp ( ( '<' | '>' | '<=' | '>=' ) additiveExp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:166:4: additiveExp ( ( '<' | '>' | '<=' | '>=' ) additiveExp )*
            {
            pushFollow(FOLLOW_additiveExp_in_relationalExp604);
            additiveExp();
            _fsp--;
            if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:166:16: ( ( '<' | '>' | '<=' | '>=' ) additiveExp )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( ((LA16_0>=32 && LA16_0<=35)) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:166:18: ( '<' | '>' | '<=' | '>=' ) additiveExp
            	    {
            	    if ( (input.LA(1)>=32 && input.LA(1)<=35) ) {
            	        input.consume();
            	        errorRecovery=false;failed=false;
            	    }
            	    else {
            	        if (backtracking>0) {failed=true; return ;}
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_relationalExp608);    throw mse;
            	    }

            	    pushFollow(FOLLOW_additiveExp_in_relationalExp626);
            	    additiveExp();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);


            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 22, relationalExp_StartIndex); }
        }
        return ;
    }
    // $ANTLR end relationalExp


    // $ANTLR start additiveExp
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:169:1: additiveExp : multiplicativeExp ( ( '+' | '-' ) multiplicativeExp )* ;
    public final void additiveExp() throws RecognitionException {
        int additiveExp_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 23) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:170:2: ( multiplicativeExp ( ( '+' | '-' ) multiplicativeExp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:170:4: multiplicativeExp ( ( '+' | '-' ) multiplicativeExp )*
            {
            pushFollow(FOLLOW_multiplicativeExp_in_additiveExp641);
            multiplicativeExp();
            _fsp--;
            if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:170:22: ( ( '+' | '-' ) multiplicativeExp )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( ((LA17_0>=36 && LA17_0<=37)) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:170:24: ( '+' | '-' ) multiplicativeExp
            	    {
            	    if ( (input.LA(1)>=36 && input.LA(1)<=37) ) {
            	        input.consume();
            	        errorRecovery=false;failed=false;
            	    }
            	    else {
            	        if (backtracking>0) {failed=true; return ;}
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_additiveExp645);    throw mse;
            	    }

            	    pushFollow(FOLLOW_multiplicativeExp_in_additiveExp655);
            	    multiplicativeExp();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);


            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 23, additiveExp_StartIndex); }
        }
        return ;
    }
    // $ANTLR end additiveExp


    // $ANTLR start multiplicativeExp
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:173:1: multiplicativeExp : unaryExp ( ( '*' | '/' | '%' ) unaryExp )* ;
    public final void multiplicativeExp() throws RecognitionException {
        int multiplicativeExp_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 24) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:174:2: ( unaryExp ( ( '*' | '/' | '%' ) unaryExp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:174:4: unaryExp ( ( '*' | '/' | '%' ) unaryExp )*
            {
            pushFollow(FOLLOW_unaryExp_in_multiplicativeExp670);
            unaryExp();
            _fsp--;
            if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:174:13: ( ( '*' | '/' | '%' ) unaryExp )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( ((LA18_0>=38 && LA18_0<=40)) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:174:15: ( '*' | '/' | '%' ) unaryExp
            	    {
            	    if ( (input.LA(1)>=38 && input.LA(1)<=40) ) {
            	        input.consume();
            	        errorRecovery=false;failed=false;
            	    }
            	    else {
            	        if (backtracking>0) {failed=true; return ;}
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_multiplicativeExp674);    throw mse;
            	    }

            	    pushFollow(FOLLOW_unaryExp_in_multiplicativeExp688);
            	    unaryExp();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);


            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 24, multiplicativeExp_StartIndex); }
        }
        return ;
    }
    // $ANTLR end multiplicativeExp


    // $ANTLR start unaryExp
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:177:1: unaryExp : ( '-' unaryExp | '+' unaryExp | unaryExpNotPlusMinus );
    public final void unaryExp() throws RecognitionException {
        int unaryExp_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 25) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:178:2: ( '-' unaryExp | '+' unaryExp | unaryExpNotPlusMinus )
            int alt19=3;
            switch ( input.LA(1) ) {
            case 37:
                {
                alt19=1;
                }
                break;
            case 36:
                {
                alt19=2;
                }
                break;
            case ID:
            case NUM_INT:
            case 15:
            case 41:
            case 42:
            case 43:
            case 44:
                {
                alt19=3;
                }
                break;
            default:
                if (backtracking>0) {failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("177:1: unaryExp : ( '-' unaryExp | '+' unaryExp | unaryExpNotPlusMinus );", 19, 0, input);

                throw nvae;
            }

            switch (alt19) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:178:4: '-' unaryExp
                    {
                    match(input,37,FOLLOW_37_in_unaryExp703); if (failed) return ;
                    pushFollow(FOLLOW_unaryExp_in_unaryExp705);
                    unaryExp();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:179:4: '+' unaryExp
                    {
                    match(input,36,FOLLOW_36_in_unaryExp710); if (failed) return ;
                    pushFollow(FOLLOW_unaryExp_in_unaryExp712);
                    unaryExp();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;
                case 3 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:180:4: unaryExpNotPlusMinus
                    {
                    pushFollow(FOLLOW_unaryExpNotPlusMinus_in_unaryExp717);
                    unaryExpNotPlusMinus();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;

            }
        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 25, unaryExp_StartIndex); }
        }
        return ;
    }
    // $ANTLR end unaryExp


    // $ANTLR start unaryExpNotPlusMinus
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:183:1: unaryExpNotPlusMinus : ( '!' unaryExp | primaryExp );
    public final void unaryExpNotPlusMinus() throws RecognitionException {
        int unaryExpNotPlusMinus_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 26) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:184:2: ( '!' unaryExp | primaryExp )
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==41) ) {
                alt20=1;
            }
            else if ( ((LA20_0>=ID && LA20_0<=NUM_INT)||LA20_0==15||(LA20_0>=42 && LA20_0<=44)) ) {
                alt20=2;
            }
            else {
                if (backtracking>0) {failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("183:1: unaryExpNotPlusMinus : ( '!' unaryExp | primaryExp );", 20, 0, input);

                throw nvae;
            }
            switch (alt20) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:184:4: '!' unaryExp
                    {
                    match(input,41,FOLLOW_41_in_unaryExpNotPlusMinus729); if (failed) return ;
                    pushFollow(FOLLOW_unaryExp_in_unaryExpNotPlusMinus731);
                    unaryExp();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:185:4: primaryExp
                    {
                    pushFollow(FOLLOW_primaryExp_in_unaryExpNotPlusMinus736);
                    primaryExp();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;

            }
        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 26, unaryExpNotPlusMinus_StartIndex); }
        }
        return ;
    }
    // $ANTLR end unaryExpNotPlusMinus


    // $ANTLR start primaryExp
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:188:1: primaryExp : (n= NUM_INT {...}? | 'true' | 'false' | 'null' | '(' exp ')' | invokeExp | ID );
    public final void primaryExp() throws RecognitionException {
        int primaryExp_StartIndex = input.index();
        Token n=null;

        try {
            if ( backtracking>0 && alreadyParsedRule(input, 27) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:189:2: (n= NUM_INT {...}? | 'true' | 'false' | 'null' | '(' exp ')' | invokeExp | ID )
            int alt21=7;
            switch ( input.LA(1) ) {
            case NUM_INT:
                {
                alt21=1;
                }
                break;
            case 42:
                {
                alt21=2;
                }
                break;
            case 43:
                {
                alt21=3;
                }
                break;
            case 44:
                {
                alt21=4;
                }
                break;
            case 15:
                {
                alt21=5;
                }
                break;
            case ID:
                {
                int LA21_6 = input.LA(2);

                if ( (LA21_6==15||LA21_6==45) ) {
                    alt21=6;
                }
                else if ( (LA21_6==EOF||(LA21_6>=18 && LA21_6<=19)||LA21_6==22||(LA21_6>=28 && LA21_6<=40)) ) {
                    alt21=7;
                }
                else {
                    if (backtracking>0) {failed=true; return ;}
                    NoViableAltException nvae =
                        new NoViableAltException("188:1: primaryExp : (n= NUM_INT {...}? | 'true' | 'false' | 'null' | '(' exp ')' | invokeExp | ID );", 21, 6, input);

                    throw nvae;
                }
                }
                break;
            default:
                if (backtracking>0) {failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("188:1: primaryExp : (n= NUM_INT {...}? | 'true' | 'false' | 'null' | '(' exp ')' | invokeExp | ID );", 21, 0, input);

                throw nvae;
            }

            switch (alt21) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:189:4: n= NUM_INT {...}?
                    {
                    n=(Token)input.LT(1);
                    match(input,NUM_INT,FOLLOW_NUM_INT_in_primaryExp750); if (failed) return ;
                    if ( !( new BigInteger(n.getText()).bitLength() < 32 ) ) {
                        if (backtracking>0) {failed=true; return ;}
                        throw new FailedPredicateException(input, "primaryExp", " new BigInteger(n.getText()).bitLength() < 32 ");
                    }

                    }
                    break;
                case 2 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:191:4: 'true'
                    {
                    match(input,42,FOLLOW_42_in_primaryExp759); if (failed) return ;

                    }
                    break;
                case 3 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:192:4: 'false'
                    {
                    match(input,43,FOLLOW_43_in_primaryExp764); if (failed) return ;

                    }
                    break;
                case 4 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:193:4: 'null'
                    {
                    match(input,44,FOLLOW_44_in_primaryExp769); if (failed) return ;

                    }
                    break;
                case 5 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:194:4: '(' exp ')'
                    {
                    match(input,15,FOLLOW_15_in_primaryExp774); if (failed) return ;
                    pushFollow(FOLLOW_exp_in_primaryExp776);
                    exp();
                    _fsp--;
                    if (failed) return ;
                    match(input,18,FOLLOW_18_in_primaryExp778); if (failed) return ;

                    }
                    break;
                case 6 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:195:4: invokeExp
                    {
                    pushFollow(FOLLOW_invokeExp_in_primaryExp783);
                    invokeExp();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;
                case 7 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:196:4: ID
                    {
                    match(input,ID,FOLLOW_ID_in_primaryExp788); if (failed) return ;

                    }
                    break;

            }
        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 27, primaryExp_StartIndex); }
        }
        return ;
    }
    // $ANTLR end primaryExp


    // $ANTLR start invokeExp
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:199:1: invokeExp : ( ID '.' )? ID '(' ( args )? ')' ;
    public final void invokeExp() throws RecognitionException {
        int invokeExp_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 28) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:200:2: ( ( ID '.' )? ID '(' ( args )? ')' )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:200:4: ( ID '.' )? ID '(' ( args )? ')'
            {
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:200:4: ( ID '.' )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==ID) ) {
                int LA22_1 = input.LA(2);

                if ( (LA22_1==45) ) {
                    alt22=1;
                }
            }
            switch (alt22) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:200:6: ID '.'
                    {
                    match(input,ID,FOLLOW_ID_in_invokeExp802); if (failed) return ;
                    match(input,45,FOLLOW_45_in_invokeExp804); if (failed) return ;

                    }
                    break;

            }

            match(input,ID,FOLLOW_ID_in_invokeExp811); if (failed) return ;
            match(input,15,FOLLOW_15_in_invokeExp813); if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:201:10: ( args )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( ((LA23_0>=ID && LA23_0<=NUM_INT)||LA23_0==15||(LA23_0>=36 && LA23_0<=37)||(LA23_0>=41 && LA23_0<=44)) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:201:12: args
                    {
                    pushFollow(FOLLOW_args_in_invokeExp817);
                    args();
                    _fsp--;
                    if (failed) return ;

                    }
                    break;

            }

            match(input,18,FOLLOW_18_in_invokeExp822); if (failed) return ;

            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 28, invokeExp_StartIndex); }
        }
        return ;
    }
    // $ANTLR end invokeExp


    // $ANTLR start args
    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:204:1: args : exp ( ',' exp )* ;
    public final void args() throws RecognitionException {
        int args_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 29) ) { return ; }
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:205:2: ( exp ( ',' exp )* )
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:205:4: exp ( ',' exp )*
            {
            pushFollow(FOLLOW_exp_in_args834);
            exp();
            _fsp--;
            if (failed) return ;
            // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:205:8: ( ',' exp )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( (LA24_0==22) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // /Users/dwyer/compilers-workspace/myname-milestone1/src/sjc/parser/extended/ExtendedStaticJava.g:205:10: ',' exp
            	    {
            	    match(input,22,FOLLOW_22_in_args838); if (failed) return ;
            	    pushFollow(FOLLOW_exp_in_args840);
            	    exp();
            	    _fsp--;
            	    if (failed) return ;

            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);


            }

        }

        catch (RecognitionException e) {
        	throw e;
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 29, args_StartIndex); }
        }
        return ;
    }
    // $ANTLR end args


 

    public static final BitSet FOLLOW_classDefinition_in_compilationUnit59 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_compilationUnit63 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_9_in_classDefinition74 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_10_in_classDefinition76 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_classDefinition78 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_11_in_classDefinition80 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_mainMethodDeclaration_in_classDefinition85 = new BitSet(new long[]{0x0000000000003000L});
    public static final BitSet FOLLOW_fieldDeclaration_in_classDefinition91 = new BitSet(new long[]{0x0000000000003000L});
    public static final BitSet FOLLOW_methodDeclaration_in_classDefinition97 = new BitSet(new long[]{0x0000000000003000L});
    public static final BitSet FOLLOW_12_in_classDefinition104 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_9_in_mainMethodDeclaration115 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_13_in_mainMethodDeclaration117 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_14_in_mainMethodDeclaration119 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_mainMethodDeclaration128 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_15_in_mainMethodDeclaration143 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_mainMethodDeclaration147 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_mainMethodDeclaration149 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_mainMethodDeclaration151 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_mainMethodDeclaration166 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_mainMethodDeclaration173 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_11_in_mainMethodDeclaration175 = new BitSet(new long[]{0x000000000D301010L});
    public static final BitSet FOLLOW_methodBody_in_mainMethodDeclaration177 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_12_in_mainMethodDeclaration179 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_fieldDeclaration191 = new BitSet(new long[]{0x0000000000300000L});
    public static final BitSet FOLLOW_type_in_fieldDeclaration193 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_fieldDeclaration195 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_fieldDeclaration197 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_methodDeclaration209 = new BitSet(new long[]{0x0000000000304000L});
    public static final BitSet FOLLOW_returnType_in_methodDeclaration211 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_methodDeclaration213 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_15_in_methodDeclaration217 = new BitSet(new long[]{0x0000000000340000L});
    public static final BitSet FOLLOW_params_in_methodDeclaration221 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_methodDeclaration226 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_11_in_methodDeclaration230 = new BitSet(new long[]{0x000000000D301010L});
    public static final BitSet FOLLOW_methodBody_in_methodDeclaration232 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_12_in_methodDeclaration234 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_type0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_14_in_returnType260 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_type_in_returnType264 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_param_in_params276 = new BitSet(new long[]{0x0000000000400002L});
    public static final BitSet FOLLOW_22_in_params280 = new BitSet(new long[]{0x0000000000300000L});
    public static final BitSet FOLLOW_param_in_params282 = new BitSet(new long[]{0x0000000000400002L});
    public static final BitSet FOLLOW_type_in_param297 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_param299 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_localDeclaration_in_methodBody310 = new BitSet(new long[]{0x000000000D300012L});
    public static final BitSet FOLLOW_statement_in_methodBody316 = new BitSet(new long[]{0x000000000D000012L});
    public static final BitSet FOLLOW_type_in_localDeclaration328 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_localDeclaration330 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_localDeclaration332 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assignStatement_in_statement346 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ifStatement_in_statement352 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_whileStatement_in_statement358 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_invokeExpStatement_in_statement364 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_returnStatement_in_statement370 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_assignStatement386 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_23_in_assignStatement388 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_exp_in_assignStatement390 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_assignStatement392 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_24_in_ifStatement404 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_15_in_ifStatement406 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_exp_in_ifStatement408 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_ifStatement410 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_11_in_ifStatement414 = new BitSet(new long[]{0x000000000D001010L});
    public static final BitSet FOLLOW_statement_in_ifStatement418 = new BitSet(new long[]{0x000000000D001010L});
    public static final BitSet FOLLOW_12_in_ifStatement423 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_25_in_ifStatement429 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_11_in_ifStatement431 = new BitSet(new long[]{0x000000000D001010L});
    public static final BitSet FOLLOW_statement_in_ifStatement435 = new BitSet(new long[]{0x000000000D001010L});
    public static final BitSet FOLLOW_12_in_ifStatement442 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_whileStatement457 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_15_in_whileStatement459 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_exp_in_whileStatement461 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_whileStatement463 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_11_in_whileStatement467 = new BitSet(new long[]{0x000000000D001010L});
    public static final BitSet FOLLOW_statement_in_whileStatement471 = new BitSet(new long[]{0x000000000D001010L});
    public static final BitSet FOLLOW_12_in_whileStatement476 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_invokeExp_in_invokeExpStatement488 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_invokeExpStatement490 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_27_in_returnStatement502 = new BitSet(new long[]{0x00001E3000088030L});
    public static final BitSet FOLLOW_exp_in_returnStatement506 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_returnStatement511 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logicalOrExp_in_exp523 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logicalAndExp_in_logicalOrExp535 = new BitSet(new long[]{0x0000000010000002L});
    public static final BitSet FOLLOW_28_in_logicalOrExp539 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_logicalAndExp_in_logicalOrExp541 = new BitSet(new long[]{0x0000000010000002L});
    public static final BitSet FOLLOW_equalityExp_in_logicalAndExp556 = new BitSet(new long[]{0x0000000020000002L});
    public static final BitSet FOLLOW_29_in_logicalAndExp560 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_equalityExp_in_logicalAndExp562 = new BitSet(new long[]{0x0000000020000002L});
    public static final BitSet FOLLOW_relationalExp_in_equalityExp577 = new BitSet(new long[]{0x00000000C0000002L});
    public static final BitSet FOLLOW_set_in_equalityExp581 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_relationalExp_in_equalityExp589 = new BitSet(new long[]{0x00000000C0000002L});
    public static final BitSet FOLLOW_additiveExp_in_relationalExp604 = new BitSet(new long[]{0x0000000F00000002L});
    public static final BitSet FOLLOW_set_in_relationalExp608 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_additiveExp_in_relationalExp626 = new BitSet(new long[]{0x0000000F00000002L});
    public static final BitSet FOLLOW_multiplicativeExp_in_additiveExp641 = new BitSet(new long[]{0x0000003000000002L});
    public static final BitSet FOLLOW_set_in_additiveExp645 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_multiplicativeExp_in_additiveExp655 = new BitSet(new long[]{0x0000003000000002L});
    public static final BitSet FOLLOW_unaryExp_in_multiplicativeExp670 = new BitSet(new long[]{0x000001C000000002L});
    public static final BitSet FOLLOW_set_in_multiplicativeExp674 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_unaryExp_in_multiplicativeExp688 = new BitSet(new long[]{0x000001C000000002L});
    public static final BitSet FOLLOW_37_in_unaryExp703 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_unaryExp_in_unaryExp705 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_36_in_unaryExp710 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_unaryExp_in_unaryExp712 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unaryExpNotPlusMinus_in_unaryExp717 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_41_in_unaryExpNotPlusMinus729 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_unaryExp_in_unaryExpNotPlusMinus731 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_primaryExp_in_unaryExpNotPlusMinus736 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUM_INT_in_primaryExp750 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_42_in_primaryExp759 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_43_in_primaryExp764 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_44_in_primaryExp769 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_primaryExp774 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_exp_in_primaryExp776 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_primaryExp778 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_invokeExp_in_primaryExp783 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_primaryExp788 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_invokeExp802 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_45_in_invokeExp804 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_invokeExp811 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_15_in_invokeExp813 = new BitSet(new long[]{0x00001E3000048030L});
    public static final BitSet FOLLOW_args_in_invokeExp817 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_invokeExp822 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_exp_in_args834 = new BitSet(new long[]{0x0000000000400002L});
    public static final BitSet FOLLOW_22_in_args838 = new BitSet(new long[]{0x00001E3000008030L});
    public static final BitSet FOLLOW_exp_in_args840 = new BitSet(new long[]{0x0000000000400002L});

}