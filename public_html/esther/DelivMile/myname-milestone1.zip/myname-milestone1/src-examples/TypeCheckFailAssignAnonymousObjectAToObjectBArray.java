class Object30 {
	
}

class Object31 {
	
}

public class TypeCheckFailAssignAnonymousObjectAToObjectBArray {
    public static void main(String[] args) {
    	Object31[] o;
    	
    	o = new Object30();
    }
}