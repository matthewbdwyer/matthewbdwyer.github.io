public class TypeCheckFailForBooleanArrayConditional {
	public static void main(String[] args) {
		boolean[] B;

		B = new boolean[1];
		for (; B;) {
		}
	}
}