public class TypeCheckFailCreateArrayWithFalseLength {
    public static void main(String[] args) {
    	int[] I;

    	I = new int[false];
    }
}