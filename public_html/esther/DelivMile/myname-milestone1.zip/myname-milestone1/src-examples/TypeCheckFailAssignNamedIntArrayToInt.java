public class TypeCheckFailAssignNamedIntArrayToInt {
    public static void main(String[] args) {
    	int i;
    	int[] I;
    	
    	I = new int[1];
    	i = I;
    }
}