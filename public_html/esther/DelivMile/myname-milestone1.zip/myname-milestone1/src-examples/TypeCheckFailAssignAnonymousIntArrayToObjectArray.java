class Object26{
	
}

public class TypeCheckFailAssignAnonymousIntArrayToObjectArray {
    public static void main(String[] args) {
    	Object26[] o;
     	
    	o = new int[1];
    }
}