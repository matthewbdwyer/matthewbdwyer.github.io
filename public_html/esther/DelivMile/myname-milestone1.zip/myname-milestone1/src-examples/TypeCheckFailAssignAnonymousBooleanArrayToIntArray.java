public class TypeCheckFailAssignAnonymousBooleanArrayToIntArray {
    public static void main(String[] args) {
    	int[] i;
     	
    	i = new boolean[1];
    }
}