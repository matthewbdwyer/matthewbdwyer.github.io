public class NullArgumentForIntArrayParameter {
	public static void main(String[] args) {
		takeIntArray(null);
	}

	static void takeIntArray(int[] I) {
	}
}