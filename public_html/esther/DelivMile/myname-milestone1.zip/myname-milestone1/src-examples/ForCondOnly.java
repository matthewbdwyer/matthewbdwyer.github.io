public class ForCondOnly {
    public static void main(String[] args) {
    }
    
    static void condOnly() {
        int i;
        
        i = 0;
        for (; i < 10;) {
        }
    }
}
