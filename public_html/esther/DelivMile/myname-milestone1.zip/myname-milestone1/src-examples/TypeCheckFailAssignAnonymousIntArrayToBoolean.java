public class TypeCheckFailAssignAnonymousIntArrayToBoolean {
    public static void main(String[] args) {
    	boolean b;
     	
    	b = new int[1];
    }
}