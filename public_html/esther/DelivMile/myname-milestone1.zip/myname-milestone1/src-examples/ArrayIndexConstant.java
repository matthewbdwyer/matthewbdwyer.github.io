public class ArrayIndexConstant {
    public static void main(String[] str)
    {
        int[] i_array;

        i_array = new int[] {1, 2, 3};
   
		i_array[0] = 1;
    }
}