class Object16{
	
}

public class TypeCheckFailAssignNamedIntArrayToObject {
    public static void main(String[] args) {
    	Object16 o;
    	int[] I;
    	
    	I = new int[1];
    	o = I;
    }
}