public class TypeCheckFailAssignAnonymousIntArrayToInt {
    public static void main(String[] args) {
    	int i;
     	
    	i = new int[1];
    }
}