public class TypeCheckFailDoWhileWithBooleanArrayCondition {
	public static void main(String[] args) {
		boolean[] B;

		B = new boolean[] { true };
		do {
		} while (B);
	}
}
