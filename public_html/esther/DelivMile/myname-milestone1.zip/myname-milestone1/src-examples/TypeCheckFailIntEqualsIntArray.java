public class TypeCheckFailIntEqualsIntArray {
    public static void main(String[] args) {
    	int i;
    	int[] I;
    	boolean b;
    	
    	i = 0;
    	I = new int[1];
    	b = i == I;
    }
}