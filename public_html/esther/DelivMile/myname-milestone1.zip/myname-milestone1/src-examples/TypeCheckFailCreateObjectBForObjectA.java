public class TypeCheckFailCreateObjectBForObjectA {
    public static void main(String[] args) {
    	COA o;
    	
    	o = new COB();
    }
}

class COA {
	
}

class COB {
	
}