class Object6 {

}

public class TypeCheckFailAssignAnonymousObjectArrayToBoolean {
	public static void main(String[] args) {
		boolean b;

		b = new Object6[1];
	}
}