class Object5{
	
}

public class TypeCheckFailAssignAnonymousIntArrayToObject {
    public static void main(String[] args) {
    	Object5 o;
     	
    	o = new int[1];
    }
}