class Object48{
	
}

public class TypeCheckFailAssignTrueToObjectArray {
    public static void main(String[] args) {
    	Object48[] O;
    	
    	O = true;
    }
}