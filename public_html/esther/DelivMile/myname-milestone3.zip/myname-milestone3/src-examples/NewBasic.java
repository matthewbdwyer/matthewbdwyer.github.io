public class NewBasic {
    public static void main(String[] args) {
        int[] i;
        int[] j;
        boolean[] b;
        boolean[] c;
        
        i = new int[4];
        j = new int[] {1, 2, 3};
        b = new boolean[4];
        c = new boolean[] {true, false};
    }
}
    
