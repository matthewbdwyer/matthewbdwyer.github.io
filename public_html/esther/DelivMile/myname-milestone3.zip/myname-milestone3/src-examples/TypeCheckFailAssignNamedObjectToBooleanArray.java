class Object46 {
	
}

public class TypeCheckFailAssignNamedObjectToBooleanArray {
    public static void main(String[] args) {
    	boolean[] B;
    	Object46 o;
    	
    	o = new Object46();
    	B = o;
    }
}