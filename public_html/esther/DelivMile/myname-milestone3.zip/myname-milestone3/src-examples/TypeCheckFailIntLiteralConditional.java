public class TypeCheckFailIntLiteralConditional {
    public static void main(String[] args) {
    	int i;
     	
    	i = 0;
    	i = 3 ? 1 : 2;
    }
}