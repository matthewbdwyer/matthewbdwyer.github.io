class Object4{
	
}

public class TypeCheckFailAssignAnonymousBooleanArrayToObject {
    public static void main(String[] args) {
    	Object4 o;
     	
    	o = new boolean[1];
    }
}