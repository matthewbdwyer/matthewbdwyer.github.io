public class TypeCheckFailAssignNamedIntArrayToBooleanArray {
    public static void main(String[] args) {
    	boolean[] B;
    	int[] I;
    	
    	I = new int[1];
    	B = I;
    }
}