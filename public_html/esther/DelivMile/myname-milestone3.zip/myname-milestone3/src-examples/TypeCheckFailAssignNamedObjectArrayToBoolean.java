class Object17 {

}

public class TypeCheckFailAssignNamedObjectArrayToBoolean {
	public static void main(String[] args) {
		boolean b;
		Object17[] O;

		O = new Object17[1];
		b = O;
	}
}