class Object3 {

}

public class TypeCheckFailAssignAnonymousObjectArrayToInt {
	public static void main(String[] args) {
		int i;

		i = new Object3[1];
	}
}