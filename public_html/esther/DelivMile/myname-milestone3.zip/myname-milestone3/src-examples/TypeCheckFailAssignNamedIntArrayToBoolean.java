public class TypeCheckFailAssignNamedIntArrayToBoolean {
    public static void main(String[] args) {
    	boolean b;
    	int[] I;
    	
    	I = new int[1];
    	b = I;
    }
}