public class TypeCheckFailCreateIntArrayForBooleanArray {
    public static void main(String[] args) {
    	boolean[] B;
    	
    	B = new int[1];
    }
}