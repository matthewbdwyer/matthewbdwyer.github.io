class Object24{
	
}

public class TypeCheckFailAssignTrueToObject {
    public static void main(String[] args) {
    	Object24 o;
    	
    	o = true;
    }
}