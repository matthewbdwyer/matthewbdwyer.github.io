public class TypeCheckFailComplementBoolean {
    public static void main(String[] args) {
    	boolean b;
    	
    	b = ~b;
    }
}