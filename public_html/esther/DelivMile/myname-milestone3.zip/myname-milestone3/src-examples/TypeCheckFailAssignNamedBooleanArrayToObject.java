class Object15{
	
}

public class TypeCheckFailAssignNamedBooleanArrayToObject {
    public static void main(String[] args) {
    	Object15 o;
    	boolean[] B;
    	
    	B = new boolean[1];
    	o = B;
    }
}