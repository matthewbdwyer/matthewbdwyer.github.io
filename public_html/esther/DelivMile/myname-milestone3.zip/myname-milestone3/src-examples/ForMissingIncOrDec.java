public class ForMissingIncOrDec {
    public static void main(String[] args) {
    }
    
    static void missingIncOrDec() {
        int i;
        
        for (i = 0; i < 10;) {
        }
    }
}
