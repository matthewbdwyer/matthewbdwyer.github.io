public class TypesBasic {
    public static void main(String[] args) {
        int i;
        boolean b;
    }
}
    
