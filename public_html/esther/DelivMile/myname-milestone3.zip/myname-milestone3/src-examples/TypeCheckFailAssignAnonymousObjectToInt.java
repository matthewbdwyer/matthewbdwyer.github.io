class Object1 {
	
}

public class TypeCheckFailAssignAnonymousObjectToInt {
    public static void main(String[] args) {
    	int i;
    	
    	i = new Object1();
    }
}