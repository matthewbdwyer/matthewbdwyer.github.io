public class ReturnNullFromIntArrayMethod {
    public static void main(String[] args) {
    	int[] i;
    	
    	i = returnIntArray();
    }
    
    static int[] returnIntArray() {
    	return null;
    }
}