public class TypeCheckFailAssignNamedBooleanArrayToBoolean {
    public static void main(String[] args) {
    	boolean b;
    	boolean[] B;
    	
    	B = new boolean[1];
    	b = B;
    }
}