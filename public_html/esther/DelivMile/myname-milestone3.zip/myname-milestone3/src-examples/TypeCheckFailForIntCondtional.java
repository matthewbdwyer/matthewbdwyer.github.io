public class TypeCheckFailForIntCondtional {
    public static void main(String[] args) {
    	int i;
    	
    	for (; i; )
    	{}
    }
}