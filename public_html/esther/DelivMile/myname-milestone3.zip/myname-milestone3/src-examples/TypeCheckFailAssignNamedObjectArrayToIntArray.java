class Object43 {

}

public class TypeCheckFailAssignNamedObjectArrayToIntArray {
	public static void main(String[] args) {
		int[] I;
		Object43[] O;

		O = new Object43[1];
		I = O;
	}
}