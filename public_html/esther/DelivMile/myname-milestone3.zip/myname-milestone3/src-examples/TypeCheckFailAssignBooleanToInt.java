public class TypeCheckFailAssignBooleanToInt {
    public static void main(String[] args) {
    	int i;
    	boolean b;
    	
    	b = true;
    	i = b;
    }
}