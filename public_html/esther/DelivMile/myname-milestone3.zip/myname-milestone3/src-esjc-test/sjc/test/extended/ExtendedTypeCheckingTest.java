package sjc.test.extended;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.ArrayList;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.antlr.runtime.ANTLRFileStream;
import org.antlr.runtime.CommonTokenStream;
import org.eclipse.jdt.core.dom.CompilationUnit;

import sjc.parser.extended.ExtendedStaticJavaASTLexer;
import sjc.parser.extended.ExtendedStaticJavaASTParser;
import sjc.symboltable.extended.ExtendedSymbolTable;
import sjc.symboltable.extended.ExtendedSymbolTableBuilder;
import sjc.type.TypeFactory;
import sjc.type.checker.extended.ExtendedTypeChecker;
import sjc.type.checker.extended.ExtendedTypeTable;
import bmsi.util.Diff;
import bmsi.util.DiffPrint;

public class ExtendedTypeCheckingTest extends TestCase
{
	public static void testFail(String filename)
	{
    	System.out.println("*** Begin testing: " + filename);
        try {
        	ANTLRFileStream afs = new ANTLRFileStream(filename);
    		ExtendedStaticJavaASTLexer esjl = new ExtendedStaticJavaASTLexer(afs);
    		CommonTokenStream cts = new CommonTokenStream(esjl);
    		ExtendedStaticJavaASTParser esjp = new ExtendedStaticJavaASTParser(cts);
    		CompilationUnit cu = esjp.compilationUnit();
        	 
        	TypeFactory tf = new TypeFactory();
        	ExtendedSymbolTable est = ExtendedSymbolTableBuilder.build(cu);
        	ExtendedTypeChecker.check(tf, cu, est);
        	System.out.println("Unexpected type checker to successfully pass " + filename);
        	System.out.println("*** End FAILING testing: " + filename);
        	System.out.println();
            System.out.flush();
        	Assert.assertTrue(false);
        } catch (Exception e) {
        	try {
	        	Object[] expectedStrings = getExpectedStrings(filename);
	        	Object[] resultStrings = getLines(e.getMessage());
	        	boolean b = diff(resultStrings, expectedStrings);
	            if (!b) {
	            	System.out.println("*** End FAILING testing: " + filename);
	            	System.out.println();
	                System.out.flush();
	            	Assert.assertTrue(false);
	            } else {
	            	System.out.println("*** End PASSING testing: " + filename);
	            	System.out.println();
	                System.out.flush();
	            }
        	}
        	catch (Exception e2)
        	{
            	System.out.println("Unexpected exception caught while processing " + filename);
            	System.out.println("Reason: " + e);
            	System.out.println("*** End FAILING testing: " + filename);
            	System.out.println();
                System.out.flush();
                Assert.assertTrue(e.getMessage(), false);
        	}
            System.out.flush();
        }
	}
	
    public static void testPass(String filename)
    {
    	System.out.println("*** Begin testing: " + filename);
        try {
        	String result;
        	{
        		ANTLRFileStream afs = new ANTLRFileStream(filename);
        		ExtendedStaticJavaASTLexer esjl = new ExtendedStaticJavaASTLexer(afs);
        		CommonTokenStream cts = new CommonTokenStream(esjl);
        		ExtendedStaticJavaASTParser esjp = new ExtendedStaticJavaASTParser(cts);
        		CompilationUnit cu = esjp.compilationUnit();
        		
	        	TypeFactory tf = new TypeFactory();
	        	ExtendedSymbolTable est = ExtendedSymbolTableBuilder.build(cu);
	        	ExtendedTypeTable ett = ExtendedTypeChecker.check(tf, cu, est);
	        	result = est.toString() + '\n' + ett.toString();
	        	
        	}
        	Object[] expectedStrings = getExpectedStrings(filename);
        	Object[] resultStrings = getLines(result);
        	boolean b = diff(resultStrings, expectedStrings);
            if (!b) {
            	System.out.println("*** End FAILING testing: " + filename);
            	System.out.println();
                System.out.flush();
            	Assert.assertTrue(false);
            } else {
            	System.out.println("*** End PASSING testing: " + filename);
            	System.out.println();
                System.out.flush();
            }
        } catch (Exception e) {
        	System.out.println("Unexpected exception caught while processing " + filename);
        	System.out.println("Reason: " + e);
        	System.out.println("*** End FAILING testing: " + filename);
        	System.out.println();
            System.out.flush();
            Assert.assertTrue(e.getMessage(), false);
        }
    }
    
    private static Object[] getExpectedStrings(String filename) throws Exception
    {
		ArrayList<Object> list = new ArrayList<Object>();
    	FileReader fr = new FileReader(filename + ".etc");
    	BufferedReader br = new BufferedReader(fr);
    	String temp = br.readLine();
    	while (temp != null)
    	{
    		list.add(temp);
    		temp = br.readLine();
    	}
    	fr.close();
    	return list.toArray();
    }
    
    private static boolean diff(Object[] resultStrings, Object[] expectedStrings)
    {
    	Diff diff = new Diff(resultStrings, expectedStrings);
        Diff.change script = diff.diff_2(false);
        DiffPrint.Base p = new DiffPrint.UnifiedPrint(resultStrings, expectedStrings);
        if (script == null)
    	{
    		System.out.println("OK");
    		return true;
    	}
    	else
    	{
            p.setOutput(new PrintWriter(System.out));
            p.print_script(script);        	
            System.err.flush();
            return false;
    	}
    }
    
	private static Object[] getLines(String s) throws Exception {
		ArrayList<Object> list = new ArrayList<Object>();
		BufferedReader br = new BufferedReader(new StringReader(s));
		String temp = br.readLine();
		while (temp != null)
		{
			list.add(temp);
			temp = br.readLine();
		}
		br.close();
		return list.toArray();
	}

	public void testAEEmptyTest() { testPass("src-examples/AEEmptyTest.java"); }

	public void testArrayAccessVariable() { testPass("src-examples/ArrayAccessVariable.java"); }

	public void testArrayCreation() { testPass("src-examples/ArrayCreation.java"); }

	public void testArrayCreation2() { testPass("src-examples/ArrayCreation2.java"); }

	public void testArrayIndex() { testPass("src-examples/ArrayIndex.java"); }

	public void testArrayIndexConstant() { testPass("src-examples/ArrayIndexConstant.java"); }

	public void testAssignNullToObject() { testPass("src-examples/AssignNullToObject.java"); }

	public void testBasicTypes() { testPass("src-examples/BasicTypes.java"); }

	public void testBinaryOps() { testPass("src-examples/BinaryOps.java"); }

	public void testBooleanAnd() { testPass("src-examples/BooleanAnd.java"); }

	public void testBooleanLiteral() { testPass("src-examples/BooleanLiteral.java"); }

	public void testBooleanNot() { testPass("src-examples/BooleanNot.java"); }

	public void testBooleanOr() { testPass("src-examples/BooleanOr.java"); }

	public void testConditionalFalse() { testPass("src-examples/ConditionalFalse.java"); }

	public void testConditionalTrue() { testPass("src-examples/ConditionalTrue.java"); }

	public void testConditionalWithNull() { testPass("src-examples/ConditionalWithNull.java"); }

	public void testCreateIntArrayWithIntAndIntLiteralInitializers() { testPass("src-examples/CreateIntArrayWithIntAndIntLiteralInitializers.java"); }

	public void testDoWhile() { testPass("src-examples/DoWhile.java"); }

	public void testDoWhileWithBooleanArrayAccessCondition() { testPass("src-examples/DoWhileWithBooleanArrayAccessCondition.java"); }

	public void testFactorial() { testPass("src-examples/Factorial.java"); }

	public void testFieldAccess() { testPass("src-examples/FieldAccess.java"); }

	public void testFor() { testPass("src-examples/For.java"); }

	public void testForBooleanArrayAccessConditional() { testPass("src-examples/ForBooleanArrayAccessConditional.java"); }

	public void testForBooleanMemberAccessConditional() { testPass("src-examples/ForBooleanMemberAccessConditional.java"); }

	public void testForCondOnly() { testPass("src-examples/ForCondOnly.java"); }

	public void testForEmpty() { testPass("src-examples/ForEmpty.java"); }

	public void testForFull() { testPass("src-examples/ForFull.java"); }

	public void testForIncOrDecOnly() { testPass("src-examples/ForIncOrDecOnly.java"); }

	public void testForInitOnly() { testPass("src-examples/ForInitOnly.java"); }

	public void testForLoop() { testPass("src-examples/ForLoop.java"); }

	public void testForMissingCond() { testPass("src-examples/ForMissingCond.java"); }

	public void testForMissingIncOrDec() { testPass("src-examples/ForMissingIncOrDec.java"); }

	public void testForMissingInit() { testPass("src-examples/ForMissingInit.java"); }

	public void testForMultipleIncOrDecOnly() { testPass("src-examples/ForMultipleIncOrDecOnly.java"); }

	public void testForMultipleInitAndIncOrDec() { testPass("src-examples/ForMultipleInitAndIncOrDec.java"); }

	public void testForMultipleInitOnly() { testPass("src-examples/ForMultipleInitOnly.java"); }

	public void testForwardClassRefs() { testPass("src-examples/ForwardClassRefs.java"); }

	public void testForwardClassTest() { testPass("src-examples/ForwardClassTest.java"); }

	public void testIf() { testPass("src-examples/If.java"); }

	public void testIfFalseEmpty() { testPass("src-examples/IfFalseEmpty.java"); }

	public void testIfFalseSingle() { testPass("src-examples/IfFalseSingle.java"); }

	public void testIfFalseSingleElseEmpty() { testPass("src-examples/IfFalseSingleElseEmpty.java"); }

	public void testIfFalseSingleElseMultiple() { testPass("src-examples/IfFalseSingleElseMultiple.java"); }

	public void testIfFalseSingleElseSingle() { testPass("src-examples/IfFalseSingleElseSingle.java"); }

	public void testIfTrueEmpty() { testPass("src-examples/IfTrueEmpty.java"); }

	public void testIfTrueEmptyElseEmpty() { testPass("src-examples/IfTrueEmptyElseEmpty.java"); }

	public void testIfTrueMultiple() { testPass("src-examples/IfTrueMultiple.java"); }

	public void testIfTrueSingle() { testPass("src-examples/IfTrueSingle.java"); }

	public void testIfTrueSingleElseEmpty() { testPass("src-examples/IfTrueSingleElseEmpty.java"); }

	public void testIfTrueSingleElseSingle() { testPass("src-examples/IfTrueSingleElseSingle.java"); }

	public void testIncIntArrayAccess() { testPass("src-examples/IncIntArrayAccess.java"); }

	public void testIntAdd() { testPass("src-examples/IntAdd.java"); }

	public void testIntComplement() { testPass("src-examples/IntComplement.java"); }

	public void testIntDivide() { testPass("src-examples/IntDivide.java"); }

	public void testIntEqual() { testPass("src-examples/IntEqual.java"); }

	public void testIntGreaterThan() { testPass("src-examples/IntGreaterThan.java"); }

	public void testIntGreaterThanOrEqual() { testPass("src-examples/IntGreaterThanOrEqual.java"); }

	public void testIntLessThan() { testPass("src-examples/IntLessThan.java"); }

	public void testIntLessThanOrEqual() { testPass("src-examples/IntLessThanOrEqual.java"); }

	public void testIntMultiply() { testPass("src-examples/IntMultiply.java"); }

	public void testIntNegate() { testPass("src-examples/IntNegate.java"); }

	public void testIntNotEqual() { testPass("src-examples/IntNotEqual.java"); }

	public void testIntPlus() { testPass("src-examples/IntPlus.java"); }

	public void testIntPostDecrement() { testPass("src-examples/IntPostDecrement.java"); }

	public void testIntPostIncrement() { testPass("src-examples/IntPostIncrement.java"); }

	public void testIntRemainder() { testPass("src-examples/IntRemainder.java"); }

	public void testIntShiftLeft() { testPass("src-examples/IntShiftLeft.java"); }

	public void testIntShiftRight() { testPass("src-examples/IntShiftRight.java"); }

	public void testIntSubtract() { testPass("src-examples/IntSubtract.java"); }

	public void testIntUnsignedShiftRight() { testPass("src-examples/IntUnsignedShiftRight.java"); }

	public void testNewBasic() { testPass("src-examples/NewBasic.java"); }

	public void testNewID() { testPass("src-examples/NewID.java"); }

	public void testNullArgumentForIntArrayParameter() { testPass("src-examples/NullArgumentForIntArrayParameter.java"); }

	public void testNullEqualsNull() { testPass("src-examples/NullEqualsNull.java"); }

	public void testObjectAEqualsReturnedObjectA() { testPass("src-examples/ObjectAEqualsReturnedObjectA.java"); }

	public void testParens() { testPass("src-examples/Parens.java"); }

	public void testPower() { testPass("src-examples/Power.java"); }

	public void testQueue() { testPass("src-examples/Queue.java"); }

	public void testReturnNullFromIntArrayMethod() { testPass("src-examples/ReturnNullFromIntArrayMethod.java"); }

	public void testSAExample() { testPass("src-examples/SAExample.java"); }

	public void testSymbolTableTest() { testPass("src-examples/SymbolTableTest.java"); }

	public void testSyntaxTorture() { testPass("src-examples/SyntaxTorture.java"); }

	public void testTypeCheckFailAssignAnonymousBooleanArrayToBoolean() { testFail("src-examples/TypeCheckFailAssignAnonymousBooleanArrayToBoolean.java"); }

	public void testTypeCheckFailAssignAnonymousBooleanArrayToInt() { testFail("src-examples/TypeCheckFailAssignAnonymousBooleanArrayToInt.java"); }

	public void testTypeCheckFailAssignAnonymousBooleanArrayToIntArray() { testFail("src-examples/TypeCheckFailAssignAnonymousBooleanArrayToIntArray.java"); }

	public void testTypeCheckFailAssignAnonymousBooleanArrayToObject() { testFail("src-examples/TypeCheckFailAssignAnonymousBooleanArrayToObject.java"); }

	public void testTypeCheckFailAssignAnonymousBooleanArrayToObjectArray() { testFail("src-examples/TypeCheckFailAssignAnonymousBooleanArrayToObjectArray.java"); }

	public void testTypeCheckFailAssignAnonymousIntArrayToBoolean() { testFail("src-examples/TypeCheckFailAssignAnonymousIntArrayToBoolean.java"); }

	public void testTypeCheckFailAssignAnonymousIntArrayToBooleanArray() { testFail("src-examples/TypeCheckFailAssignAnonymousIntArrayToBooleanArray.java"); }

	public void testTypeCheckFailAssignAnonymousIntArrayToInt() { testFail("src-examples/TypeCheckFailAssignAnonymousIntArrayToInt.java"); }

	public void testTypeCheckFailAssignAnonymousIntArrayToObject() { testFail("src-examples/TypeCheckFailAssignAnonymousIntArrayToObject.java"); }

	public void testTypeCheckFailAssignAnonymousIntArrayToObjectArray() { testFail("src-examples/TypeCheckFailAssignAnonymousIntArrayToObjectArray.java"); }

	public void testTypeCheckFailAssignAnonymousObjectAArrayToObjectA() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectAArrayToObjectA.java"); }

	public void testTypeCheckFailAssignAnonymousObjectAArrayToObjectB() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectAArrayToObjectB.java"); }

	public void testTypeCheckFailAssignAnonymousObjectAArrayToObjectBArray() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectAArrayToObjectBArray.java"); }

	public void testTypeCheckFailAssignAnonymousObjectArrayToBoolean() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectArrayToBoolean.java"); }

	public void testTypeCheckFailAssignAnonymousObjectArrayToBooleanArray() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectArrayToBooleanArray.java"); }

	public void testTypeCheckFailAssignAnonymousObjectArrayToInt() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectArrayToInt.java"); }

	public void testTypeCheckFailAssignAnonymousObjectArrayToIntArray() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectArrayToIntArray.java"); }

	public void testTypeCheckFailAssignAnonymousObjectAToObjectB() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectAToObjectB.java"); }

	public void testTypeCheckFailAssignAnonymousObjectAToObjectBArray() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectAToObjectBArray.java"); }

	public void testTypeCheckFailAssignAnonymousObjectToBoolean() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectToBoolean.java"); }

	public void testTypeCheckFailAssignAnonymousObjectToBooleanArray() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectToBooleanArray.java"); }

	public void testTypeCheckFailAssignAnonymousObjectToInt() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectToInt.java"); }

	public void testTypeCheckFailAssignAnonymousObjectToIntArray() { testFail("src-examples/TypeCheckFailAssignAnonymousObjectToIntArray.java"); }

	public void testTypeCheckFailAssignBooleanToInt() { testFail("src-examples/TypeCheckFailAssignBooleanToInt.java"); }

	public void testTypeCheckFailAssignBooleanToIntArray() { testFail("src-examples/TypeCheckFailAssignBooleanToIntArray.java"); }

	public void testTypeCheckFailAssignBooleanToObject() { testFail("src-examples/TypeCheckFailAssignBooleanToObject.java"); }

	public void testTypeCheckFailAssignBooleanToObjectArray() { testFail("src-examples/TypeCheckFailAssignBooleanToObjectArray.java"); }

	public void testTypeCheckFailAssignFalseToInt() { testFail("src-examples/TypeCheckFailAssignFalseToInt.java"); }

	public void testTypeCheckFailAssignFalseToIntArray() { testFail("src-examples/TypeCheckFailAssignFalseToIntArray.java"); }

	public void testTypeCheckFailAssignFalseToObject() { testFail("src-examples/TypeCheckFailAssignFalseToObject.java"); }

	public void testTypeCheckFailAssignFalseToObjectArray() { testFail("src-examples/TypeCheckFailAssignFalseToObjectArray.java"); }

	public void testTypeCheckFailAssignNamedBooleanArrayToBoolean() { testFail("src-examples/TypeCheckFailAssignNamedBooleanArrayToBoolean.java"); }

	public void testTypeCheckFailAssignNamedBooleanArrayToInt() { testFail("src-examples/TypeCheckFailAssignNamedBooleanArrayToInt.java"); }

	public void testTypeCheckFailAssignNamedBooleanArrayToIntArray() { testFail("src-examples/TypeCheckFailAssignNamedBooleanArrayToIntArray.java"); }

	public void testTypeCheckFailAssignNamedBooleanArrayToObject() { testFail("src-examples/TypeCheckFailAssignNamedBooleanArrayToObject.java"); }

	public void testTypeCheckFailAssignNamedBooleanArrayToObjectArray() { testFail("src-examples/TypeCheckFailAssignNamedBooleanArrayToObjectArray.java"); }

	public void testTypeCheckFailAssignNamedIntArrayToBoolean() { testFail("src-examples/TypeCheckFailAssignNamedIntArrayToBoolean.java"); }

	public void testTypeCheckFailAssignNamedIntArrayToBooleanArray() { testFail("src-examples/TypeCheckFailAssignNamedIntArrayToBooleanArray.java"); }

	public void testTypeCheckFailAssignNamedIntArrayToInt() { testFail("src-examples/TypeCheckFailAssignNamedIntArrayToInt.java"); }

	public void testTypeCheckFailAssignNamedIntArrayToObject() { testFail("src-examples/TypeCheckFailAssignNamedIntArrayToObject.java"); }

	public void testTypeCheckFailAssignNamedIntArrayToObjectArray() { testFail("src-examples/TypeCheckFailAssignNamedIntArrayToObjectArray.java"); }

	public void testTypeCheckFailAssignNamedObjectAArrayToObjectA() { testFail("src-examples/TypeCheckFailAssignNamedObjectAArrayToObjectA.java"); }

	public void testTypeCheckFailAssignNamedObjectAArrayToObjectB() { testFail("src-examples/TypeCheckFailAssignNamedObjectAArrayToObjectB.java"); }

	public void testTypeCheckFailAssignNamedObjectAArrayToObjectBArray() { testFail("src-examples/TypeCheckFailAssignNamedObjectAArrayToObjectBArray.java"); }

	public void testTypeCheckFailAssignNamedObjectArrayToBoolean() { testFail("src-examples/TypeCheckFailAssignNamedObjectArrayToBoolean.java"); }

	public void testTypeCheckFailAssignNamedObjectArrayToBooleanArray() { testFail("src-examples/TypeCheckFailAssignNamedObjectArrayToBooleanArray.java"); }

	public void testTypeCheckFailAssignNamedObjectArrayToInt() { testFail("src-examples/TypeCheckFailAssignNamedObjectArrayToInt.java"); }

	public void testTypeCheckFailAssignNamedObjectArrayToIntArray() { testFail("src-examples/TypeCheckFailAssignNamedObjectArrayToIntArray.java"); }

	public void testTypeCheckFailAssignNamedObjectAToObjectB() { testFail("src-examples/TypeCheckFailAssignNamedObjectAToObjectB.java"); }

	public void testTypeCheckFailAssignNamedObjectAToObjectBArray() { testFail("src-examples/TypeCheckFailAssignNamedObjectAToObjectBArray.java"); }

	public void testTypeCheckFailAssignNamedObjectToBoolean() { testFail("src-examples/TypeCheckFailAssignNamedObjectToBoolean.java"); }

	public void testTypeCheckFailAssignNamedObjectToBooleanArray() { testFail("src-examples/TypeCheckFailAssignNamedObjectToBooleanArray.java"); }

	public void testTypeCheckFailAssignNamedObjectToInt() { testFail("src-examples/TypeCheckFailAssignNamedObjectToInt.java"); }

	public void testTypeCheckFailAssignNamedObjectToIntArray() { testFail("src-examples/TypeCheckFailAssignNamedObjectToIntArray.java"); }

	public void testTypeCheckFailAssignTrueToInt() { testFail("src-examples/TypeCheckFailAssignTrueToInt.java"); }

	public void testTypeCheckFailAssignTrueToIntArray() { testFail("src-examples/TypeCheckFailAssignTrueToIntArray.java"); }

	public void testTypeCheckFailAssignTrueToObject() { testFail("src-examples/TypeCheckFailAssignTrueToObject.java"); }

	public void testTypeCheckFailAssignTrueToObjectArray() { testFail("src-examples/TypeCheckFailAssignTrueToObjectArray.java"); }

	public void testTypeCheckFailBooleanArrayWithBooleanAccess() { testFail("src-examples/TypeCheckFailBooleanArrayWithBooleanAccess.java"); }

	public void testTypeCheckFailComplementBadExpression() { testFail("src-examples/TypeCheckFailComplementBadExpression.java"); }

	public void testTypeCheckFailComplementBoolean() { testFail("src-examples/TypeCheckFailComplementBoolean.java"); }

	public void testTypeCheckFailComplementNull() { testFail("src-examples/TypeCheckFailComplementNull.java"); }

	public void testTypeCheckFailComplementTrue() { testFail("src-examples/TypeCheckFailComplementTrue.java"); }

	public void testTypeCheckFailConditionalAssignIntToBool() { testFail("src-examples/TypeCheckFailConditionalAssignIntToBool.java"); }

	public void testTypeCheckFailConditionalAssignObjectAToObjectAArray() { testFail("src-examples/TypeCheckFailConditionalAssignObjectAToObjectAArray.java"); }

	public void testTypeCheckFailCreateArrayWithBooleanLength() { testFail("src-examples/TypeCheckFailCreateArrayWithBooleanLength.java"); }

	public void testTypeCheckFailCreateArrayWithFalseLength() { testFail("src-examples/TypeCheckFailCreateArrayWithFalseLength.java"); }

	public void testTypeCheckFailCreateIntArrayForBooleanArray() { testFail("src-examples/TypeCheckFailCreateIntArrayForBooleanArray.java"); }

	public void testTypeCheckFailCreateIntArrayForInt() { testFail("src-examples/TypeCheckFailCreateIntArrayForInt.java"); }

	public void testTypeCheckFailCreateIntArrayWithBooleanInitializer() { testFail("src-examples/TypeCheckFailCreateIntArrayWithBooleanInitializer.java"); }

	public void testTypeCheckFailCreateIntArrayWithIntAndBooleanInitializers() { testFail("src-examples/TypeCheckFailCreateIntArrayWithIntAndBooleanInitializers.java"); }

	public void testTypeCheckFailCreateObjectAForObjectAArray() { testFail("src-examples/TypeCheckFailCreateObjectAForObjectAArray.java"); }

	public void testTypeCheckFailCreateObjectBForObjectA() { testFail("src-examples/TypeCheckFailCreateObjectBForObjectA.java"); }

	public void testTypeCheckFailDoWhileWithBooleanArrayCondition() { testFail("src-examples/TypeCheckFailDoWhileWithBooleanArrayCondition.java"); }

	public void testTypeCheckFailForBooleanArrayConditional() { testFail("src-examples/TypeCheckFailForBooleanArrayConditional.java"); }

	public void testTypeCheckFailForIntCondtional() { testFail("src-examples/TypeCheckFailForIntCondtional.java"); }

	public void testTypeCheckFailIncBoolean() { testFail("src-examples/TypeCheckFailIncBoolean.java"); }

	public void testTypeCheckFailIncIntArray() { testFail("src-examples/TypeCheckFailIncIntArray.java"); }

	public void testTypeCheckFailIntArgumentForBooleanParameter() { testFail("src-examples/TypeCheckFailIntArgumentForBooleanParameter.java"); }

	public void testTypeCheckFailIntConditional() { testFail("src-examples/TypeCheckFailIntConditional.java"); }

	public void testTypeCheckFailIntEqualsBoolean() { testFail("src-examples/TypeCheckFailIntEqualsBoolean.java"); }

	public void testTypeCheckFailIntEqualsIntArray() { testFail("src-examples/TypeCheckFailIntEqualsIntArray.java"); }

	public void testTypeCheckFailIntLiteralConditional() { testFail("src-examples/TypeCheckFailIntLiteralConditional.java"); }

	public void testTypeCheckFailIntPlusBadExpression() { testFail("src-examples/TypeCheckFailIntPlusBadExpression.java"); }

	public void testTypeCheckFailIntPlusObject() { testFail("src-examples/TypeCheckFailIntPlusObject.java"); }

	public void testTypeCheckFailNegateBadExpression() { testFail("src-examples/TypeCheckFailNegateBadExpression.java"); }

	public void testTypeCheckFailNegateBoolean() { testFail("src-examples/TypeCheckFailNegateBoolean.java"); }

	public void testTypeCheckFailNegateIntArray() { testFail("src-examples/TypeCheckFailNegateIntArray.java"); }

	public void testTypeCheckFailNegateObject() { testFail("src-examples/TypeCheckFailNegateObject.java"); }

	public void testTypeCheckFailNullEqualsVoid() { testFail("src-examples/TypeCheckFailNullEqualsVoid.java"); }

	public void testTypeCheckFailObjectAEqualsReturnedObjectB() { testFail("src-examples/TypeCheckFailObjectAEqualsReturnedObjectB.java"); }

	public void testTypeCheckFailObjectEqualsBoolean() { testFail("src-examples/TypeCheckFailObjectEqualsBoolean.java"); }

	public void testTypeCheckFailReturnIntFromBooleanMethod() { testFail("src-examples/TypeCheckFailReturnIntFromBooleanMethod.java"); }

	public void testTypeCheckFailReturnIntLiteralFromVoidMethod() { testFail("src-examples/TypeCheckFailReturnIntLiteralFromVoidMethod.java"); }

	public void testTypeCheckFailTooFewMethodArguments() { testFail("src-examples/TypeCheckFailTooFewMethodArguments.java"); }

	public void testTypeCheckFailTooManyMethodArguments() { testFail("src-examples/TypeCheckFailTooManyMethodArguments.java"); }

	public void testTypeCheckFailUndefinedClass() { testFail("src-examples/TypeCheckFailUndefinedClass.java"); }

	public void testTypesArray() { testPass("src-examples/TypesArray.java"); }

	public void testTypesBasic() { testPass("src-examples/TypesBasic.java"); }

	public void testTypesID() { testPass("src-examples/TypesID.java"); }

	public void testUnaryOps() { testPass("src-examples/UnaryOps.java"); }

	public void testWhile() { testPass("src-examples/While.java"); }

	public void testWhileInitRD() { testPass("src-examples/WhileInitRD.java"); }

}
